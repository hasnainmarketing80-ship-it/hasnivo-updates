<?php
/**
 * Site header: document head, skip link target, navigation.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#060A18">
<meta name="color-scheme" content="dark">
<?php if ( ! current_theme_supports( 'title-tag' ) ) { echo '<title>' . esc_html( HNVL_TITLE ) . '</title>' . "\n"; } ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
if ( function_exists( 'hx_bg_canvas' ) ) {
	remove_action( 'wp_body_open', 'hx_bg_canvas' ); // old background plugin: its CSS/JS are not loaded here, so skip its canvas.
}
wp_body_open();
?>
<div class="progress" id="progress" aria-hidden="true"></div>
<svg class="sprite" width="0" height="0" aria-hidden="true" focusable="false">
  <symbol id="i-chat" viewBox="0 0 24 24"><path d="M4 5h16v11H10l-5 4v-4H4z"/><path d="M8.5 10.5h.01M12 10.5h.01M15.5 10.5h.01"/></symbol>
  <symbol id="i-bolt" viewBox="0 0 24 24"><path d="M13 3L5 14h6l-1 7 8-11h-6z"/></symbol>
  <symbol id="i-headset" viewBox="0 0 24 24"><path d="M4 14v-2a8 8 0 0116 0v2"/><path d="M4 14h3v5H4zM17 14h3v5h-3z"/><path d="M20 19c0 1.6-2 2-5 2"/></symbol>
  <symbol id="i-target" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 12h.01"/></symbol>
  <symbol id="i-cpu" viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2"/><path d="M10 10h4v4h-4zM9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4"/></symbol>
  <symbol id="i-plug" viewBox="0 0 24 24"><path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 01-12 0z"/><path d="M12 17v4"/></symbol>
  <symbol id="i-api" viewBox="0 0 24 24"><path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 5l-3 14"/></symbol>
  <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
  <symbol id="i-hourglass" viewBox="0 0 24 24"><path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9"/></symbol>
  <symbol id="i-magnet" viewBox="0 0 24 24"><path d="M5 4v7a7 7 0 0014 0V4h-4v7a3 3 0 01-6 0V4z"/><path d="M5 8h4M15 8h4"/></symbol>
  <symbol id="i-sliders" viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/></symbol>
  <symbol id="i-heart" viewBox="0 0 24 24"><path d="M12 20s-8-5-8-11a4.5 4.5 0 018-2.7A4.5 4.5 0 0120 9c0 6-8 11-8 11z"/></symbol>
  <symbol id="i-layers" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></symbol>
  <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
  <symbol id="i-replay" viewBox="0 0 24 24"><path d="M4 12a8 8 0 108-8H8"/><path d="M11 1L8 4l3 3"/></symbol>
  <symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol>
  <symbol id="i-close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
  <symbol id="i-wa" viewBox="0 0 24 24"><path d="M3.5 20.5l1.3-4.6A8.5 8.5 0 1112 20.5a8.5 8.5 0 01-4.2-1.1z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.6-2.2-1-1 .8c-1-.4-1.9-1.300-2.300-2.300l.8-1-1-2.200z"/></symbol>
  <symbol id="i-facebook" viewBox="0 0 24 24"><path d="M14 8h3V4h-3a4 4 0 00-4 4v2H7v4h3v6h4v-6h3l1-4h-4V8.500z"/></symbol>
  <symbol id="i-linkedin" viewBox="0 0 24 24"><rect x="3.500" y="3.500" width="17" height="17" rx="3"/><path d="M8 10.500V16M8 7.800v.01M12 16v-5.500M12 13c0-1.500 1-2.500 2.300-2.500S16.500 11.300 16.500 13v3"/></symbol>
  <symbol id="i-instagram" viewBox="0 0 24 24"><rect x="3.500" y="3.500" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17 7h.01"/></symbol>
  <symbol id="i-x" viewBox="0 0 24 24"><path d="M4 4l16 16M20 4L4 20"/></symbol>
</svg>

<header class="site-header" id="top">
  <div class="wrap nav">
    <a class="brand" href="<?php echo esc_url( home_url( '/#home' ) ); ?>" aria-label="Hasnivo Tech home">
      <svg width="42" height="42" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#25D6F0"/><stop offset=".5" stop-color="#3B74FF"/><stop offset="1" stop-color="#8F5CFF"/></linearGradient></defs><path d="M32 12V6" stroke="#25D6F0" stroke-width="3" stroke-linecap="round"/><circle cx="32" cy="4.6" r="3.4" fill="#25D6F0"/><rect x="2.5" y="26" width="7" height="12" rx="3" fill="#3B74FF"/><rect x="54.5" y="26" width="7" height="12" rx="3" fill="#8F5CFF"/><path d="M22 12H42A14 14 0 0 1 56 26V36A14 14 0 0 1 42 50H36L24 60V50H22A14 14 0 0 1 8 36V26A14 14 0 0 1 22 12z" fill="url(#lg)"/><rect x="15" y="20" width="34" height="23" rx="10" fill="#050A1A"/><circle cx="25" cy="29" r="3.9" fill="#25D6F0"/><circle cx="39" cy="29" r="3.9" fill="#25D6F0"/><circle cx="26.2" cy="27.8" r="1.1" fill="#fff"/><circle cx="40.2" cy="27.8" r="1.1" fill="#fff"/><path d="M27 36.2q5 3.2 10 0" stroke="#25D6F0" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg>
      <span class="brand-name">Hasnivo<small>TECH</small></span>
    </a>
    <ul class="nav-links" id="navLinks">
      <li><a href="<?php echo esc_url( home_url( '/#home' ) ); ?>" data-spy="home">Home</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#features' ) ); ?>" data-spy="features">Features</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#plans' ) ); ?>" data-spy="plans">Plans</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#services' ) ); ?>" data-spy="services">Services</a></li>
      <li><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>" data-spy="faq">FAQ</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" data-spy="contact">Contact</a></li>
      <li class="nav-signin"><a href="https://app.hasnivo.tech/login.php">Sign in</a></li>
    </ul>
    <div class="nav-cta">
      <a class="btn btn-ghost btn-sm nav-signin-d" href="https://app.hasnivo.tech/login.php">Sign in</a>
      <a class="btn btn-primary btn-sm" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
      <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navLinks" aria-label="Open menu">
        <svg class="ic"><use href="#i-menu"/></svg>
      </button>
    </div>
  </div>
</header>

<main>
<main>
<!-- HOME -->
<section class="hero" id="home">
  <div class="aura" aria-hidden="true"><i></i><i></i></div>
  <div class="wrap hero-grid">
    <div>
      <h1><span class="h1-kw"><i></i>WhatsApp AI Chatbot for Pakistani Businesses</span><span>Automate</span><span>Conversations.</span><span class="grad">Grow Your Business.</span></h1>
      <p class="hero-lead">Hasnivo Tech builds <a class="inline" href="<?php echo esc_url( home_url( '/#services' ) ); ?>">WhatsApp AI chatbots</a> that answer your customers instantly, take appointments and food orders right inside WhatsApp, and show every chat to your team in one shared inbox, even at 2 AM.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
        <a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">See plans</a>
      </div>
      <ul class="hero-points">
        <li><svg class="ic"><use href="#i-check"/></svg>Connect by QR code</li>
        <li><svg class="ic"><use href="#i-check"/></svg>Replies in your customers&#8217; language</li>
        <li><svg class="ic"><use href="#i-check"/></svg>Free plan available</li>
      </ul>
    </div>

    <div>
      <div class="stage" id="stage">
        <div class="scene-tabs" role="tablist" aria-label="Choose a demo">
          <button class="scene-tab on" type="button" role="tab" aria-selected="true" data-scene="food">🍔 Food order</button>
          <button class="scene-tab" type="button" role="tab" aria-selected="false" data-scene="appt">📅 Appointment</button>
          <button class="scene-tab" type="button" role="tab" aria-selected="false" data-scene="help">💬 Support</button>
        </div>
        <div class="phone2" role="img" aria-label="Animated sample WhatsApp chats: a food order, an appointment booking and customer support with an AI assistant">
          <div class="wa">
            <div class="wa-top"><div class="wa-av" id="waAv">BK</div><div><strong id="waName">Biryani Kitchen</strong><span class="s" id="waSub">online · replies instantly</span></div><div class="tag">Sample</div></div>
            <div class="wa-feed" id="waFeed" aria-hidden="true"></div>
            <div class="wa-input" aria-hidden="true"><i>Message</i><b>🎤</b></div>
          </div>
        </div>
        <div class="float f-order" id="fOrder"><i>🛍️</i><div><b>New order #1042</b><span>Rs 1,210 · Home delivery</span></div></div>
        <div class="float f-book" id="fBook"><i>📅</i><div><b>Booking confirmed</b><span>Tomorrow · 3:00 PM</span></div></div>
        <div class="float f-reply" id="fReply"><i>👤</i><div><b>Team joined the chat</b><span>Human handover</span></div></div>
        <div class="stage-foot"><span>A sample chat. Your bot uses your own menu and rules.</span><button type="button" id="waReplay">↻ Replay</button></div>
      </div>
    </div>
  </div>
</section>



<div class="marquee" aria-hidden="true"><div class="marquee-track"><ul><li>Restaurants</li><li>Clinics</li><li>Salons</li><li>Tutors</li><li>Offices</li><li>Pharmacies</li><li>Online shops</li><li>Gyms</li><li>Bakeries</li><li>Real estate</li></ul></div></div>
<!-- FEATURES (chatbot) -->
<section class="section" id="features">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">What the bot does</span>
      <h2>Appointments, food orders and one inbox for your team.</h2>
      <p>Everything runs inside the WhatsApp number your customers already message.</p>
    </div>
    <div class="feat-two">
      <article class="feat-card">
        <span class="eyebrow">Appointments</span>
        <h3>Bookings without a single phone call</h3>
        <p>Clinics, salons, tutors and offices: customers pick a service, a day and a free slot in the chat. You set your working hours once.</p>
        <div class="viz" data-viz="appt" aria-hidden="true"></div>
        <ul class="tick"><li><svg class="ic"><use href="#i-check"/></svg>Only open times are offered, no double bookings</li><li><svg class="ic"><use href="#i-check"/></svg>Confirmation and reminder in the same chat</li><li><svg class="ic"><use href="#i-check"/></svg>Every booking visible to your team in the inbox</li></ul>
      </article>
      <article class="feat-card">
        <span class="eyebrow">Food orders</span>
        <h3>Your menu, open 24/7 on WhatsApp</h3>
        <p>Restaurants and food shops show the menu by category, take items and quantities, and offer pickup or home delivery, from the number customers already message.</p>
        <div class="viz" data-viz="food" aria-hidden="true"></div>
        <ul class="tick"><li><svg class="ic"><use href="#i-check"/></svg>Menu by category, with prices</li><li><svg class="ic"><use href="#i-check"/></svg>Asks for the address for delivery orders</li><li><svg class="ic"><use href="#i-check"/></svg>Order number sent to customer and team</li></ul>
      </article>
    </div>
    <div class="section-head mt-l">
      <span class="eyebrow">What your team gets</span>
      <h2>One number. One inbox. The whole team.</h2>
    </div>
    <div class="feat-grid">
      <div><h4>Shared inbox</h4><p>Read and reply together, no passing one phone around.</p></div>
      <div><h4>AI assistant</h4><p>Replies from your services and policies when you switch it on.</p></div>
      <div><h4>Human handover</h4><p>Put the bot on hold and reply yourself when it matters.</p></div>
      <div><h4>Voice notes</h4><p>The bot understands voice messages on eligible plans.</p></div>
      <div><h4>Connect by QR</h4><p>Pair your number in a minute. Cloud API on eligible plans.</p></div>
      <div><h4>CSV export</h4><p>Take your contacts and orders out whenever you need.</p></div>
    </div>
  </div>
</section>

<!-- PLANS -->
<section class="section about" id="plans">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Plans</span>
      <h2>Simple monthly pricing</h2>
      <p>Pick the plan that fits your team. You can change plans later.</p>
    </div>
    <?php hnvl_render_plans(); ?>
  </div>
</section>

<!-- ABOUT -->
<section class="section about" id="about">
  <div class="wrap about-grid">
    <div>
      <div class="section-head tight">
        <span class="eyebrow">About Hasnivo Tech</span>
        <h2>AI automation that talks to your customers like your best employee.</h2>
      </div>
      <div class="about-copy">
        <p><strong>Hasnivo Tech is an AI automation and technology solutions provider.</strong> We set up WhatsApp AI chatbots and automation for businesses, so every customer message gets a quick, accurate reply.</p>
        <p>Most small businesses lose customers to slow answers: a message at night, a rush hour with no free hands, the same question asked fifty times. We take that load off your team and keep the conversation going until a sale, a booking or a handover to a person.</p>
        <dl class="glance">
          <div><dt>Who we are</dt><dd>Hasnivo Tech, an AI automation and technology solutions provider.</dd></div>
          <div><dt>What we build</dt><dd>WhatsApp AI chatbots, WhatsApp Business automation and AI customer support.</dd></div>
          <div><dt>Also offered</dt><dd>Lead generation and research, custom chatbot integration, SaaS solutions and API integration.</dd></div>
          <div><dt>Who it is for</dt><dd>Business owners who want customer messages answered quickly, at any hour.</dd></div>
        </dl>
      </div>
    </div>
    <div class="vm">
      <div class="vm-card"><span class="eyebrow">Vision</span><h3>Every business, always responsive</h3><p>A future where no customer waits for an answer, whatever the size of the business replying.</p></div>
      <div class="vm-card"><span class="eyebrow">Mission</span><h3>Make smart automation simple</h3><p>Give business owners practical AI tools they can start using quickly, without hiring a technical team.</p></div>
      <div class="vm-card"><span class="eyebrow">Commitment</span><h3>Your growth is the measure</h3><p>We design each solution around your workflow, then stay involved so it keeps working as your business changes.</p></div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="section" id="services">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Our Services</span>
      <h2>Everything you need to run conversations on autopilot.</h2>
      <p>From a single chatbot to a connected automation stack, we build what your business actually uses.</p>
    </div>
    <div class="svc-grid" id="svcGrid">
      <article class="svc wide"><span class="svc-no">01</span><div class="svc-icon"><svg class="ic"><use href="#i-chat"/></svg></div><h3>WhatsApp AI Chatbot Development</h3><p>Custom chatbots that understand your customers' questions, answer in their language, take orders and book appointments inside WhatsApp.</p><a class="more" href="<?php echo esc_url( home_url( '/#guides' ) ); ?>">How a chatbot works</a></article>
      <article class="svc"><span class="svc-no">02</span><div class="svc-icon"><svg class="ic"><use href="#i-bolt"/></svg></div><h3>WhatsApp Business Automation</h3><p>Automatic greetings, order confirmations, reminders and follow-ups that go out without anyone typing.</p></article>
      <article class="svc"><span class="svc-no">03</span><div class="svc-icon"><svg class="ic"><use href="#i-headset"/></svg></div><h3>AI Customer Support</h3><p>Instant answers to common questions, with a clean handover to your team when a person is needed.</p><a class="more" href="<?php echo esc_url( home_url( '/#faq' ) ); ?>">Read the FAQ</a></article>
      <article class="svc"><span class="svc-no">04</span><div class="svc-icon"><svg class="ic"><use href="#i-target"/></svg></div><h3>Lead Generation &amp; Research</h3><p>Capture enquiries, qualify them with a few smart questions and research prospects worth contacting.</p></article>
      <article class="svc"><span class="svc-no">05</span><div class="svc-icon"><svg class="ic"><use href="#i-cpu"/></svg></div><h3>AI Business Automation</h3><p>Replace repetitive manual tasks with AI workflows that save hours every week.</p></article>
      <article class="svc"><span class="svc-no">06</span><div class="svc-icon"><svg class="ic"><use href="#i-plug"/></svg></div><h3>Custom Chatbot Integration</h3><p>Add a chatbot to your existing website, app or tools instead of starting over.</p></article>
      <article class="svc wide"><span class="svc-no">07</span><div class="svc-icon"><svg class="ic"><use href="#i-api"/></svg></div><h3>SaaS Solutions &amp; API Integration</h3><p>Connect your bot to your CRM, spreadsheets, payment tools and internal systems, so conversations turn into records and actions automatically.</p><a class="more" href="<?php echo esc_url( home_url( '/#guides' ) ); ?>">Compare WhatsApp options</a></article>
    </div>
  </div>
</section>

<!-- WHY -->
<section class="section about" id="why">
  <div class="wrap why-grid">
    <div class="why-sticky">
      <div class="section-head">
        <span class="eyebrow">Why Choose Us</span>
        <h2>More replies. Less manual work.</h2>
        <p>Six reasons business owners put their customer conversations in our hands.</p>
        <a class="btn btn-ghost self-start" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Talk to us</a>
      </div>
    </div>
    <div class="why-list">
      <div class="why-item"><svg class="ic"><use href="#i-clock"/></svg><h3>24/7 Customer Support</h3><p>Customers get an answer at 2 PM or 2 AM, every day of the week.</p></div>
      <div class="why-item"><svg class="ic"><use href="#i-hourglass"/></svg><h3>Save Time</h3><p>Stop retyping the same prices, timings and directions all day.</p></div>
      <div class="why-item"><svg class="ic"><use href="#i-magnet"/></svg><h3>Smart Lead Generation</h3><p>Every new chat is captured, sorted and ready for follow-up.</p></div>
      <div class="why-item"><svg class="ic"><use href="#i-sliders"/></svg><h3>Customized Solutions</h3><p>Your tone, your products, your rules. No one-size-fits-all bot.</p></div>
      <div class="why-item"><svg class="ic"><use href="#i-heart"/></svg><h3>Better Engagement</h3><p>Fast, friendly replies keep customers talking and coming back.</p></div>
      <div class="why-item"><svg class="ic"><use href="#i-layers"/></svg><h3>Scalable Automation</h3><p>Start with one workflow and add more as your business grows.</p></div>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="section" id="process">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">How It Works</span>
      <h2>Live in three steps</h2>
    </div>
    <ol class="steps steps-3">
      <li class="step"><div class="step-n">1</div><h3>Request access</h3><p>Send the short form. We create your account and send a link to set your password.</p></li>
      <li class="step"><div class="step-n">2</div><h3>Connect your number</h3><p>Scan the QR code from your WhatsApp. That is it.</p></li>
      <li class="step"><div class="step-n">3</div><h3>Start replying</h3><p>Turn on appointments, the menu or the AI assistant.</p></li>
    </ol>
    <p class="center-cta"><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a></p>
  </div>
</section>

<!-- GUIDES -->
<section class="section" id="guides">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Guides</span>
      <h2>WhatsApp chatbots explained in plain language.</h2>
      <p>Short guides from the Hasnivo Tech team for business owners who are deciding where to start.</p>
    </div>
    <div class="guides-grid">
      <article class="guide">
        <span class="eyebrow">Guide 1</span>
        <h3>How a WhatsApp AI chatbot works</h3>
        <p>Every automated reply follows the same short path.</p>
        <ol>
          <li>A customer sends a message to your business number.</li>
          <li>WhatsApp passes the message to the chatbot.</li>
          <li>The bot reads it and checks your business information and rules.</li>
          <li>It sends a reply, usually within seconds.</li>
          <li>If needed, it records the order or lead, or alerts your team.</li>
        </ol>
      </article>
      <article class="guide">
        <span class="eyebrow">Guide 2</span>
        <h3>How your WhatsApp number connects</h3>
        <p><strong>Connect by QR code.</strong> You pair your own number by scanning a QR code from your WhatsApp, which takes about a minute.</p>
        <p><strong>Cloud API.</strong> The official WhatsApp Cloud API is available on eligible plans. Meta may charge for some message types on the official platform.</p>
      </article>
      <article class="guide">
        <span class="eyebrow">Guide 3</span>
        <h3>Five conversations worth automating first</h3>
        <ol>
          <li>Opening hours and location.</li>
          <li>Prices, menus and product details.</li>
          <li>Taking orders and checking order status.</li>
          <li>Booking appointments and sending reminders.</li>
          <li>Capturing the details of new enquiries.</li>
        </ol>
        <p>Start with the questions your team answers most often.</p>
      </article>
    </div>
    <p class="center-cta" style="margin-top:1.5rem"><a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Read all insights</a></p>
  </div>
</section>

<!-- FAQ -->
<section class="section about" id="faq">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">FAQ</span>
      <h2>Common questions</h2>
      <p>Straight answers to what business owners ask us first. Need something else? <a class="inline" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Ask us directly</a>.</p>
    </div>
    <div class="faq-list">
        <details class="faq-item" name="faq"><summary><h3>What is a WhatsApp AI chatbot?</h3></summary><p>It is software connected to your WhatsApp number that reads each customer message and replies automatically. With Hasnivo the bot can take appointments and food orders, answer from your own services and policies, reply in the language your customer writes in, and hand the chat to your team when a person is needed.</p></details>
        <details class="faq-item" name="faq"><summary><h3>How do I connect my WhatsApp number?</h3></summary><p>Request access with the short form. We create your account and send a link to set your password. Then you scan a QR code from your WhatsApp, which pairs your number in about a minute. The official Cloud API is available on eligible plans.</p></details>
        <details class="faq-item" name="faq"><summary><h3>How much does it cost?</h3></summary><p><?php echo esc_html( hnvl_plans_sentence() ); ?> See the <a class="inline" href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">Plans</a> section for what each includes. Some features depend on how your workspace is set up.</p></details>
        <details class="faq-item" name="faq"><summary><h3>Can my team reply too?</h3></summary><p>Yes. Your whole team shares one inbox on one number. With human handover you can put the bot on hold and reply yourself whenever it matters.</p></details>
        <details class="faq-item" name="faq"><summary><h3>Which businesses can use it?</h3></summary><p>Clinics, salons, tutors and offices use it for appointment booking. Restaurants and food shops use it to take orders with pickup or home delivery. See the pages for <a class="inline" href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-restaurants/' ) ); ?>">restaurants</a>, <a class="inline" href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-clinics/' ) ); ?>">clinics</a> and <a class="inline" href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-salons/' ) ); ?>">salons</a>. Any business that answers the same customer questions on WhatsApp again and again can benefit.</p></details>
        <details class="faq-item" name="faq"><summary><h3>Will the chatbot give wrong answers?</h3></summary><p>A chatbot can only be as good as the information it is given. The AI assistant replies from your own services and policies once you switch it on, and you can pause it and reply yourself at any time. For anything specific, our team is happy to help.</p></details>
    </div>
  </div>
</section>

<!-- CONTACT -->
<section class="section" id="contact">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Contact Us</span>
      <h2>Tell us about your business. We'll show you what a bot can take off your plate.</h2>
    </div>
    <div class="contact-card">
      <form class="contact-form" id="contactForm" novalidate>
        <h3>Start your project</h3>
        <div class="hp" aria-hidden="true"><label for="f-website">Leave this field empty</label><input id="f-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
        <div class="row">
          <div class="field" data-field="name">
            <label for="f-name">Name</label>
            <input id="f-name" name="name" type="text" maxlength="100" autocomplete="name" placeholder="Your full name" aria-describedby="e-name" required>
            <div class="err" id="e-name" role="alert"></div>
          </div>
          <div class="field" data-field="email">
            <label for="f-email">Email</label>
            <input id="f-email" name="email" type="email" maxlength="254" autocomplete="email" placeholder="you@company.com" aria-describedby="e-email" required>
            <div class="err" id="e-email" role="alert"></div>
          </div>
        </div>
        <div class="row">
          <div class="field" data-field="phone">
            <label for="f-phone">WhatsApp number</label>
            <input id="f-phone" name="phone" type="tel" maxlength="25" autocomplete="tel" placeholder="+92 300 0000000" aria-describedby="e-phone" required>
            <div class="err" id="e-phone" role="alert"></div>
          </div>
          <div class="field" data-field="service">
            <label for="f-service">Service required</label>
            <select id="f-service" name="service" aria-describedby="e-service" required>
              <option value="">Choose a service</option>
              <option>WhatsApp AI Chatbot Development</option>
              <option>WhatsApp Business Automation</option>
              <option>AI Customer Support Solutions</option>
              <option>Lead Generation &amp; Research</option>
              <option>AI Business Automation</option>
              <option>Custom Chatbot Integration</option>
              <option>SaaS Solutions &amp; API Integration</option>
              <option>Not sure yet</option>
            </select>
            <div class="err" id="e-service" role="alert"></div>
          </div>
        </div>
        <div class="field" data-field="message">
          <label for="f-message">Message</label>
          <textarea id="f-message" name="message" maxlength="2000" placeholder="What does your business do, and what should the bot handle?" aria-describedby="e-message" required></textarea>
          <div class="err" id="e-message" role="alert"></div>
        </div>
        <button class="btn btn-primary" type="submit">Send Enquiry</button>
        <div class="form-ok" id="formOk" tabindex="-1">
          <h4>Your enquiry is ready.</h4>
          <p>Choose how to send it. WhatsApp is the fastest way to reach us.</p>
          <div class="acts">
            <a class="btn btn-wa btn-sm" id="okWa" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" target="_blank" rel="noopener noreferrer"><svg class="ic"><use href="#i-wa"/></svg>Send on WhatsApp</a>
            <a class="btn btn-ghost btn-sm" id="okMail" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Send by Email</a>
            <button class="btn btn-ghost btn-sm" id="okCopy" type="button">Copy message</button>
          </div>
        </div>
      </form>

      <aside class="contact-side">
        <div>
          <h3>Prefer to talk now?</h3>
          <p class="mt-s">Message us directly and we'll reply as soon as we can.</p>
        </div>
        <?php if ( hnvl_opt( 'whatsapp' ) ) : ?>
        <a class="btn btn-wa" data-wa href="https://wa.me/<?php echo esc_attr( hnvl_sanitize_phone( hnvl_opt( 'whatsapp' ) ) ); ?>" target="_blank" rel="noopener noreferrer"><svg class="ic"><use href="#i-wa"/></svg>Chat on WhatsApp</a>
        <?php endif; ?>
        <div class="channel"><small>Email</small><a class="mail" data-mail href="mailto:<?php echo esc_attr( hnvl_opt( 'email' ) ); ?>"><?php echo esc_html( hnvl_opt( 'email' ) ); ?></a></div>
        <?php if ( hnvl_has_social() ) : ?>
        <div class="channel">
          <small>Follow us</small>
          <div class="socials">
            <?php if ( hnvl_social( 'facebook' ) ) : ?><a href="<?php echo esc_url( hnvl_social( 'facebook' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Hasnivo Tech on Facebook" data-social="facebook"><svg class="ic"><use href="#i-facebook"/></svg></a><?php endif; ?>
            <?php if ( hnvl_social( 'linkedin' ) ) : ?><a href="<?php echo esc_url( hnvl_social( 'linkedin' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Hasnivo Tech on LinkedIn" data-social="linkedin"><svg class="ic"><use href="#i-linkedin"/></svg></a><?php endif; ?>
            <?php if ( hnvl_social( 'instagram' ) ) : ?><a href="<?php echo esc_url( hnvl_social( 'instagram' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Hasnivo Tech on Instagram" data-social="instagram"><svg class="ic"><use href="#i-instagram"/></svg></a><?php endif; ?>
            <?php if ( hnvl_social( 'x' ) ) : ?><a href="<?php echo esc_url( hnvl_social( 'x' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Hasnivo Tech on X" data-social="x"><svg class="ic"><use href="#i-x"/></svg></a><?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </aside>
    </div>
  </div>
</section>
</main>
<?php
/**
 * Site footer.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<footer class="site-footer">
  <div class="wrap">
    <div class="foot-grid">
      <div>
        <a class="brand" href="<?php echo esc_url( home_url( '/#home' ) ); ?>" aria-label="Hasnivo Tech home">
          <svg width="38" height="38" viewBox="0 0 64 64" aria-hidden="true"><path d="M32 12V6" stroke="#25D6F0" stroke-width="3" stroke-linecap="round"/><circle cx="32" cy="4.6" r="3.4" fill="#25D6F0"/><rect x="2.5" y="26" width="7" height="12" rx="3" fill="#3B74FF"/><rect x="54.5" y="26" width="7" height="12" rx="3" fill="#8F5CFF"/><path d="M22 12H42A14 14 0 0 1 56 26V36A14 14 0 0 1 42 50H36L24 60V50H22A14 14 0 0 1 8 36V26A14 14 0 0 1 22 12z" fill="url(#lg)"/><rect x="15" y="20" width="34" height="23" rx="10" fill="#050A1A"/><circle cx="25" cy="29" r="3.9" fill="#25D6F0"/><circle cx="39" cy="29" r="3.9" fill="#25D6F0"/><circle cx="26.2" cy="27.8" r="1.1" fill="#fff"/><circle cx="40.2" cy="27.8" r="1.1" fill="#fff"/><path d="M27 36.2q5 3.2 10 0" stroke="#25D6F0" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg>
          <span class="brand-name">Hasnivo<small>TECH</small></span>
        </a>
        <p>Automate Conversations. Grow Your Business. Smart AI automation for modern businesses.</p>
      </div>
      <div>
        <h4>Quick links</h4>
        <ul>
          <li><a href="<?php echo esc_url( home_url( '/#home' ) ); ?>">Home</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">Plans</a></li>
          <li><a href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a></li>
          <li><a href="https://app.hasnivo.tech/login.php">Sign in</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#about' ) ); ?>">About</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">Services</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#why' ) ); ?>">Why Us</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#process' ) ); ?>">How It Works</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#guides' ) ); ?>">Guides</a></li>
          <li><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>">FAQ</a></li>
          <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Contact</a></li>
          <li><a href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-restaurants/' ) ); ?>">Chatbot for restaurants</a></li>
          <li><a href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-clinics/' ) ); ?>">Chatbot for clinics</a></li>
          <li><a href="<?php echo esc_url( home_url( '/whatsapp-chatbot-for-salons/' ) ); ?>">Chatbot for salons</a></li>
        </ul>
      </div>
      <div>
        <h4>Connect</h4>
        <ul>
          <?php if ( hnvl_opt( 'whatsapp' ) ) : ?><li><a data-wa href="https://wa.me/<?php echo esc_attr( hnvl_sanitize_phone( hnvl_opt( 'whatsapp' ) ) ); ?>" target="_blank" rel="noopener noreferrer">WhatsApp</a></li><?php endif; ?>
          <li><a data-mail href="mailto:<?php echo esc_attr( hnvl_opt( 'email' ) ); ?>"><?php echo esc_html( hnvl_opt( 'email' ) ); ?></a></li>
          <?php if ( hnvl_social( 'facebook' ) ) : ?><li><a href="<?php echo esc_url( hnvl_social( 'facebook' ) ); ?>" target="_blank" rel="noopener noreferrer" data-social="facebook">Facebook</a></li><?php endif; ?>
          <?php if ( hnvl_social( 'linkedin' ) ) : ?><li><a href="<?php echo esc_url( hnvl_social( 'linkedin' ) ); ?>" target="_blank" rel="noopener noreferrer" data-social="linkedin">LinkedIn</a></li><?php endif; ?>
          <?php if ( hnvl_social( 'instagram' ) ) : ?><li><a href="<?php echo esc_url( hnvl_social( 'instagram' ) ); ?>" target="_blank" rel="noopener noreferrer" data-social="instagram">Instagram</a></li><?php endif; ?>
        </ul>
      </div>
    </div>
    <div class="copyright"><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Hasnivo Tech. All rights reserved.</span><a href="<?php echo esc_url( home_url( '/#top' ) ); ?>">Back to top</a></div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
