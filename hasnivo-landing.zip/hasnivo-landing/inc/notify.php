<?php
/**
 * Request access extras:
 *  1. Every new access request is emailed to the owner (details + one-tap WhatsApp link).
 *  2. A "WhatsApp" button next to each request in the admin (list column + box on the edit screen).
 *  3. The thank-you message on the Request access page greets the visitor by first name.
 *
 * The old theme stores a request as a "hasnivo_request" post. The meta key names are not assumed:
 * fields are found by looking at the key names and values, and every readable field is emailed anyway.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Flattens a stored value (scalar, array or JSON text) into $out as key => string. */
function hnvl_req_flatten( $key, $val, &$out, $depth = 0 ) {
	if ( $depth > 2 ) {
		return;
	}
	if ( is_string( $val ) && strlen( $val ) > 1 && in_array( $val[0], array( '{', '[' ), true ) ) {
		$j = json_decode( $val, true );
		if ( is_array( $j ) ) {
			$val = $j;
		}
	}
	if ( is_array( $val ) ) {
		foreach ( $val as $k2 => $v2 ) {
			hnvl_req_flatten( is_string( $k2 ) ? $k2 : $key, $v2, $out, $depth + 1 );
		}
		return;
	}
	if ( is_scalar( $val ) && '' !== trim( (string) $val ) && ! isset( $out[ $key ] ) ) {
		$out[ $key ] = trim( (string) $val );
	}
}

/** All readable (non-underscore) meta of a request as key => value (arrays/JSON are opened up). */
function hnvl_req_fields( $post_id ) {
	$out = array();
	foreach ( (array) get_post_meta( $post_id ) as $k => $vals ) {
		// The old theme may keep its fields in "private" (underscore) meta; skip only WordPress/our own internals.
		if ( preg_match( '/^_(edit_|wp_|hnvl_|thumbnail_id|pingme|encloseme|oembed)/', $k ) ) {
			continue;
		}
		hnvl_req_flatten( $k, is_array( $vals ) && array_key_exists( 0, $vals ) && 1 === count( $vals ) ? $vals[0] : $vals, $out );
	}
	// Some themes keep the details as "Label: value" lines in the post body.
	$post = get_post( $post_id );
	if ( $post && ! empty( $post->post_content ) ) {
		foreach ( preg_split( '/\r?\n/', wp_strip_all_tags( $post->post_content ) ) as $line ) {
			if ( preg_match( '/^\s*([A-Za-z][A-Za-z _\-]{1,30})\s*:\s*(.+)$/', $line, $m ) && ! isset( $out[ trim( $m[1] ) ] ) ) {
				$out[ trim( $m[1] ) ] = trim( $m[2] );
			}
		}
	}
	return $out;
}

/** First value whose key matches $pattern (regex) and that is not empty. */
function hnvl_req_pick( $fields, $pattern, $not = '' ) {
	foreach ( $fields as $k => $v ) {
		if ( '' !== $v && preg_match( $pattern, $k ) && ( '' === $not || ! preg_match( $not, $k ) ) ) {
			return $v;
		}
	}
	return '';
}

/** Normalised view of a request: name, business, phone, email, plan, type, message, ref. */
function hnvl_req_info( $post_id ) {
	$f     = hnvl_req_fields( $post_id );
	$phone = hnvl_req_pick( $f, '/phone|whatsapp|mobile|number/i' );
	if ( '' === $phone ) {
		foreach ( $f as $v ) {
			if ( preg_match( '/^\+?[0-9][0-9 \-]{8,16}$/', $v ) ) {
				$phone = $v;
				break;
			}
		}
	}
	$email = hnvl_req_pick( $f, '/mail/i' );
	$ref   = hnvl_req_pick( $f, '/ref/i' );
	if ( '' === $ref ) {
		foreach ( $f as $v ) {
			if ( preg_match( '/^HN-\d+$/', $v ) ) {
				$ref = $v;
				break;
			}
		}
	}
	$title = (string) get_the_title( $post_id );
	$tname = trim( preg_split( '/\s+[\x{2013}-]\s+/u', $title )[0] );
	return array(
		'fields'   => $f,
		'name'     => '' !== hnvl_req_pick( $f, '/name/i', '/business|company|biz|shop/i' ) ? hnvl_req_pick( $f, '/name/i', '/business|company|biz|shop/i' ) : $tname,
		'business' => hnvl_req_pick( $f, '/business|company|biz|shop/i' ),
		'phone'    => $phone,
		'email'    => is_email( $email ) ? $email : '',
		'plan'     => hnvl_req_pick( $f, '/plan/i' ),
		'type'     => hnvl_req_pick( $f, '/type|categor|industry/i' ),
		'message'  => hnvl_req_pick( $f, '/message|note|detail/i' ),
		'ref'      => $ref,
	);
}

/** Pakistani number -> international digits for wa.me (03xx.. -> 923xx..). Returns '' when it does not look like a number. */
function hnvl_wa_digits( $raw ) {
	$d = preg_replace( '/\D+/', '', (string) $raw );
	if ( '' === $d ) {
		return '';
	}
	if ( 0 === strpos( $d, '0092' ) ) {
		$d = substr( $d, 2 );
	}
	if ( 0 === strpos( $d, '0' ) ) {
		$d = '92' . substr( $d, 1 );
	} elseif ( 10 === strlen( $d ) && 0 === strpos( $d, '3' ) ) {
		$d = '92' . $d;
	}
	return ( strlen( $d ) >= 11 && strlen( $d ) <= 15 ) ? $d : '';
}

/** wa.me link (with a short greeting) for a request, or '' when there is no usable number. */
function hnvl_wa_link( $post_id ) {
	$i = hnvl_req_info( $post_id );
	$d = hnvl_wa_digits( $i['phone'] );
	if ( '' === $d ) {
		return '';
	}
	$name = '' !== $i['name'] ? $i['name'] : '';
	$msg  = 'Assalam o Alaikum' . ( '' !== $name ? ' ' . $name : '' ) . ', Hasnivo Tech se baat kar raha hoon. Aap ki WhatsApp bot request' . ( '' !== $i['ref'] ? ' (' . $i['ref'] . ')' : '' ) . ' mil gayi hai. ';
	return 'https://wa.me/' . $d . '?text=' . rawurlencode( $msg );
}

/** True while someone is using the WordPress post editor (not for form posts, which the theme may route through admin-post.php). */
function hnvl_in_editor() {
	global $pagenow;
	return in_array( $pagenow, array( 'post.php', 'post-new.php', 'edit.php', 'import.php' ), true );
}

/* ---------- 1. Email the owner on every new request ---------- */

add_action(
	'save_post_hasnivo_request',
	function ( $post_id, $post, $update ) {
		if ( $update || hnvl_in_editor() || wp_is_post_revision( $post_id ) || 'publish' !== $post->post_status ) {
			return;
		}
		// Meta is written after the post row, so send when the request has finished (shutdown).
		add_action(
			'shutdown',
			function () use ( $post_id ) {
				hnvl_mail_request( $post_id );
			}
		);
	},
	10,
	3
);

function hnvl_mail_request( $post_id ) {
	if ( get_post_meta( $post_id, '_hnvl_mailed', true ) ) {
		return;
	}
	$i  = hnvl_req_info( $post_id );
	$to = sanitize_email( hnvl_opt( 'email' ) );
	if ( ! is_email( $to ) ) {
		return;
	}
	$one = function ( $s ) {
		return trim( preg_replace( '/[\r\n]+/', ' ', (string) $s ) );
	};
	$subject = 'New access request' . ( '' !== $i['ref'] ? ' ' . $one( $i['ref'] ) : '' ) . ( '' !== $i['name'] ? ' - ' . mb_substr( $one( $i['name'] ), 0, 60 ) : '' );
	$lines   = array();
	foreach ( $i['fields'] as $k => $v ) {
		$lines[] = ucfirst( str_replace( '_', ' ', ltrim( $k, '_' ) ) ) . ': ' . $v;
	}
	$wa   = hnvl_wa_link( $post_id );
	$body = implode( "\n", $lines ) . "\n\n";
	if ( '' !== $wa ) {
		$body .= "Reply on WhatsApp:\n" . $wa . "\n\n";
	}
	$body .= "Open in admin:\n" . admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' ) . "\n";
	$headers = array();
	if ( '' !== $i['email'] ) {
		$headers[] = 'Reply-To: ' . $one( $i['name'] ) . ' <' . $i['email'] . '>';
	}
	$ok = wp_mail( $to, $subject, $body, $headers );
	update_post_meta( $post_id, '_hnvl_mailed', $ok ? 'sent' : 'failed' );
}

/* ---------- 2. WhatsApp button in the admin ---------- */

add_filter(
	'manage_hasnivo_request_posts_columns',
	function ( $cols ) {
		$cols['hnvl_wa'] = 'Reply';
		return $cols;
	},
	99
);

add_action(
	'manage_hasnivo_request_posts_custom_column',
	function ( $col, $post_id ) {
		if ( 'hnvl_wa' !== $col ) {
			return;
		}
		$wa = hnvl_wa_link( $post_id );
		if ( '' === $wa ) {
			echo '<span style="color:#888">no number</span>';
			return;
		}
		echo '<a class="button button-primary" style="background:#25D366;border-color:#1da851;color:#04210f" target="_blank" rel="noopener noreferrer" href="' . esc_url( $wa ) . '">WhatsApp</a>';
		$m = get_post_meta( $post_id, '_hnvl_mailed', true );
		if ( 'failed' === $m ) {
			echo '<div style="color:#b32d2e;font-size:11px;margin-top:4px">email not delivered</div>';
		}
	},
	10,
	2
);

add_action(
	'add_meta_boxes_hasnivo_request',
	function () {
		add_meta_box(
			'hnvl_wa_box',
			'Reply to customer',
			function ( $post ) {
				$wa = hnvl_wa_link( $post->ID );
				if ( '' === $wa ) {
					echo '<p>No usable WhatsApp number found.</p>';
					echo '<p style="color:#999;font-size:11px">Fields read: ' . esc_html( implode( ', ', array_keys( hnvl_req_info( $post->ID )['fields'] ) ) ) . '</p>';
					return;
				}
				echo '<p><a class="button button-primary" style="background:#25D366;border-color:#1da851;color:#04210f" target="_blank" rel="noopener noreferrer" href="' . esc_url( $wa ) . '">Open WhatsApp chat</a></p>';
				$m = get_post_meta( $post->ID, '_hnvl_mailed', true );
				echo '<p style="color:#666;font-size:12px">Owner email: ' . esc_html( $m ? $m : 'not sent' ) . '</p>';
				echo '<p style="color:#999;font-size:11px">Fields read: ' . esc_html( implode( ', ', array_keys( hnvl_req_info( $post->ID )['fields'] ) ) ) . '</p>';
			},
			'hasnivo_request',
			'side',
			'high'
		);
	}
);

/* ---------- 3. "Thank you, <first name>!" on the Request access page ---------- */

add_action(
	'save_post_hasnivo_request',
	function ( $post_id, $post, $update ) {
		if ( $update || hnvl_in_editor() || headers_sent() ) {
			return;
		}
		$title = (string) $post->post_title;
		$name  = trim( preg_split( '/\s+[–-]\s+/u', $title )[0] );
		$name  = trim( strtok( $name, ' ' ) );
		if ( '' === $name ) {
			return;
		}
		$name = mb_substr( wp_strip_all_tags( $name ), 0, 30 );
		@setcookie( 'hnvl_thanks', rawurlencode( $name ), time() + 600, '/', '', is_ssl(), true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	},
	5,
	3
);

add_action(
	'template_redirect',
	function () {
		if ( is_admin() || ! isset( $_GET['sent'], $_GET['ref'] ) || empty( $_COOKIE['hnvl_thanks'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$name = sanitize_text_field( rawurldecode( wp_unslash( $_COOKIE['hnvl_thanks'] ) ) );
		$name = mb_substr( $name, 0, 30 );
		if ( '' === $name ) {
			return;
		}
		ob_start(
			function ( $html ) use ( $name ) {
				$new = 'Thank you, ' . esc_html( $name ) . '!';
				return preg_replace( '/Thank you!/', $new, $html, 1 );
			}
		);
	},
	1
);
