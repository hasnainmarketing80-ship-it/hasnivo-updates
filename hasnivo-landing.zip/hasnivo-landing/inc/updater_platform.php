<?php
/**
 * Companion updater: keeps the "Hasnivo Platform" plugin up to date from the same
 * public GitHub folder as Hasnivo Landing. Same safety rule: the zip is installed
 * only if its SHA-256 matches platform-version.json.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const HNVP_BASENAME = 'hasnivo-platform/hasnivo-platform.php';

function hnvp_zip_url() {
	return HNVL_UPDATE_URL . 'hasnivo-platform.zip';
}

function hnvp_installed_version() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$all = get_plugins();
	return isset( $all[ HNVP_BASENAME ] ) ? $all[ HNVP_BASENAME ]['Version'] : '';
}

function hnvp_update_info( $force = false ) {
	$cached = get_transient( 'hnvp_upd_info' );
	if ( ! $force && is_array( $cached ) ) {
		return $cached;
	}
	$info = array();
	$res  = wp_remote_get( HNVL_UPDATE_URL . 'platform-version.json', array( 'timeout' => 10 ) );
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$d = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $d ) && isset( $d['version'], $d['sha256'] ) && preg_match( '/^\d+\.\d+\.\d+$/', $d['version'] ) && preg_match( '/^[a-f0-9]{64}$/i', $d['sha256'] ) ) {
			$info = array( 'version' => $d['version'], 'sha256' => strtolower( $d['sha256'] ) );
		}
	}
	set_transient( 'hnvp_upd_info', $info, $info ? 30 * MINUTE_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
	return $info;
}

add_filter(
	'pre_set_site_transient_update_plugins',
	function ( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$cur  = hnvp_installed_version();
		$info = $cur ? hnvp_update_info() : array();
		if ( $info && version_compare( $info['version'], $cur, '>' ) ) {
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			$transient->response[ HNVP_BASENAME ] = (object) array(
				'id'          => 'hasnivo-platform',
				'slug'        => 'hasnivo-platform',
				'plugin'      => HNVP_BASENAME,
				'new_version' => $info['version'],
				'url'         => 'https://hasnivo.tech/',
				'package'     => hnvp_zip_url(),
			);
		}
		return $transient;
	}
);

add_filter(
	'auto_update_plugin',
	function ( $update, $item ) {
		return ( isset( $item->plugin ) && HNVP_BASENAME === $item->plugin ) ? true : $update;
	},
	10,
	2
);

add_filter(
	'upgrader_pre_download',
	function ( $reply, $package ) {
		if ( hnvp_zip_url() !== $package ) {
			return $reply;
		}
		$info = hnvp_update_info( true );
		if ( ! $info ) {
			return new WP_Error( 'hnvp_info', 'Hasnivo Platform update info is not available right now.' );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		if ( ! hash_equals( $info['sha256'], strtolower( (string) hash_file( 'sha256', $tmp ) ) ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'hnvp_hash', 'Hasnivo Platform update failed the checksum test, so it was not installed.' );
		}
		return $tmp;
	},
	10,
	2
);

// The existing hourly Landing check also refreshes this one.
add_action(
	'hnvl_selfupdate',
	function () {
		delete_transient( 'hnvp_upd_info' );
	},
	5
);
