<?php
/**
 * Chat Knowledge: lets the site owner add and edit the chat assistant's answers from the WordPress admin.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const HNVL_KB_OPTION = 'hnvl_kb';
const HNVL_KB_MAX    = 100;

/** Clean the submitted rows. Pure function: used on save and in tests. */
function hnvl_kb_sanitize( $raw ) {
	$out = array();
	if ( ! is_array( $raw ) ) {
		return $out;
	}
	foreach ( $raw as $row ) {
		if ( ! is_array( $row ) || count( $out ) >= HNVL_KB_MAX ) {
			continue;
		}
		$keys = array();
		$kw   = isset( $row['k'] ) ? sanitize_text_field( (string) $row['k'] ) : '';
		foreach ( explode( ',', $kw ) as $k ) {
			$k = trim( strtolower( preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', $k ) ) );
			$k = trim( preg_replace( '/\s+/', ' ', $k ) );
			if ( '' !== $k && mb_strlen( $k ) <= 40 ) {
				$keys[] = $k;
			}
		}
		$keys = array_slice( array_values( array_unique( $keys ) ), 0, 20 );
		$en   = isset( $row['a'] ) ? mb_substr( sanitize_textarea_field( (string) $row['a'] ), 0, 1200 ) : '';
		$ur   = isset( $row['u'] ) ? mb_substr( sanitize_textarea_field( (string) $row['u'] ), 0, 1200 ) : '';
		if ( ! $keys || ( '' === $en && '' === $ur ) ) {
			continue; // a row needs at least one keyword and one answer
		}
		$label = isset( $row['bl'] ) ? mb_substr( sanitize_text_field( (string) $row['bl'] ), 0, 40 ) : '';
		$href  = isset( $row['bu'] ) ? trim( (string) $row['bu'] ) : '';
		if ( '' !== $href && 0 === strpos( $href, '/' ) && 0 !== strpos( $href, '//' ) ) {
			$href = home_url( $href );
		}
		$href = esc_url_raw( $href, array( 'http', 'https', 'mailto' ) );
		if ( '' === $label || '' === $href ) {
			$label = '';
			$href  = '';
		}
		$out[] = array(
			'k'  => implode( ', ', $keys ),
			'a'  => $en,
			'u'  => $ur,
			'bl' => $label,
			'bu' => $href,
		);
	}
	return $out;
}

function hnvl_kb_get() {
	$v = get_option( HNVL_KB_OPTION, array() );
	return is_array( $v ) ? hnvl_kb_sanitize( $v ) : array();
}

/** Same data in the shape chat.js reads. */
function hnvl_kb_for_js() {
	$out = array();
	foreach ( hnvl_kb_get() as $r ) {
		$en    = '' !== $r['a'] ? $r['a'] : $r['u'];
		$ur    = '' !== $r['u'] ? $r['u'] : $r['a'];
		$entry = array(
			'k'  => array_map( 'trim', explode( ',', $r['k'] ) ),
			'en' => $en,
			'ur' => $ur,
		);
		if ( '' !== $r['bl'] ) {
			$entry['a'] = array( array( 'label' => $r['bl'], 'href' => $r['bu'] ) );
		}
		$out[] = $entry;
	}
	return $out;
}

// Hand the owner's answers to the chat widget as inert JSON (a data block is not executed, so a strict CSP is unaffected).
add_action( 'wp_footer', 'hnvl_print_kb', 5 );
function hnvl_print_kb() {
	if ( ! hnvl_is_landing() ) {
		return;
	}
	echo '<script type="application/json" id="hnvl-kb">' . wp_json_encode( hnvl_kb_for_js(), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>' . "\n";
}

/** Owner's answers as extra facts for the optional AI mode. */
function hnvl_kb_prompt_text() {
	$lines = array();
	foreach ( hnvl_kb_get() as $r ) {
		$ans     = '' !== $r['a'] ? $r['a'] : $r['u'];
		$lines[] = '- When asked about (' . $r['k'] . '): ' . str_replace( array( "\r", "\n" ), ' ', $ans );
	}
	return $lines ? "\nOWNER-ADDED ANSWERS (authoritative, you may use them):\n" . implode( "\n", $lines ) . "\n" : '';
}

/* ---------------------------------------------------------------------------
 * Admin page
 * ------------------------------------------------------------------------- */

add_action( 'admin_menu', 'hnvl_kb_menu' );
function hnvl_kb_menu() {
	add_menu_page( 'Chat Knowledge', 'Chat Knowledge', 'manage_options', 'hnvl-kb', 'hnvl_kb_page', 'dashicons-format-chat', 27 );
}

add_action( 'admin_enqueue_scripts', 'hnvl_kb_admin_assets' );
function hnvl_kb_admin_assets( $hook ) {
	if ( 'toplevel_page_hnvl-kb' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'hnvl-kb-admin', HNVL_URL . 'assets/admin.css', array(), HNVL_VERSION );
	wp_enqueue_script( 'hnvl-kb-admin', HNVL_URL . 'assets/admin.js', array(), HNVL_VERSION, true );
}

add_action( 'admin_post_hnvl_save_kb', 'hnvl_kb_save' );
function hnvl_kb_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', 403 );
	}
	check_admin_referer( 'hnvl_save_kb' );
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$raw = isset( $_POST['kb'] ) ? wp_unslash( $_POST['kb'] ) : array();
	update_option( HNVL_KB_OPTION, hnvl_kb_sanitize( $raw ), false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'hnvl-kb', 'saved' => '1' ), admin_url( 'admin.php' ) ) );
	exit;
}

function hnvl_kb_row( $i, $r ) {
	$f = function ( $name, $val, $type = 'input', $ph = '', $rows = 4 ) use ( $i ) {
		$n = 'kb[' . $i . '][' . $name . ']';
		if ( 'textarea' === $type ) {
			return '<textarea name="' . esc_attr( $n ) . '" rows="' . (int) $rows . '" maxlength="1200" placeholder="' . esc_attr( $ph ) . '">' . esc_textarea( $val ) . '</textarea>';
		}
		return '<input type="text" name="' . esc_attr( $n ) . '" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $ph ) . '">';
	};
	?>
	<div class="hnvl-row">
		<div class="hnvl-row-head"><strong class="hnvl-no"></strong><button type="button" class="button-link-delete hnvl-del">Delete this answer</button></div>
		<label>1. Customer yeh alfaaz likhe to jawab dein <small>(comma se alag, jitne chahein)</small>
			<?php echo $f( 'k', $r['k'], 'input', 'refund, paisay wapis, money back' ); // phpcs:ignore ?>
		</label>
		<label>2. Jawab (English ya Roman Urdu)
			<?php echo $f( 'a', $r['a'], 'textarea', 'Example: Refund policy yeh hai...' ); // phpcs:ignore ?>
		</label>
		<label>3. Urdu wala alag jawab <small>(optional, khali chhorein to upar wala hi dikhega)</small>
			<?php echo $f( 'u', $r['u'], 'textarea', '', 3 ); // phpcs:ignore ?>
		</label>
		<div class="hnvl-two">
			<label>Button ka naam <small>(optional)</small><?php echo $f( 'bl', $r['bl'], 'input', 'Send us a message' ); // phpcs:ignore ?></label>
			<label>Button kahan jaye <small>(link, jaise https://wa.me/923216740220 ya /request-access/)</small><?php echo $f( 'bu', $r['bu'], 'input', 'https://' ); // phpcs:ignore ?></label>
		</div>
	</div>
	<?php
}

function hnvl_kb_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$rows = hnvl_kb_get();
	$blank = array( 'k' => '', 'a' => '', 'u' => '', 'bl' => '', 'bu' => '' );
	?>
	<div class="wrap hnvl-wrap">
		<h1>Chat Knowledge</h1>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success is-dismissible"><p>Save ho gaya. Ab website ka chat assistant yeh jawab dega.</p></div>
		<?php endif; ?>
		<p class="hnvl-lead">Yahan aap chat assistant ko apni information dete hain. <strong>Sawal ke alfaaz</strong> aur <strong>jawab</strong> likhein, Save karein, bas. Jab koi customer un alfaaz mein se kuch likhta hai, assistant aap ka likha hua jawab dega. Aap ke jawab hamesha built-in jawabon se pehle dekhe jate hain.</p>
		<details class="hnvl-built"><summary>Assistant pehle se kya jaanta hai?</summary>
			<p>Plans aur prices, appointments, food orders, team inbox, voice notes, QR se connect, shuru karne ke 3 steps, services, payment ka step, sign in aur contact. Inke ilawa kuch (jaise refund, delivery ka waqt, discount, office ka address) aap yahan add karein. Jo information aap nahi dete, assistant woh nahi banata.</p>
		</details>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="hnvl-kb-form">
			<input type="hidden" name="action" value="hnvl_save_kb">
			<?php wp_nonce_field( 'hnvl_save_kb' ); ?>
			<div id="hnvl-rows">
				<?php foreach ( $rows as $i => $r ) { hnvl_kb_row( $i, $r ); } ?>
			</div>
			<p class="hnvl-empty" id="hnvl-empty"<?php echo $rows ? ' hidden' : ''; ?>>Abhi koi jawab add nahi hua. Neeche "Naya jawab add karein" dabayein.</p>
			<template id="hnvl-tpl"><?php hnvl_kb_row( '__i__', $blank ); ?></template>
			<p class="hnvl-actions">
				<button type="button" class="button button-secondary" id="hnvl-add">+ Naya jawab add karein</button>
				<button type="submit" class="button button-primary button-large">Save karein</button>
			</p>
		</form>
	</div>
	<?php
}
