<?php
/**
 * Self-updater for Hasnivo Landing.
 *
 * Checks a small public file on GitHub (version.json) and, when a newer version
 * is published, WordPress installs it by itself. The zip is only installed when
 * its SHA-256 matches the value in version.json.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'HNVL_UPDATE_URL' ) ) {
	define( 'HNVL_UPDATE_URL', 'https://raw.githubusercontent.com/hasnainmarketing80-ship-it/hasnivo-updates/main/' );
}

function hnvl_upd_basename() {
	return plugin_basename( HNVL_DIR . 'hasnivo-landing.php' );
}

function hnvl_upd_zip_url() {
	return HNVL_UPDATE_URL . 'hasnivo-landing.zip';
}

/** Latest published version info: [ 'version' => 'x.y.z', 'sha256' => '...' ] or []. */
function hnvl_update_info( $force = false ) {
	$cached = get_transient( 'hnvl_upd_info' );
	if ( ! $force && is_array( $cached ) ) {
		return $cached;
	}
	$info = array();
	$res  = wp_remote_get( HNVL_UPDATE_URL . 'version.json', array( 'timeout' => 10 ) );
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$d = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $d )
			&& isset( $d['version'], $d['sha256'] )
			&& preg_match( '/^\d+\.\d+\.\d+$/', $d['version'] )
			&& preg_match( '/^[a-f0-9]{64}$/i', $d['sha256'] ) ) {
			$info = array(
				'version' => $d['version'],
				'sha256'  => strtolower( $d['sha256'] ),
			);
		}
	}
	set_transient( 'hnvl_upd_info', $info, $info ? 30 * MINUTE_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
	return $info;
}

// Tell WordPress an update exists.
add_filter(
	'pre_set_site_transient_update_plugins',
	function ( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = hnvl_update_info();
		if ( $info && version_compare( $info['version'], HNVL_VERSION, '>' ) ) {
			$base = hnvl_upd_basename();
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			$transient->response[ $base ] = (object) array(
				'id'          => 'hasnivo-landing',
				'slug'        => 'hasnivo-landing',
				'plugin'      => $base,
				'new_version' => $info['version'],
				'url'         => 'https://hasnivo.tech/',
				'package'     => hnvl_upd_zip_url(),
			);
		}
		return $transient;
	}
);

// Install it automatically.
add_filter(
	'auto_update_plugin',
	function ( $update, $item ) {
		if ( isset( $item->plugin ) && hnvl_upd_basename() === $item->plugin ) {
			return true;
		}
		return $update;
	},
	10,
	2
);

// Refuse any zip whose checksum does not match version.json.
add_filter(
	'upgrader_pre_download',
	function ( $reply, $package ) {
		if ( hnvl_upd_zip_url() !== $package ) {
			return $reply;
		}
		$info = hnvl_update_info( true );
		if ( ! $info ) {
			return new WP_Error( 'hnvl_upd_info', 'Hasnivo update info is not available right now.' );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		if ( ! hash_equals( $info['sha256'], strtolower( (string) hash_file( 'sha256', $tmp ) ) ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'hnvl_upd_hash', 'Hasnivo update failed the checksum test, so it was not installed.' );
		}
		return $tmp;
	},
	10,
	2
);

// Hourly: look for a new version and let WordPress install it.
add_action(
	'init',
	function () {
		if ( ! wp_next_scheduled( 'hnvl_selfupdate' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'hnvl_selfupdate' );
		}
	}
);

function hnvl_run_update_check() {
	delete_transient( 'hnvl_upd_info' );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();
}

add_action(
	'hnvl_selfupdate',
	function () {
		hnvl_run_update_check();
		do_action( 'wp_maybe_auto_update' );
	}
);

// "Check for updates" link on the Plugins screen (manual fallback).
add_filter(
	'plugin_action_links_' . plugin_basename( HNVL_DIR . 'hasnivo-landing.php' ),
	function ( $links ) {
		if ( current_user_can( 'update_plugins' ) ) {
			$url   = wp_nonce_url( admin_url( 'admin-post.php?action=hnvl_check_update' ), 'hnvl_check_update' );
			$links = array_merge( array( '<a href="' . esc_url( $url ) . '">Check for updates</a>' ), $links );
		}
		return $links;
	}
);

add_action(
	'admin_post_hnvl_check_update',
	function () {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'hnvl_check_update' );
		hnvl_run_update_check();
		wp_safe_redirect( admin_url( 'plugins.php' ) );
		exit;
	}
);
