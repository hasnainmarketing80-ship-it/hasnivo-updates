<?php
/**
 * Industry landing pages for search: restaurants, clinics, salons.
 * Served by the plugin itself at fixed addresses (no page needs to be created in WordPress).
 * Deactivating the plugin removes them.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hnvl_verticals() {
	return array(
		'restaurants' => array(
			'path'    => '/whatsapp-chatbot-for-restaurants/',
			'name'    => 'Restaurants and food shops',
			'title'   => 'WhatsApp Chatbot for Restaurants in Pakistan | Hasnivo Tech',
			'desc'    => 'A WhatsApp AI chatbot for restaurants and food shops in Pakistan. It sends your menu, takes orders for pickup or home delivery and gives every order a number. Replies in your customer\'s language.',
			'h1'      => 'WhatsApp Chatbot for Restaurants in Pakistan',
			'lead'    => 'Customers message you on WhatsApp to ask the menu, the price and whether you deliver. The bot answers at once, takes the order and hands your kitchen a clean order with a number, even during the dinner rush.',
			'pain'    => array(
				array( 'Menu questions all day', 'The same "send me the menu" and "what is the price" arrive again and again. The bot sends the menu by category and the prices every time.' ),
				array( 'Orders lost in the rush', 'When the phone is busy, messages go unanswered and the customer orders elsewhere. The bot replies in seconds, whatever the hour.' ),
				array( 'Mixed-up orders', 'Orders typed in a hurry get items and addresses wrong. The bot collects items, quantity, pickup or delivery and the address in a fixed order.' ),
			),
			'steps'   => array(
				array( 'Customer says hello', 'The bot greets in the customer\'s language and shows your menu by category with prices.' ),
				array( 'Order is built in chat', 'The customer picks items and quantity, then chooses pickup or home delivery and shares the address.' ),
				array( 'Your team gets the order', 'The order appears in your shared inbox with an order number the customer also receives.' ),
			),
			'chat'    => array(
				array( 'c', 'Hi, can you send me the menu?' ),
				array( 'b', 'Hello! Here is our menu: Zinger Burger Rs 450, Chicken Biryani Rs 380, Aloo Biryani Rs 280. What would you like to order?' ),
				array( 'c', '2 chicken biryani, delivery please' ),
				array( 'b', 'Sure: 2 x Chicken Biryani = Rs 760. Please send your address and I will confirm the order.' ),
			),
			'faq'     => array(
				array( 'Can a WhatsApp chatbot take food orders?', 'Yes. The bot shows the menu by category, collects the items and quantity, asks for pickup or home delivery, and gives the customer and your team an order number. Your team can take over any chat at any time.' ),
				array( 'Does it reply in my customers\' language?', 'Yes. Customers can write in Urdu, English or another language and the bot answers in the same language.' ),
				array( 'Do I need a new WhatsApp number?', 'No. You connect your existing business number by scanning a QR code, which takes about a minute. The official Cloud API is available on eligible plans.' ),
				array( 'How much does a restaurant WhatsApp bot cost?', 'See the plans page for current monthly prices in rupees. You can request access and try it first.' ),
			),
		),
		'clinics'     => array(
			'path'    => '/whatsapp-chatbot-for-clinics/',
			'name'    => 'Clinics and doctors',
			'title'   => 'WhatsApp Appointment Booking Bot for Clinics in Pakistan | Hasnivo Tech',
			'desc'    => 'A WhatsApp AI chatbot for clinics and doctors in Pakistan. Patients pick a day and a free slot, get a confirmation and a reminder, and your staff stop answering the same questions. Urdu and English.',
			'h1'      => 'WhatsApp Appointment Booking Chatbot for Clinics',
			'lead'    => 'Patients ask for timings, fees and a free slot all day. The bot answers from your own details, books the appointment in the chat and sends a confirmation and a reminder, so reception can focus on the people in front of them.',
			'pain'    => array(
				array( 'Phone never stops ringing', 'Questions about timings, fees and the doctor\'s availability fill the day. The bot answers them from the details you give it.' ),
				array( 'No-shows and double bookings', 'Patients forget, and slots get booked twice by hand. The bot offers only free slots and sends a reminder in the same chat.' ),
				array( 'After-hours messages', 'Patients write at night and wait until morning. The bot replies at once and books the next free slot.' ),
			),
			'steps'   => array(
				array( 'Patient asks for an appointment', 'The bot asks which service or doctor, and which day suits.' ),
				array( 'A free slot is chosen', 'Only open slots are shown. The patient picks one and receives a confirmation in the chat.' ),
				array( 'Reminder and handover', 'A reminder follows in the same chat. For anything medical or unusual, your staff take over the conversation.' ),
			),
			'chat'    => array(
				array( 'c', 'Is the doctor available tomorrow?' ),
				array( 'b', 'Yes, tomorrow\'s free slots are 5:00 PM, 5:30 PM and 6:00 PM. Which one should I book?' ),
				array( 'c', '5:30 PM' ),
				array( 'b', 'Your appointment is booked for tomorrow at 5:30 PM. We will remind you before the visit.' ),
			),
			'faq'     => array(
				array( 'Can a WhatsApp bot book doctor appointments?', 'Yes. The bot offers free slots for the day the patient chooses, books the one they pick and sends a confirmation and a reminder in the same chat.' ),
				array( 'Does the bot give medical advice?', 'No. It answers questions about timings, fees, services and location from the details you provide, and hands any medical or unusual question to your staff.' ),
				array( 'Can my reception team reply as well?', 'Yes. The whole team shares one inbox on one number, and anyone can put the bot on hold and reply personally.' ),
				array( 'Does it reply in my patients\' language?', 'Yes. Patients can write in Urdu, English or another language and the bot answers in the same language.' ),
			),
		),
		'salons'      => array(
			'path'    => '/whatsapp-chatbot-for-salons/',
			'name'    => 'Salons and parlours',
			'title'   => 'WhatsApp Booking Bot for Salons and Parlours in Pakistan | Hasnivo Tech',
			'desc'    => 'A WhatsApp AI chatbot for salons and beauty parlours in Pakistan. It shares your services and prices, books appointments and sends reminders, in your clients\' own language.',
			'h1'      => 'WhatsApp Booking Chatbot for Salons and Parlours',
			'lead'    => 'Clients ask for your services, prices and a time that suits them, often while your team has their hands full. The bot answers instantly, books the slot and reminds the client before the visit.',
			'pain'    => array(
				array( 'Hands busy, phone buzzing', 'You cannot type with a client in the chair. The bot replies to rate and service questions for you.' ),
				array( 'Empty slots, late replies', 'A client who waits for an answer books somewhere else. The bot replies in seconds and fills open slots.' ),
				array( 'Forgotten appointments', 'Reminders sent by hand get skipped. The bot sends them in the same chat automatically.' ),
			),
			'steps'   => array(
				array( 'Client asks about a service', 'The bot shares your services and prices and asks what she would like to book.' ),
				array( 'Day and slot are picked', 'Open slots are shown. The client chooses one and gets a confirmation.' ),
				array( 'Reminder before the visit', 'A reminder arrives in the same chat. Your team can step in whenever a personal reply is better.' ),
			),
			'chat'    => array(
				array( 'c', 'How much is bridal makeup?' ),
				array( 'b', 'Here are the bridal makeup details and price. Which day would you like to book?' ),
				array( 'c', 'Sunday' ),
				array( 'b', 'Free slots on Sunday: 11:00 AM, 1:00 PM and 3:00 PM. Which one should I book?' ),
			),
			'faq'     => array(
				array( 'Can a WhatsApp chatbot book salon appointments?', 'Yes. The bot shares your services, offers free slots, books the chosen one and sends a reminder in the same chat.' ),
				array( 'Will it answer questions about prices?', 'Yes, from the service and price details you give it. For anything it does not know, your team can reply personally.' ),
				array( 'Can I use my existing WhatsApp number?', 'Yes. You connect it by scanning a QR code, which takes about a minute.' ),
				array( 'Does it reply in my clients\' language?', 'Yes. Clients can write in Urdu, English or another language and the bot answers in the same language.' ),
			),
		),
	);
}

/** Which vertical (if any) is being requested. */
function hnvl_vertical_key() {
	if ( is_admin() ) {
		return '';
	}
	$p = trailingslashit( hnvl_request_path() );
	foreach ( hnvl_verticals() as $k => $v ) {
		if ( $p === $v['path'] ) {
			return $k;
		}
	}
	return '';
}

add_filter(
	'hnvl_sitemap_urls',
	function ( $urls ) {
		foreach ( hnvl_verticals() as $v ) {
			$urls[] = array( home_url( $v['path'] ), '0.7' );
		}
		return $urls;
	}
);

add_action( 'template_redirect', 'hnvl_render_vertical', 2 );
function hnvl_render_vertical() {
	$key = hnvl_vertical_key();
	if ( '' === $key ) {
		return;
	}
	$all = hnvl_verticals();
	$v   = $all[ $key ];
	$url = home_url( $v['path'] );
	$img = HNVL_URL . 'assets/og-image.png';
	$org = home_url( '/' ) . '#organization';
	$ver = HNVL_VERSION . '.' . (int) @filemtime( HNVL_DIR . 'assets/style.css' );
	$cfg = array(
		'whatsapp'  => hnvl_sanitize_phone( hnvl_opt( 'whatsapp' ) ),
		'email'     => sanitize_email( hnvl_opt( 'email' ) ),
		'social'    => array(),
		'ga4Id'     => hnvl_sanitize_ga4( hnvl_opt( 'ga4' ) ),
		'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
		'siteUrl'   => home_url( '/' ),
		'aiEnabled' => false,
	);

	$faq_ld = array();
	foreach ( $v['faq'] as $f ) {
		$faq_ld[] = array(
			'@type'          => 'Question',
			'name'           => $f[0],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ),
		);
	}
	$graph = array(
		array(
			'@type'    => 'BreadcrumbList',
			'itemListElement' => array(
				array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Hasnivo Tech', 'item' => home_url( '/' ) ),
				array( '@type' => 'ListItem', 'position' => 2, 'name' => $v['h1'], 'item' => $url ),
			),
		),
		array(
			'@type'       => 'Service',
			'name'        => $v['h1'],
			'description' => $v['desc'],
			'serviceType' => 'WhatsApp AI chatbot',
			'areaServed'  => array( '@type' => 'Country', 'name' => 'Pakistan' ),
			'url'         => $url,
			'provider'    => array( '@type' => 'Organization', '@id' => $org, 'name' => 'Hasnivo Tech', 'url' => home_url( '/' ) ),
		),
		array(
			'@type'      => 'FAQPage',
			'mainEntity' => $faq_ld,
		),
	);

	status_header( 200 );
	nocache_headers();
	header( 'Content-Type: text/html; charset=UTF-8' );
	header( 'Cache-Control: public, max-age=300' );
	$e = 'esc_html';
	?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#060A18">
<meta name="color-scheme" content="dark">
<title><?php echo esc_html( $v['title'] ); ?></title>
<meta name="description" content="<?php echo esc_attr( $v['desc'] ); ?>">
<link rel="canonical" href="<?php echo esc_url( $url ); ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Hasnivo Tech">
<meta property="og:title" content="<?php echo esc_attr( $v['title'] ); ?>">
<meta property="og:description" content="<?php echo esc_attr( $v['desc'] ); ?>">
<meta property="og:url" content="<?php echo esc_url( $url ); ?>">
<meta property="og:image" content="<?php echo esc_url( $img ); ?>">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="<?php echo esc_url( HNVL_URL . 'assets/favicon.svg' ); ?>" type="image/svg+xml">
<link rel="icon" href="<?php echo esc_url( HNVL_URL . 'assets/logo-512.png' ); ?>" type="image/png" sizes="512x512">
<meta name="hasnivo-config" content="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,700;12..96,800&amp;family=DM+Sans:wght@400;500;700&amp;family=JetBrains+Mono:wght@500&amp;display=swap">
<link rel="stylesheet" href="<?php echo esc_url( HNVL_URL . 'assets/style.css?ver=' . $ver ); ?>">
<style>
.vt-hero{padding:clamp(7rem,14vw,10rem) 0 3rem}.vt-hero h1{font-family:'Bricolage Grotesque',sans-serif;font-size:clamp(2rem,5.2vw,3.6rem);line-height:1.08;margin:.6rem 0 1rem;max-width:20ch}
.vt-crumb{font-size:.85rem;opacity:.7}.vt-crumb a{color:inherit}.vt-cards{display:grid;gap:1rem;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));margin-top:1.5rem}
.vt-card{border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);border-radius:16px;padding:1.2rem}.vt-card h3{margin:.1rem 0 .5rem;font-size:1.05rem}.vt-card p{margin:0;opacity:.85}
.vt-chat{max-width:440px;margin:1.5rem auto 0;border:1px solid rgba(255,255,255,.12);border-radius:20px;padding:1rem;background:#0b1220;display:flex;flex-direction:column;gap:.5rem}
.vt-m{max-width:85%;padding:.55rem .8rem;border-radius:12px;font-size:.95rem;line-height:1.4}.vt-m.c{align-self:flex-end;background:#075e54;color:#fff}.vt-m.b{align-self:flex-start;background:#1f2c34;color:#e9edef}
.vt-more{display:flex;gap:.7rem;flex-wrap:wrap;margin-top:1rem}.vt-more a{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:.45rem .9rem;text-decoration:none;color:inherit}
.vt-sec{padding:2.5rem 0}.vt-sec h2{font-family:'Bricolage Grotesque',sans-serif;font-size:clamp(1.5rem,3.4vw,2.2rem);margin:.3rem 0 .6rem}
</style>
<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); // phpcs:ignore ?></script>
</head>
<body class="hnvl-vertical">
<svg class="sprite" width="0" height="0" aria-hidden="true" focusable="false"><symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol><symbol id="i-close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol></svg>
<header class="site-header" id="top">
  <div class="wrap nav">
    <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Hasnivo Tech home"><span class="brand-name">Hasnivo<small>TECH</small></span></a>
    <ul class="nav-links" id="navLinks">
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#features' ) ); ?>">Features</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">Plans</a></li>
      <li><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>">FAQ</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Contact</a></li>
    </ul>
    <div class="nav-cta">
      <a class="btn btn-primary btn-sm" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
      <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navLinks" aria-label="Open menu"><svg class="ic"><use href="#i-menu"/></svg></button>
    </div>
  </div>
</header>
<main>
<section class="vt-hero">
  <div class="wrap">
    <p class="vt-crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Hasnivo Tech</a> / <?php echo esc_html( $v['name'] ); ?></p>
    <span class="eyebrow">WhatsApp AI chatbot for <?php echo esc_html( strtolower( $v['name'] ) ); ?></span>
    <h1><?php echo esc_html( $v['h1'] ); ?></h1>
    <p class="hero-lead"><?php echo esc_html( $v['lead'] ); ?></p>
    <div class="hero-actions">
      <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
      <a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">See plans</a>
    </div>
  </div>
</section>

<section class="vt-sec">
  <div class="wrap">
    <span class="eyebrow">The problem</span>
    <h2>What slows <?php echo esc_html( strtolower( $v['name'] ) ); ?> down on WhatsApp</h2>
    <div class="vt-cards">
      <?php foreach ( $v['pain'] as $c ) : ?>
        <div class="vt-card"><h3><?php echo esc_html( $c[0] ); ?></h3><p><?php echo esc_html( $c[1] ); ?></p></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="vt-sec">
  <div class="wrap">
    <span class="eyebrow">How it works</span>
    <h2>From first message to confirmed in three steps</h2>
    <div class="vt-cards">
      <?php foreach ( $v['steps'] as $i => $c ) : ?>
        <div class="vt-card"><h3><?php echo (int) ( $i + 1 ); ?>. <?php echo esc_html( $c[0] ); ?></h3><p><?php echo esc_html( $c[1] ); ?></p></div>
      <?php endforeach; ?>
    </div>
    <div class="vt-chat" aria-label="Example chat">
      <?php foreach ( $v['chat'] as $m ) : ?>
        <div class="vt-m <?php echo 'c' === $m[0] ? 'c' : 'b'; ?>"><?php echo esc_html( $m[1] ); ?></div>
      <?php endforeach; ?>
    </div>
    <p class="vt-crumb" style="text-align:center;margin-top:.6rem">Example conversation. Your bot uses your own menu, services and prices.</p>
  </div>
</section>

<section class="vt-sec">
  <div class="wrap">
    <span class="eyebrow">Questions</span>
    <h2>Frequently asked questions</h2>
    <div class="faq-list">
      <?php foreach ( $v['faq'] as $f ) : ?>
        <details class="faq-item" name="faq"><summary><h3><?php echo esc_html( $f[0] ); ?></h3></summary><p><?php echo esc_html( $f[1] ); ?></p></details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="vt-sec">
  <div class="wrap center-cta">
    <h2>Ready to answer every customer on WhatsApp?</h2>
    <p>Request access and we will set up your account. <?php echo esc_html( 'The bot replies in the language your customer writes in.' ); ?></p>
    <div class="hero-actions"><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
    <?php if ( hnvl_opt( 'whatsapp' ) ) : ?><a class="btn btn-ghost" href="https://wa.me/<?php echo esc_attr( hnvl_sanitize_phone( hnvl_opt( 'whatsapp' ) ) ); ?>" rel="noopener noreferrer">Chat on WhatsApp</a><?php endif; ?></div>
    <div class="vt-more">
      <?php foreach ( $all as $k => $o ) : if ( $k === $key ) { continue; } ?>
        <a href="<?php echo esc_url( home_url( $o['path'] ) ); ?>">WhatsApp chatbot for <?php echo esc_html( strtolower( $o['name'] ) ); ?></a>
      <?php endforeach; ?>
      <a href="<?php echo esc_url( home_url( '/plans/' ) ); ?>">Plans and pricing</a>
    </div>
  </div>
</section>
</main>
<footer class="site-footer"><div class="wrap"><div class="copyright"><span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> Hasnivo Tech. All rights reserved.</span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></div></div></footer>
<script src="<?php echo esc_url( HNVL_URL . 'assets/vertical.js?ver=' . $ver ); ?>" defer></script>
</body>
</html>
	<?php
	exit;
}
