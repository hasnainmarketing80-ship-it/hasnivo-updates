<?php
/**
 * Home Plans: the Plans section of the Home page, editable from the WordPress admin.
 * The plan "keys" (free, starter, business, pro) are fixed because the existing Request access
 * form uses them (/request-access/?plan=starter). Everything else about each plan can be edited.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const HNVL_PLANS_OPTION = 'hnvl_plans';

function hnvl_plans_defaults() {
	return array(
		'note'    => 'Some features depend on how your workspace is set up.',
		'popular' => 'business',
		'plans'   => array(
			'free'     => array( 'on' => 1, 'name' => 'Free', 'price' => 'Rs 0', 'per' => '/mo', 'desc' => 'Try it out with a single WhatsApp number.', 'features' => "1 WhatsApp number\n200 contacts\n300 messages / month\nAI chatbot", 'cta' => 'Start free' ),
			'starter'  => array( 'on' => 1, 'name' => 'Starter', 'price' => 'Rs 3,999', 'per' => '/mo', 'desc' => 'For solo operators and small teams.', 'features' => "3 WhatsApp numbers\n10,000 contacts\n15,000 messages / month\nAI chatbot\nHuman handover\nCSV export", 'cta' => 'Choose Starter' ),
			'business' => array( 'on' => 1, 'name' => 'Business', 'price' => 'Rs 7,999', 'per' => '/mo', 'desc' => 'For growing businesses that take bookings.', 'features' => "50,000 contacts\n35,000 messages / month\nEverything in Starter\nAppointment booking\nSend media\nVoice note understanding\nFull AI bot setup", 'cta' => 'Choose Business' ),
			'pro'      => array( 'on' => 1, 'name' => 'Pro', 'price' => 'Rs 14,999', 'per' => '/mo', 'desc' => 'For high-volume teams.', 'features' => 'Everything in Business', 'cta' => 'Choose Pro' ),
		),
	);
}

/** Clean submitted data. Pure function (used on save, on read and in tests). */
function hnvl_plans_sanitize( $raw ) {
	$d   = hnvl_plans_defaults();
	$out = array(
		'note'    => $d['note'],
		'popular' => '',
		'plans'   => array(),
	);
	if ( ! is_array( $raw ) ) {
		return $d;
	}
	if ( isset( $raw['note'] ) ) {
		$out['note'] = mb_substr( sanitize_text_field( (string) $raw['note'] ), 0, 160 );
	}
	$pop = isset( $raw['popular'] ) ? sanitize_key( (string) $raw['popular'] ) : '';
	foreach ( $d['plans'] as $key => $def ) {
		$in = isset( $raw['plans'][ $key ] ) && is_array( $raw['plans'][ $key ] ) ? $raw['plans'][ $key ] : array();
		$g  = function ( $f, $max ) use ( $in, $def ) {
			return isset( $in[ $f ] ) ? mb_substr( sanitize_text_field( (string) $in[ $f ] ), 0, $max ) : $def[ $f ];
		};
		$lines = array();
		$feat  = isset( $in['features'] ) ? (string) $in['features'] : $def['features'];
		foreach ( preg_split( '/\r\n|\r|\n/', $feat ) as $ln ) {
			$ln = mb_substr( sanitize_text_field( $ln ), 0, 80 );
			if ( '' !== $ln && count( $lines ) < 14 ) {
				$lines[] = $ln;
			}
		}
		$name = $g( 'name', 40 );
		$out['plans'][ $key ] = array(
			'on'       => isset( $raw['plans'] ) && ! isset( $in['on'] ) ? 0 : ( empty( $in ) ? $def['on'] : ( ! empty( $in['on'] ) ? 1 : 0 ) ),
			'name'     => '' !== $name ? $name : $def['name'],
			'price'    => $g( 'price', 30 ),
			'per'      => $g( 'per', 12 ),
			'desc'     => $g( 'desc', 140 ),
			'features' => implode( "\n", $lines ),
			'cta'      => '' !== $g( 'cta', 30 ) ? $g( 'cta', 30 ) : $def['cta'],
		);
	}
	$out['popular'] = ( isset( $out['plans'][ $pop ] ) && $out['plans'][ $pop ]['on'] ) ? $pop : '';
	return $out;
}

function hnvl_plans_get() {
	$v = get_option( HNVL_PLANS_OPTION, null );
	return is_array( $v ) ? hnvl_plans_sanitize( $v ) : hnvl_plans_defaults();
}

function hnvl_plans_enabled() {
	$p   = hnvl_plans_get();
	$out = array();
	foreach ( $p['plans'] as $key => $pl ) {
		if ( ! empty( $pl['on'] ) ) {
			$pl['key']     = $key;
			$pl['popular'] = ( $p['popular'] === $key );
			$out[]         = $pl;
		}
	}
	return $out;
}

/** Output of the Plans cards on the Home page. */
function hnvl_render_plans() {
	$p = hnvl_plans_get();
	echo '<div class="plans">';
	foreach ( hnvl_plans_enabled() as $pl ) {
		$li = '';
		foreach ( preg_split( '/\n/', $pl['features'] ) as $f ) {
			if ( '' !== $f ) {
				$li .= '<li><svg class="ic"><use href="#i-check"/></svg>' . esc_html( $f ) . '</li>';
			}
		}
		echo '<article class="plan' . ( $pl['popular'] ? ' plan-pop' : '' ) . '">';
		if ( $pl['popular'] ) {
			echo '<span class="plan-badge">Most popular</span>';
		}
		echo '<h3>' . esc_html( $pl['name'] ) . '</h3>';
		echo '<p class="plan-price"><b>' . esc_html( $pl['price'] ) . '</b>' . ( '' !== $pl['per'] ? '<span> ' . esc_html( $pl['per'] ) . '</span>' : '' ) . '</p>';
		if ( '' !== $pl['desc'] ) {
			echo '<p class="plan-desc">' . esc_html( $pl['desc'] ) . '</p>';
		}
		echo '<ul>' . $li . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a class="btn ' . ( $pl['popular'] ? 'btn-primary' : 'btn-ghost' ) . '" href="' . esc_url( home_url( '/request-access/?plan=' . $pl['key'] ) ) . '">' . esc_html( $pl['cta'] ) . '</a>';
		echo '</article>';
	}
	echo '</div>';
	if ( '' !== $p['note'] ) {
		echo '<p class="plan-note">' . esc_html( $p['note'] ) . '</p>';
	}
}

/** Plans for the chat widget, as inert JSON. */
add_action( 'wp_footer', 'hnvl_print_plans_json', 5 );
function hnvl_print_plans_json() {
	if ( ! hnvl_is_landing() ) {
		return;
	}
	$p   = hnvl_plans_get();
	$out = array( 'note' => $p['note'], 'plans' => array() );
	foreach ( hnvl_plans_enabled() as $pl ) {
		$out['plans'][] = array(
			'key'      => $pl['key'], 'name' => $pl['name'], 'price' => $pl['price'], 'per' => $pl['per'], 'desc' => $pl['desc'],
			'features' => array_values( array_filter( preg_split( '/\n/', $pl['features'] ) ) ), 'popular' => $pl['popular'],
		);
	}
	echo '<script type="application/json" id="hnvl-plans">' . wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>' . "\n";
}

/** One-line summary used in the FAQ. */
function hnvl_plans_sentence() {
	$parts = array();
	foreach ( hnvl_plans_enabled() as $pl ) {
		$parts[] = $pl['name'] . ' (' . $pl['price'] . ')';
	}
	if ( ! $parts ) {
		return 'Please see the Plans section for the current options.';
	}
	return 'There are ' . count( $parts ) . ' monthly plans: ' . implode( ', ', $parts ) . '.';
}

/** Plan facts for the optional AI mode. */
function hnvl_plans_prompt_text() {
	$lines = array();
	foreach ( hnvl_plans_enabled() as $pl ) {
		$lines[] = $pl['name'] . ' ' . $pl['price'] . $pl['per'] . ' (' . str_replace( "\n", '; ', $pl['features'] ) . ')';
	}
	$p = hnvl_plans_get();
	return '- Plans: ' . ( $lines ? implode( '. ', $lines ) : 'see the website Plans section' ) . '. ' . $p['note'] . "\n";
}

/* ---------------------------------------------------------------------------
 * Admin page: "Home Plans"
 * ------------------------------------------------------------------------- */

add_action( 'admin_menu', 'hnvl_plans_menu' );
function hnvl_plans_menu() {
	add_menu_page( 'Home Plans', 'Home Plans', 'manage_options', 'hnvl-plans', 'hnvl_plans_page', 'dashicons-money-alt', 28 );
}

add_action( 'admin_enqueue_scripts', 'hnvl_plans_admin_assets' );
function hnvl_plans_admin_assets( $hook ) {
	if ( 'toplevel_page_hnvl-plans' === $hook ) {
		wp_enqueue_style( 'hnvl-kb-admin', HNVL_URL . 'assets/admin.css', array(), HNVL_VERSION );
	}
}

add_action( 'admin_post_hnvl_save_plans', 'hnvl_plans_save' );
function hnvl_plans_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', 403 );
	}
	check_admin_referer( 'hnvl_save_plans' );
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$raw = isset( $_POST['hp'] ) ? wp_unslash( $_POST['hp'] ) : array();
	if ( ! empty( $_POST['reset'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		delete_option( HNVL_PLANS_OPTION );
		$flag = 'reset';
	} else {
		update_option( HNVL_PLANS_OPTION, hnvl_plans_sanitize( $raw ), false );
		$flag = '1';
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'hnvl-plans', 'saved' => $flag ), admin_url( 'admin.php' ) ) );
	exit;
}

function hnvl_plans_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$p = hnvl_plans_get();
	?>
	<div class="wrap hnvl-wrap">
		<h1>Home Plans</h1>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success is-dismissible"><p><?php echo ( 'reset' === $_GET['saved'] ) ? 'Plans pehle jaise ho gaye.' : 'Save ho gaya. Home page ka Plans section aur chat assistant ke plans ke jawab badal gaye.'; // phpcs:ignore ?></p></div>
		<?php endif; ?>
		<p class="hnvl-lead">Yahan se aap Home page ke <strong>Plans</strong> ki price, features, description aur button ka text badal sakte hain.</p>
		<div class="notice notice-warning inline"><p><strong>Zaroori:</strong> yeh sirf <strong>Home page</strong> ka Plans section (aur chat assistant ke jawab) badalta hai. Alag <strong>/plans/</strong> page aur <strong>Request access</strong> form aap ki purani theme se chalte hain, wahan bhi wahi tabdeeli karein, warna dono jagah alag cheez dikhegi. Plans ke chaar "keys" (free, starter, business, pro) fixed hain, kyunke Request access form unhi se pehchanta hai.</p></div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="hnvl_save_plans">
			<?php wp_nonce_field( 'hnvl_save_plans' ); ?>
			<?php foreach ( $p['plans'] as $key => $pl ) : $n = 'hp[plans][' . $key . ']'; ?>
				<div class="hnvl-row">
					<div class="hnvl-row-head"><strong><?php echo esc_html( ucfirst( $key ) ); ?> plan</strong>
						<span><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[on]" value="1" <?php checked( ! empty( $pl['on'] ) ); ?>> Home page par dikhao</label>
						&nbsp; <label><input type="radio" name="hp[popular]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $p['popular'], $key ); ?>> Most popular</label></span></div>
					<div class="hnvl-two">
						<label>Naam<input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $pl['name'] ); ?>" maxlength="40"></label>
						<label>Price <small>(jaise Rs 3,999)</small><input type="text" name="<?php echo esc_attr( $n ); ?>[price]" value="<?php echo esc_attr( $pl['price'] ); ?>" maxlength="30"></label>
					</div>
					<div class="hnvl-two">
						<label>Price ke saath <small>(jaise /mo)</small><input type="text" name="<?php echo esc_attr( $n ); ?>[per]" value="<?php echo esc_attr( $pl['per'] ); ?>" maxlength="12"></label>
						<label>Button ka text<input type="text" name="<?php echo esc_attr( $n ); ?>[cta]" value="<?php echo esc_attr( $pl['cta'] ); ?>" maxlength="30"></label>
					</div>
					<label>Chhoti description<input type="text" name="<?php echo esc_attr( $n ); ?>[desc]" value="<?php echo esc_attr( $pl['desc'] ); ?>" maxlength="140"></label>
					<label>Features <small>(har line mein ek feature)</small><textarea name="<?php echo esc_attr( $n ); ?>[features]" rows="6"><?php echo esc_textarea( $pl['features'] ); ?></textarea></label>
				</div>
			<?php endforeach; ?>
			<div class="hnvl-row"><label>Plans ke neeche ki line <small>(khali chhorein to nahi dikhegi)</small><input type="text" name="hp[note]" value="<?php echo esc_attr( $p['note'] ); ?>" maxlength="160"></label></div>
			<p class="hnvl-actions">
				<button type="submit" class="button button-primary button-large">Save karein</button>
				<button type="submit" name="reset" value="1" class="button button-secondary" onclick="return confirm('Plans pehle wale default par wapis karein?');">Default par wapis</button>
			</p>
		</form>
	</div>
	<?php
}
