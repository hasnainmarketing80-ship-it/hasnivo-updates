<?php
/**
 * Home demo chat: the visitor tries a sample chat, gives feedback, picks a bot and leaves details.
 * Saved in WordPress (Website enquiries) and emailed to the owner through the site's mail setup (Gmail SMTP).
 * Checks: nonce, same-origin, honeypot, rate limit, server-side validation, sanitising. No hand-written SQL.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_ajax_nopriv_hnvl_demo_lead', 'hnvl_ajax_demo_lead' );
add_action( 'wp_ajax_hnvl_demo_lead', 'hnvl_ajax_demo_lead' );

/** Bot types offered in the demo chat. */
function hnvl_demo_bot_types() {
	return array( 'Food & order / Restaurants', 'Clinic / Appointment booking', 'Other' );
}

/** Plans the visitor may choose: the plans switched on in Home Plans (name only, e.g. "Business"). */
function hnvl_demo_plan_names() {
	$out = array();
	if ( function_exists( 'hnvl_plans_enabled' ) ) {
		foreach ( hnvl_plans_enabled() as $pl ) {
			$out[] = (string) $pl['name'];
		}
	}
	return $out;
}

function hnvl_demo_rate_limited() {
	$key  = 'hnvl_dl_' . md5( hnvl_client_ip() );
	$now  = time();
	$hits = get_transient( $key );
	$hits = is_array( $hits ) ? $hits : array();
	$hits = array_values(
		array_filter(
			$hits,
			function ( $t ) use ( $now ) {
				return is_int( $t ) && $t > $now - 600;
			}
		)
	);
	$limit = count( $hits ) >= 5;
	if ( ! $limit ) {
		$hits[] = $now;
	}
	set_transient( $key, $hits, 600 );
	return $limit;
}

function hnvl_ajax_demo_lead() {
	nocache_headers();

	if ( ! check_ajax_referer( 'hnvl_contact', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'Session expired. Reload the page and try again.' ), 403 );
	}
	$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ) : '';
	if ( '' !== $origin && hnvl_host_key( $origin ) !== hnvl_host_key( home_url() ) ) {
		wp_send_json_error( array( 'message' => 'Forbidden.' ), 403 );
	}
	if ( ! empty( $_POST['website'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_send_json_success( array( 'stored' => false ) ); // honeypot: pretend success.
	}
	if ( hnvl_demo_rate_limited() ) {
		wp_send_json_error( array( 'message' => 'Too many requests. Please try again in a few minutes.' ), 429 );
	}

	// phpcs:disable WordPress.Security.NonceVerification
	$g = function ( $k ) {
		return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
	};
	$name   = $g( 'name' );
	$phone  = $g( 'phone' );
	$email  = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$plan   = $g( 'plan' );
	$bot    = $g( 'bot' );
	$tried  = $g( 'demo' );
	$rating = $g( 'rating' );
	// phpcs:enable

	$errors = array();
	if ( mb_strlen( $name ) < 2 || mb_strlen( $name ) > 100 ) {
		$errors['name'] = 'Enter your name.';
	}
	if ( ! preg_match( '/^\d{8,15}$/', preg_replace( '/[\s\-().]/', '', ltrim( $phone, '+' ) ) ) ) {
		$errors['phone'] = 'Enter a valid WhatsApp number.';
	}
	if ( ! is_email( $email ) || strlen( $email ) > 254 ) {
		$errors['email'] = 'Enter a valid email.';
	}
	if ( ! in_array( $plan, hnvl_demo_plan_names(), true ) ) {
		$errors['plan'] = 'Choose a plan.';
	}
	if ( ! in_array( $bot, hnvl_demo_bot_types(), true ) ) {
		$errors['bot'] = 'Choose a bot type.';
	}
	if ( $errors ) {
		wp_send_json_error(
			array(
				'message' => 'Please check your details.',
				'fields'  => $errors,
			),
			422
		);
	}
	$tried  = in_array( $tried, array( 'Restaurant orders', 'Clinic appointments', 'Customer support' ), true ) ? $tried : '';
	$rating = in_array( $rating, array( 'Loved it', 'Good', 'Not sure yet' ), true ) ? $rating : '';

	$lines = array(
		'Name: ' . $name,
		'WhatsApp: ' . $phone,
		'Email: ' . $email,
		'Plan: ' . $plan,
		'Bot type: ' . $bot,
		'Demo tried: ' . ( '' !== $tried ? $tried : 'none' ),
		'Feedback: ' . ( '' !== $rating ? $rating : 'none' ),
		'Source: Home page demo chat',
	);

	$post_id = wp_insert_post(
		wp_slash(
			array(
				'post_type'    => 'hnvl_lead',
				'post_status'  => 'private',
				'post_title'   => $name . ' - ' . $bot . ' (demo chat)',
				'post_content' => implode( "\n", $lines ),
				'meta_input'   => array(
					'hnvl_email'   => $email,
					'hnvl_phone'   => $phone,
					'hnvl_service' => $bot . ' / ' . $plan,
				),
			)
		),
		true
	);
	$stored = ! is_wp_error( $post_id ) && $post_id > 0;

	$to   = sanitize_email( hnvl_opt( 'email' ) );
	$body = implode( "\n", $lines ) . "\n";
	if ( function_exists( 'hnvl_wa_digits' ) ) {
		$d = hnvl_wa_digits( $phone );
		if ( '' !== $d ) {
			$body .= "\nReply on WhatsApp:\nhttps://wa.me/" . $d . '?text=' . rawurlencode( 'Assalam o Alaikum ' . $name . ', Hasnivo Tech se baat kar raha hoon. Aap ki ' . $bot . ' bot ki request mil gayi hai. ' ) . "\n";
		}
	}
	if ( $stored ) {
		$body .= "\nOpen in admin:\n" . admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' ) . "\n";
	}
	$mailed = false;
	if ( is_email( $to ) ) {
		$subject = 'New demo chat lead: ' . $bot . ' - ' . $plan . ' - ' . trim( preg_replace( '/[\r\n]+/', ' ', mb_substr( $name, 0, 60 ) ) );
		$mailed  = wp_mail( $to, $subject, $body, array( 'Reply-To: ' . trim( preg_replace( '/[\r\n<>,]+/', ' ', $name ) ) . ' <' . $email . '>' ) );
	}

	if ( ! $stored && ! $mailed ) {
		wp_send_json_error( array( 'message' => 'We could not send your details. Please use WhatsApp instead.' ), 502 );
	}
	wp_send_json_success(
		array(
			'stored' => $stored,
			'mailed' => (bool) $mailed,
		)
	);
}
