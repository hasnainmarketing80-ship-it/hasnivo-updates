<?php
/**
 * SEO / AI-search extras and light security hardening that are safe to run next to the old theme.
 * Nothing here changes page content. Deactivating the plugin removes all of it.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------------------------------------------------------------------------
 * 1. /sitemap.xml and /llms.txt (served directly, no rewrite flush needed)
 * ------------------------------------------------------------------------- */

function hnvl_request_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
	$path = wp_parse_url( $uri, PHP_URL_PATH );
	$base = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$path = is_string( $path ) ? $path : '';
	$base = is_string( $base ) ? rtrim( $base, '/' ) : '';
	if ( '' !== $base && 0 === strpos( $path, $base ) ) {
		$path = substr( $path, strlen( $base ) );
	}
	return '/' . trim( $path, '/' );
}

/** Public pages worth indexing (the Request access form is left out on purpose). */
function hnvl_sitemap_urls() {
	$urls = array(
		array( home_url( '/' ), '1.0' ),
		array( home_url( '/plans/' ), '0.8' ),
		array( home_url( '/contact/' ), '0.6' ),
	);
	return apply_filters( 'hnvl_sitemap_urls', $urls );
}

add_action( 'template_redirect', 'hnvl_serve_text_files', 0 );
function hnvl_serve_text_files() {
	if ( is_admin() ) {
		return;
	}
	$p = hnvl_request_path();
	if ( '/sitemap.xml' === $p ) {
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( hnvl_sitemap_urls() as $u ) {
			echo '  <url><loc>' . esc_url( $u[0] ) . '</loc><priority>' . esc_html( $u[1] ) . '</priority></url>' . "\n";
		}
		echo '</urlset>' . "\n";
		exit;
	}
	if ( '/llms.txt' === $p ) {
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=UTF-8' );
		echo hnvl_llms_text(); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}
}

/** A short, factual summary for AI assistants and answer engines. Uses the live plan data, so it never goes stale. */
function hnvl_llms_text() {
	$site  = home_url( '/' );
	$mail  = hnvl_opt( 'email' );
	$wa    = hnvl_opt( 'whatsapp' );
	$t     = "# Hasnivo Tech\n\n";
	$t    .= "> Hasnivo Tech builds WhatsApp AI chatbots and business automation for businesses, mainly in Pakistan. The bot replies to customers inside WhatsApp, takes appointments and food orders, and hands over to a person when needed. Replies in the language the customer writes in.\n\n";
	$t    .= "## What it does\n";
	$t    .= "- Appointment booking: customers pick a service, day and free slot; confirmation and reminder arrive in the same chat.\n";
	$t    .= "- Food orders: menu by category, pickup or home delivery, an order number for the customer and the team.\n";
	$t    .= "- Customer support: AI answers from the business's own services and policies; staff can take over any chat.\n";
	$t    .= "- Shared team inbox, CSV export of contacts and orders. Numbers connect by scanning a QR code; the official Cloud API is available on eligible plans.\n\n";
	$t    .= "## Plans (monthly)\n";
	foreach ( hnvl_plans_enabled() as $pl ) {
		$t .= '- ' . $pl['name'] . ': ' . $pl['price'] . $pl['per'] . ( '' !== $pl['desc'] ? '. ' . $pl['desc'] : '' ) . "\n";
	}
	$t    .= "\nSome features depend on how a workspace is set up.\n\n";
	$t    .= "## Other services\n";
	foreach ( hnvl_services() as $s ) {
		$t .= '- ' . $s[0] . ': ' . $s[1] . "\n";
	}
	$t    .= "\n## Links\n";
	$t    .= '- Home: ' . $site . "\n- Plans: " . home_url( '/plans/' ) . "\n- Request access: " . home_url( '/request-access/' ) . "\n- Contact: " . home_url( '/contact/' ) . "\n";
	if ( function_exists( 'hnvl_verticals' ) ) {
		$t .= "\n## Industries\n";
		foreach ( hnvl_verticals() as $v ) {
			$t .= '- ' . $v['name'] . ': ' . home_url( $v['path'] ) . "\n";
		}
	}
	if ( function_exists( 'hnvl_articles' ) ) {
		$t .= "\n## Insights (guides)\n- All guides: " . home_url( '/insights/' ) . "\n";
		foreach ( hnvl_articles() as $slug => $a ) {
			$t .= '- ' . $a['h1'] . ': ' . home_url( hnvl_ins_path( $slug ) ) . ' (' . $a['quick'] . ")\n";
		}
	}
	$t    .= "\n## Contact\n- Email: " . $mail . "\n- WhatsApp: +" . preg_replace( '/\D+/', '', (string) $wa ) . "\n";
	return $t;
}

add_filter( 'robots_txt', 'hnvl_robots_txt', 20, 2 );
function hnvl_robots_txt( $output, $public ) {
	if ( ! $public ) {
		return $output;
	}
	$output  = rtrim( $output ) . "\n";
	$output .= "Disallow: /?s=\nDisallow: /search/\n";
	$output .= "\nSitemap: " . home_url( '/sitemap.xml' ) . "\n";
	return $output;
}

/** Keep the form page and search results out of Google. */
add_action( 'wp_head', 'hnvl_noindex_extra', 1 );
function hnvl_noindex_extra() {
	if ( is_search() || is_404() || ( is_page() && 'request-access' === get_post_field( 'post_name', get_queried_object_id() ) ) ) {
		echo '<meta name="robots" content="noindex,follow">' . "\n";
	}
}

/* ---------------------------------------------------------------------------
 * 2. Hardening that is safe next to any theme
 * ------------------------------------------------------------------------- */

remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'wp_headers', 'hnvl_drop_xmlrpc_header' );
function hnvl_drop_xmlrpc_header( $h ) {
	unset( $h['X-Pingback'] );
	return $h;
}

/** Stop /?author=1 from revealing login names. */
add_action( 'template_redirect', 'hnvl_block_author_enum', 1 );
function hnvl_block_author_enum() {
	if ( is_admin() || is_user_logged_in() ) {
		return;
	}
	if ( isset( $_GET['author'] ) || is_author() ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}

/** Hide the user list from the public REST API. */
add_filter( 'rest_endpoints', 'hnvl_rest_hide_users' );
function hnvl_rest_hide_users( $eps ) {
	if ( ! is_user_logged_in() ) {
		foreach ( array_keys( $eps ) as $route ) {
			if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
				unset( $eps[ $route ] );
			}
		}
	}
	return $eps;
}

/** Same message for a wrong user name and a wrong password. */
add_filter( 'login_errors', 'hnvl_generic_login_error' );
function hnvl_generic_login_error( $msg ) {
	return 'Login failed. Check your details and try again.';
}

/** Lock a visitor out for 15 minutes after 6 failed logins in that time (per IP). */
function hnvl_login_key() {
	return 'hnvl_lf_' . md5( hnvl_client_ip() );
}
add_filter( 'authenticate', 'hnvl_login_gate', 1, 3 );
function hnvl_login_gate( $user, $username, $password ) {
	if ( '' === (string) $username && '' === (string) $password ) {
		return $user;
	}
	$n = (int) get_transient( hnvl_login_key() );
	if ( $n >= 6 ) {
		return new WP_Error( 'hnvl_locked', 'Too many attempts. Please wait 15 minutes and try again.' );
	}
	return $user;
}
add_action( 'wp_login_failed', 'hnvl_login_failed' );
function hnvl_login_failed() {
	$k = hnvl_login_key();
	set_transient( $k, (int) get_transient( $k ) + 1, 15 * MINUTE_IN_SECONDS );
}
add_action( 'wp_login', 'hnvl_login_ok' );
function hnvl_login_ok() {
	delete_transient( hnvl_login_key() );
}

/** Strict-Transport-Security on https pages (no includeSubdomains, so app.hasnivo.tech is not affected). */
add_action( 'send_headers', 'hnvl_hsts', 20 );
function hnvl_hsts() {
	if ( is_ssl() && ! headers_sent() ) {
		header( 'Strict-Transport-Security: max-age=31536000' );
	}
}

/* ---------------------------------------------------------------------------
 * 3. Titles, descriptions, social tags and price data for the Plans and Contact pages
 *    (the old theme prints none of these). Skipped when an SEO plugin is active.
 * ------------------------------------------------------------------------- */

function hnvl_inner_page_key() {
	if ( is_admin() || hnvl_is_landing() || ! is_page() ) {
		return '';
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	return in_array( $slug, array( 'plans', 'contact' ), true ) ? $slug : '';
}

function hnvl_inner_meta( $key ) {
	$lowest = '';
	foreach ( hnvl_plans_enabled() as $pl ) {
		if ( '' === $lowest ) {
			$lowest = $pl['name'] . ' ' . $pl['price'];
		}
	}
	if ( 'plans' === $key ) {
		return array(
			'title' => 'WhatsApp AI Chatbot Plans and Pricing | Hasnivo Tech',
			'desc'  => 'Simple monthly plans for a WhatsApp AI chatbot that books appointments and takes food orders. ' . hnvl_plans_sentence() . ' Start free.',
		);
	}
	return array(
		'title' => 'Contact Hasnivo Tech | WhatsApp AI Chatbots',
		'desc'  => 'Contact Hasnivo Tech about WhatsApp AI chatbots and business automation. Email or message us on WhatsApp, or request access to start.',
	);
}

add_filter( 'pre_get_document_title', 'hnvl_inner_title', 20 );
function hnvl_inner_title( $title ) {
	$k = hnvl_inner_page_key();
	if ( '' === $k || hnvl_seo_plugin_active() ) {
		return $title;
	}
	$m = hnvl_inner_meta( $k );
	return $m['title'];
}

add_action( 'wp_head', 'hnvl_inner_head', 2 );
function hnvl_inner_head() {
	$k = hnvl_inner_page_key();
	if ( '' === $k || hnvl_seo_plugin_active() ) {
		return;
	}
	$m   = hnvl_inner_meta( $k );
	$url = home_url( '/' . $k . '/' );
	$img = HNVL_URL . 'assets/og-image.png';
	echo '<meta name="description" content="' . esc_attr( $m['desc'] ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:site_name" content="Hasnivo Tech">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $m['title'] ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $m['desc'] ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	if ( 'plans' === $k ) {
		$offers = array();
		foreach ( hnvl_plans_enabled() as $pl ) {
			$num = (int) preg_replace( '/\D+/', '', explode( '.', str_replace( ',', '', $pl['price'] ) )[0] );
			$offers[] = array(
				'@type'         => 'Offer',
				'name'          => $pl['name'] . ' plan',
				'description'   => $pl['desc'],
				'price'         => (string) $num,
				'priceCurrency' => 'PKR',
				'url'           => home_url( '/request-access/?plan=' . $pl['key'] ),
			);
		}
		$data = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'Service',
			'name'            => 'WhatsApp AI chatbot',
			'provider'        => array( '@type' => 'Organization', 'name' => 'Hasnivo Tech', 'url' => home_url( '/' ) ),
			'areaServed'      => 'PK',
			'offers'          => $offers,
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>' . "\n";
	}
}

/** The WordPress sitemap address is not used on this site: send visitors and crawlers to /sitemap.xml. */
add_action( 'template_redirect', 'hnvl_core_sitemap_redirect', 0 );
function hnvl_core_sitemap_redirect() {
	if ( ! is_admin() && '/wp-sitemap.xml' === hnvl_request_path() ) {
		wp_safe_redirect( home_url( '/sitemap.xml' ), 301 );
		exit;
	}
}

/* ---------------------------------------------------------------------------
 * 4. Google Search Console ownership tag (Home page only). Change it with the
 *    option "hnvl_gsc_token" if the property is ever re-created.
 * ------------------------------------------------------------------------- */
add_action( 'wp_head', 'hnvl_gsc_meta', 1 );
function hnvl_gsc_meta() {
	if ( ! hnvl_is_landing() ) {
		return;
	}
	$token = get_option( 'hnvl_gsc_token', 'ybLazVdu2nMIHjerIFrl4gs9t_E3zU_lNx7tFuIVntE' );
	if ( is_string( $token ) && preg_match( '/^[A-Za-z0-9_\-]{20,80}$/', $token ) ) {
		echo '<meta name="google-site-verification" content="' . esc_attr( $token ) . '">' . "\n";
	}
}
