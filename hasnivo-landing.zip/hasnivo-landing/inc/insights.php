<?php
/**
 * Insights: a small set of articles for search (SEO), answer engines (AEO) and AI assistants (GEO).
 * Served by the plugin at /insights/ and /insights/<slug>/ (no WordPress pages needed). Deactivating the plugin removes them.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Article data. Body blocks: array( 'h2', text ) | array( 'p', text ) | array( 'ul', array( text, ... ) ).
 * Inline links: [anchor](slug:article-slug) or [anchor](/path/).
 */
function hnvl_articles_base() {
	$d = '2026-11-07';
	return array(
		'what-is-a-whatsapp-ai-chatbot' => array(
			'title'   => 'What Is a WhatsApp AI Chatbot? A Plain Guide for Business Owners',
			'h1'      => 'What Is a WhatsApp AI Chatbot?',
			'desc'    => 'A WhatsApp AI chatbot reads customer messages on your business number and replies automatically. Learn what it does, how it works and when it is worth using.',
			'kw'      => 'WhatsApp AI chatbot',
			'date'    => $d,
			'quick'   => 'A WhatsApp AI chatbot is software connected to your business WhatsApp number. It reads each customer message, replies automatically using your own business information, and hands the chat to a person when needed.',
			'body'    => array(
				array( 'h2', 'How does a WhatsApp AI chatbot work?' ),
				array( 'p', 'A customer sends a message to your business number. WhatsApp passes the message to the chatbot, which checks it against your services, prices and rules, then sends a reply, usually within seconds. If the customer is placing an order or booking a visit, the bot records the details and can alert your team.' ),
				array( 'h2', 'What can it do for a small business?' ),
				array( 'ul', array(
					'Answer the same questions again and again, such as opening hours, location and prices.',
					'Take food orders for pickup or home delivery. See [how to take food orders on WhatsApp](slug:how-to-take-food-orders-on-whatsapp).',
					'Book appointments by offering only free slots. See [how to book appointments on WhatsApp automatically](slug:whatsapp-appointment-booking-automatically).',
					'Capture the details of new enquiries, so no lead is lost overnight.',
					'Hand the conversation to your team whenever a person is needed.',
				) ),
				array( 'h2', 'Is it the same as a WhatsApp auto reply?' ),
				array( 'p', 'No. An auto reply sends one fixed message, such as a greeting or an away note. A chatbot understands what the customer asked and answers that question. The two are compared in detail in [WhatsApp auto reply vs AI chatbot](slug:whatsapp-auto-reply-vs-ai-chatbot).' ),
				array( 'h2', 'Will it give wrong answers?' ),
				array( 'p', 'A chatbot is only as good as the information it is given. Give it your real services, prices and policies, and keep a person able to take over any chat. With Hasnivo your team shares one inbox and can put the bot on hold at any time.' ),
				array( 'h2', 'Who should use one?' ),
				array( 'p', 'Any business that answers the same customer questions on WhatsApp every day: restaurants, clinics, salons, tutors, shops and offices. See the pages for [restaurants](/whatsapp-chatbot-for-restaurants/), [clinics](/whatsapp-chatbot-for-clinics/) and [salons](/whatsapp-chatbot-for-salons/). If you are ready to begin, read [how to set up a WhatsApp chatbot](slug:how-to-set-up-a-whatsapp-chatbot).' ),
			),
			'takeaways' => array( 'A chatbot answers the question the customer asked; an auto reply sends one fixed message.', 'It works best on repeat questions, orders, bookings and enquiries.', 'Keep a person able to take over any chat.' ),
			'faq'     => array(
				array( 'What is a WhatsApp AI chatbot in simple words?', 'It is a program on your business WhatsApp number that reads customer messages and replies automatically, using the information you give it.' ),
				array( 'Does a WhatsApp chatbot replace my staff?', 'No. It handles repeat questions and simple tasks so your team can focus on people who need a personal reply. Staff can take over any chat.' ),
				array( 'Can it reply in Urdu?', 'Yes. The bot replies in the language the customer writes in, including Urdu and English.' ),
			),
			'related' => array( 'whatsapp-chatbot-for-small-business-pakistan', 'whatsapp-auto-reply-vs-ai-chatbot', 'how-to-set-up-a-whatsapp-chatbot' ),
		),
		'whatsapp-chatbot-for-small-business-pakistan' => array(
			'title'   => 'WhatsApp Chatbot for Small Business in Pakistan: 6 Practical Uses',
			'h1'      => 'WhatsApp Chatbot for Small Business in Pakistan',
			'desc'    => 'Six practical ways a small business in Pakistan can use a WhatsApp chatbot: orders, bookings, price questions, leads, reminders and after-hours replies.',
			'kw'      => 'WhatsApp chatbot for small business Pakistan',
			'date'    => $d,
			'quick'   => 'Small businesses in Pakistan can use a WhatsApp chatbot to answer price and timing questions, take orders, book appointments, capture leads, send reminders and reply after hours, all on the WhatsApp number customers already use.',
			'body'    => array(
				array( 'h2', 'Why WhatsApp first?' ),
				array( 'p', 'Most customers already message businesses on WhatsApp, so there is no new app to ask them to install. A chatbot meets them where they are. It is explained from the beginning in [what is a WhatsApp AI chatbot](slug:what-is-a-whatsapp-ai-chatbot).' ),
				array( 'h2', 'Six practical uses' ),
				array( 'ul', array(
					'**Price and menu questions.** The bot shares your menu, services and prices every time someone asks.',
					'**Orders.** It collects items, quantity, pickup or delivery and the address, then gives an order number.',
					'**Appointments.** Customers pick a day and a free slot in the chat.',
					'**Leads.** It records the name, number and what the customer needs, even at night.',
					'**Reminders.** It reminds customers before a booking, which helps with no-shows.',
					'**After-hours replies.** Customers who write at midnight get an answer at midnight.',
				) ),
				array( 'h2', 'Where should you start?' ),
				array( 'p', 'Start with the question your team answers most often. For a restaurant that is usually the menu, so read [how to take food orders on WhatsApp](slug:how-to-take-food-orders-on-whatsapp). For a clinic or salon it is usually booking, so read [how to book appointments on WhatsApp automatically](slug:whatsapp-appointment-booking-automatically).' ),
				array( 'h2', 'What does it cost?' ),
				array( 'p', 'Costs depend on the plan and on how many numbers, contacts and messages you need. [WhatsApp chatbot cost: what affects the price](slug:whatsapp-chatbot-cost) explains the factors, and the [plans page](/plans/) shows current prices in rupees.' ),
			),
			'takeaways' => array( 'Begin with your most repeated customer question.', 'The bot works on the number customers already use.', 'Orders, bookings, leads and reminders are the highest-value starting points.' ),
			'faq'     => array(
				array( 'Can a small shop in Pakistan use a WhatsApp chatbot?', 'Yes. A shop can use it for price questions, orders and enquiries. You connect your existing business number by scanning a QR code.' ),
				array( 'Do I need technical knowledge?', 'No. You request access, we set up your account, and you scan a QR code to connect your number.' ),
				array( 'Is there a free plan?', 'Yes. There is a Free plan to try the bot on one number. See the plans page for what it includes.' ),
			),
			'related' => array( 'what-is-a-whatsapp-ai-chatbot', 'whatsapp-chatbot-cost', 'reply-to-whatsapp-customers-faster' ),
		),
		'how-to-take-food-orders-on-whatsapp' => array(
			'title'   => 'How to Take Food Orders on WhatsApp Automatically (Restaurants)',
			'h1'      => 'How to Take Food Orders on WhatsApp Automatically',
			'desc'    => 'A step-by-step guide for restaurants and food shops: share your menu, collect orders, ask pickup or delivery, and give every order a number on WhatsApp.',
			'kw'      => 'take food orders on WhatsApp',
			'date'    => $d,
			'quick'   => 'To take food orders on WhatsApp automatically, connect a chatbot to your business number, load your menu by category with prices, and let the bot collect items, quantity, pickup or delivery and the address, then confirm with an order number.',
			'body'    => array(
				array( 'h2', 'Step 1: Put your menu in order' ),
				array( 'p', 'Group items by category, such as burgers, biryani and drinks, and give each a clear name and price. The bot shows this menu whenever a customer asks for it.' ),
				array( 'h2', 'Step 2: Let the bot build the order' ),
				array( 'p', 'The customer picks items and quantity in the chat. The bot checks the total, then asks whether the order is for pickup or home delivery. For delivery it asks for the address.' ),
				array( 'h2', 'Step 3: Confirm with an order number' ),
				array( 'p', 'The customer and your team both receive an order number. Your team sees the order in a shared inbox, so nothing depends on one person\'s phone.' ),
				array( 'h2', 'Step 4: Keep a person ready' ),
				array( 'p', 'Special requests happen. Your staff can take over any chat and reply personally, then hand it back to the bot.' ),
				array( 'h2', 'What it looks like in practice' ),
				array( 'p', 'See the [WhatsApp chatbot for restaurants](/whatsapp-chatbot-for-restaurants/) page for an example conversation. If you are new to chatbots, start with [what is a WhatsApp AI chatbot](slug:what-is-a-whatsapp-ai-chatbot), and when you are ready follow [how to set up a WhatsApp chatbot](slug:how-to-set-up-a-whatsapp-chatbot).' ),
			),
			'takeaways' => array( 'A clear menu with prices is the foundation.', 'Ask pickup or delivery before the address.', 'Give every order a number the customer and team share.' ),
			'faq'     => array(
				array( 'Can a WhatsApp chatbot take food orders?', 'Yes. It shows the menu by category, collects items and quantity, asks pickup or delivery, and confirms with an order number.' ),
				array( 'Do I need a separate number for orders?', 'No. You can connect your existing business number by scanning a QR code.' ),
				array( 'Can customers order in Urdu?', 'Yes. The bot replies in the language the customer writes in.' ),
			),
			'related' => array( 'reply-to-whatsapp-customers-faster', 'whatsapp-chatbot-cost', 'whatsapp-chatbot-for-small-business-pakistan' ),
		),
		'whatsapp-appointment-booking-automatically' => array(
			'title'   => 'Book Appointments on WhatsApp Automatically (Clinics, Salons)',
			'h1'      => 'How to Book Appointments on WhatsApp Automatically',
			'desc'    => 'How clinics, salons and tutors can let customers book a free slot on WhatsApp, get a confirmation and receive a reminder, without answering every message by hand.',
			'kw'      => 'appointment booking on WhatsApp',
			'date'    => $d,
			'quick'   => 'To book appointments on WhatsApp automatically, set your working hours once, let a chatbot offer only free slots, confirm the booking in the chat and send a reminder before the visit.',
			'body'    => array(
				array( 'h2', 'Step 1: Set your working hours once' ),
				array( 'p', 'Tell the system when you work and how long each service takes. From then on only free slots are shown, so double bookings stop.' ),
				array( 'h2', 'Step 2: Let customers choose in the chat' ),
				array( 'p', 'The customer picks a service and a day, then taps a free slot. The bot confirms the booking in the same conversation.' ),
				array( 'h2', 'Step 3: Send a reminder' ),
				array( 'p', 'A reminder in the same chat before the visit helps reduce missed appointments, because customers can reply to confirm or change.' ),
				array( 'h2', 'Step 4: Keep your team in control' ),
				array( 'p', 'For anything unusual, your staff take over the chat. The bot does not give medical advice; it answers timings, fees and services from the details you provide.' ),
				array( 'h2', 'Where to see it' ),
				array( 'p', 'See the pages for [clinics](/whatsapp-chatbot-for-clinics/) and [salons](/whatsapp-chatbot-for-salons/). To compare a chatbot with a simple greeting message, read [WhatsApp auto reply vs AI chatbot](slug:whatsapp-auto-reply-vs-ai-chatbot).' ),
			),
			'takeaways' => array( 'Offer only free slots to avoid double bookings.', 'Confirm in the chat and remind before the visit.', 'Let staff take over anything unusual.' ),
			'faq'     => array(
				array( 'Can WhatsApp book doctor or salon appointments?', 'Yes. With a chatbot connected to your number, customers choose a free slot in the chat and receive a confirmation and a reminder.' ),
				array( 'Does the bot give medical advice?', 'No. It answers questions about timings, fees and services from the details you provide, and hands medical questions to your staff.' ),
				array( 'Can my receptionist reply too?', 'Yes. The whole team shares one inbox on one number.' ),
			),
			'related' => array( 'what-is-a-whatsapp-ai-chatbot', 'reply-to-whatsapp-customers-faster', 'how-to-set-up-a-whatsapp-chatbot' ),
		),
		'whatsapp-auto-reply-vs-ai-chatbot' => array(
			'title'   => 'WhatsApp Auto Reply vs AI Chatbot: Which Does Your Business Need?',
			'h1'      => 'WhatsApp Auto Reply vs AI Chatbot',
			'desc'    => 'Auto replies send one fixed message. An AI chatbot answers the actual question, takes orders and books appointments. Compare them and choose the right one.',
			'kw'      => 'WhatsApp auto reply vs chatbot',
			'date'    => $d,
			'quick'   => 'An auto reply sends the same fixed message to everyone, such as a greeting or an away note. An AI chatbot understands the question and answers it, and can take orders and bookings. Use an auto reply for simple greetings and a chatbot when customers ask varied questions.',
			'body'    => array(
				array( 'h2', 'What an auto reply does' ),
				array( 'p', 'A greeting or away message is sent when a customer first writes or when you are closed. It is simple and useful, but it cannot answer a specific question.' ),
				array( 'h2', 'What an AI chatbot does' ),
				array( 'p', 'A chatbot reads the message and replies to what was asked, using your own services and policies. It can also take an order, offer free booking slots and capture a lead. The basics are in [what is a WhatsApp AI chatbot](slug:what-is-a-whatsapp-ai-chatbot).' ),
				array( 'h2', 'Side by side' ),
				array( 'ul', array(
					'**Reply type:** one fixed message, versus an answer to the actual question.',
					'**Orders and bookings:** not possible with an auto reply, possible with a chatbot.',
					'**Best for:** a greeting or closed notice, versus busy businesses with repeat questions.',
					'**Setup effort:** very little, versus a short setup of your menu, services and prices.',
				) ),
				array( 'h2', 'Which should you choose?' ),
				array( 'p', 'If you only need to say hello and give opening hours, an auto reply is enough. If customers ask about prices, ask to order or want to book, a chatbot saves real time. Many businesses use both. For the next step, see [how to set up a WhatsApp chatbot](slug:how-to-set-up-a-whatsapp-chatbot), and for the cost side read [WhatsApp chatbot cost](slug:whatsapp-chatbot-cost).' ),
			),
			'takeaways' => array( 'Auto replies are fixed; chatbots answer the question.', 'Only a chatbot can take orders and bookings.', 'Many businesses use a greeting plus a chatbot.' ),
			'faq'     => array(
				array( 'Is an auto reply the same as a chatbot?', 'No. An auto reply sends one fixed message. A chatbot understands the question and gives a relevant answer.' ),
				array( 'Can I use both?', 'Yes. A greeting can welcome the customer and the chatbot can then answer questions and take orders.' ),
				array( 'Which is cheaper?', 'Auto replies are simpler and cheaper to set up. A chatbot costs more but handles far more of the conversation.' ),
			),
			'related' => array( 'what-is-a-whatsapp-ai-chatbot', 'whatsapp-chatbot-cost', 'how-to-set-up-a-whatsapp-chatbot' ),
		),
		'reply-to-whatsapp-customers-faster' => array(
			'title'   => 'How to Reply to WhatsApp Customers Faster: 7 Practical Tips',
			'h1'      => 'How to Reply to WhatsApp Customers Faster',
			'desc'    => 'Seven practical tips to answer WhatsApp customers faster: save common answers, use one shared inbox, automate repeat questions and cover after-hours messages.',
			'kw'      => 'reply to WhatsApp customers faster',
			'date'    => $d,
			'quick'   => 'To reply to WhatsApp customers faster, list your repeat questions, write standard answers, let a chatbot handle them automatically, share one inbox across your team, cover after-hours messages and keep a person ready for the rest.',
			'body'    => array(
				array( 'h2', 'Why speed matters' ),
				array( 'p', 'A customer who waits for an answer often messages another business. Fast replies keep the sale, especially for food orders and bookings.' ),
				array( 'h2', 'Seven tips' ),
				array( 'ul', array(
					'**List your repeat questions.** Opening hours, location, prices and delivery areas usually cover most chats.',
					'**Write one good answer for each.** Keep it short and clear.',
					'**Automate those answers.** A chatbot sends them instantly, as in [what is a WhatsApp AI chatbot](slug:what-is-a-whatsapp-ai-chatbot).',
					'**Share one inbox.** Your team reads and replies on one number, not one person\'s phone.',
					'**Cover after-hours.** Let the bot answer at night and record orders or leads.',
					'**Keep a person ready.** Staff should be able to take over any chat.',
					'**Review weekly.** Add answers for new questions you notice.',
				) ),
				array( 'h2', 'Where to go next' ),
				array( 'p', 'For restaurants, see [how to take food orders on WhatsApp](slug:how-to-take-food-orders-on-whatsapp). For clinics and salons, see [how to book appointments on WhatsApp automatically](slug:whatsapp-appointment-booking-automatically). To get started, read [how to set up a WhatsApp chatbot](slug:how-to-set-up-a-whatsapp-chatbot).' ),
			),
			'takeaways' => array( 'Answer repeat questions automatically.', 'Use one shared inbox for the whole team.', 'Cover after-hours messages.' ),
			'faq'     => array(
				array( 'How fast should I reply to WhatsApp customers?', 'As fast as you can. A chatbot replies within seconds, any hour, and your team can follow up when a personal answer is needed.' ),
				array( 'Can my whole team use one WhatsApp number?', 'Yes. With a shared inbox, your team reads and replies together on one number.' ),
				array( 'What about messages at night?', 'The bot can answer, take an order or capture a lead while you are closed.' ),
			),
			'related' => array( 'whatsapp-auto-reply-vs-ai-chatbot', 'whatsapp-chatbot-for-small-business-pakistan', 'how-to-take-food-orders-on-whatsapp' ),
		),
		'how-to-set-up-a-whatsapp-chatbot' => array(
			'title'   => 'How to Set Up a WhatsApp Chatbot for Your Business in 3 Steps',
			'h1'      => 'How to Set Up a WhatsApp Chatbot for Your Business',
			'desc'    => 'Set up a WhatsApp chatbot in three steps: request access, connect your number by scanning a QR code, then switch on appointments, your menu or the AI assistant.',
			'kw'      => 'set up a WhatsApp chatbot',
			'date'    => $d,
			'quick'   => 'To set up a WhatsApp chatbot with Hasnivo: request access with a short form, set your password from the link we send, scan a QR code from your WhatsApp to connect your number, then turn on appointments, your menu or the AI assistant.',
			'body'    => array(
				array( 'h2', 'Step 1: Request access' ),
				array( 'p', 'Fill in the short [request access form](/request-access/). We create your account and send a link to set your password.' ),
				array( 'h2', 'Step 2: Connect your number' ),
				array( 'p', 'Sign in, then scan a QR code from your WhatsApp. This pairs your number in about a minute. The official Cloud API is available on eligible plans, and Meta may charge for some message types on the official platform.' ),
				array( 'h2', 'Step 3: Turn on what you need' ),
				array( 'ul', array(
					'**Appointments:** set working hours and services. See [appointment booking on WhatsApp](slug:whatsapp-appointment-booking-automatically).',
					'**Food menu:** add categories, items and prices. See [taking food orders on WhatsApp](slug:how-to-take-food-orders-on-whatsapp).',
					'**AI assistant:** add your services and policies so it can answer questions.',
				) ),
				array( 'h2', 'Before you start' ),
				array( 'p', 'Decide which question your team answers most, and start there. If you are comparing options, read [WhatsApp auto reply vs AI chatbot](slug:whatsapp-auto-reply-vs-ai-chatbot) and [WhatsApp chatbot cost](slug:whatsapp-chatbot-cost). Total setup time depends on your business, so ask our team for a firm estimate.' ),
			),
			'takeaways' => array( 'Three steps: request access, scan the QR code, turn on features.', 'Start with your most repeated question.', 'Your team can take over any chat.' ),
			'faq'     => array(
				array( 'How long does it take to connect my number?', 'Scanning the QR code takes about a minute. The full bot setup depends on your business, so ask our team for an estimate.' ),
				array( 'Do I need a new SIM or number?', 'No. You connect the WhatsApp number you already use for your business.' ),
				array( 'Where do I start?', 'Use the request access form on the website. We will create your account.' ),
			),
			'related' => array( 'what-is-a-whatsapp-ai-chatbot', 'whatsapp-chatbot-cost', 'whatsapp-auto-reply-vs-ai-chatbot' ),
		),
		'whatsapp-chatbot-cost' => array(
			'title'   => 'WhatsApp Chatbot Cost: What Affects the Price (Pakistan)',
			'h1'      => 'WhatsApp Chatbot Cost: What Affects the Price',
			'desc'    => 'What determines the price of a WhatsApp chatbot: the plan, the number of numbers, contacts and messages, setup and official platform message charges.',
			'kw'      => 'WhatsApp chatbot cost',
			'date'    => $d,
			'quick'   => 'The price of a WhatsApp chatbot depends on the plan, how many WhatsApp numbers, contacts and messages you need, which features you use and whether you connect through the official Cloud API, where Meta may charge for some message types.',
			'body'    => array(
				array( 'h2', 'What affects the price?' ),
				array( 'ul', array(
					'**The plan.** Plans differ in numbers, contacts, monthly messages and features such as human handover and CSV export.',
					'**Volume.** More customers and messages usually need a larger plan.',
					'**Features.** Appointments, food ordering and voice-note understanding depend on the plan.',
					'**Official platform charges.** On the WhatsApp Cloud API, Meta may charge for some message types.',
					'**Setup help.** Some businesses want help loading menus, services and policies.',
				) ),
				array( 'h2', 'Is there a free option?' ),
				array( 'p', 'Yes. Hasnivo has a Free plan so you can try the bot on one number before you pay. See the [plans page](/plans/) for what each plan includes, in rupees.' ),
				array( 'h2', 'How to choose a plan' ),
				array( 'p', 'Start with the Free plan if you are testing. Move up when you need more numbers, contacts or messages, or features like handover and exports. To understand what you are paying for, read [what is a WhatsApp AI chatbot](slug:what-is-a-whatsapp-ai-chatbot), and when ready, [set up your chatbot](slug:how-to-set-up-a-whatsapp-chatbot).' ),
				array( 'h2', 'Is it worth it?' ),
				array( 'p', 'Compare the monthly price with the time your team spends answering repeat questions and the orders or bookings lost to slow replies. [Small businesses in Pakistan](slug:whatsapp-chatbot-for-small-business-pakistan) usually start with the question they answer most.' ),
			),
			'takeaways' => array( 'Price depends on plan, volume, features and official platform charges.', 'You can try the Free plan first.', 'Compare the price with time and orders lost to slow replies.' ),
			'faq'     => array(
				array( 'How much does a WhatsApp chatbot cost in Pakistan?', 'It depends on the plan. Current monthly prices in rupees are on the plans page, and there is a Free plan to try.' ),
				array( 'Are there extra WhatsApp charges?', 'On the official Cloud API, Meta may charge for some message types. Connecting by QR code does not use the Cloud API.' ),
				array( 'Can I change plans later?', 'Yes. You can change plans as your business grows.' ),
			),
			'related' => array( 'whatsapp-chatbot-for-small-business-pakistan', 'how-to-set-up-a-whatsapp-chatbot', 'whatsapp-auto-reply-vs-ai-chatbot' ),
		),
	);
}

/** Extra sections, spliced in before each article's closing section (which holds the links to related guides). */
function hnvl_articles_extra() {
	return array(
		'what-is-a-whatsapp-ai-chatbot' => array(
			array( 'h2', 'What does a chatbot need from you?' ),
			array( 'p', 'It needs information. Give it your opening hours, location, menu or services, prices, delivery areas and policies. The clearer the information, the better the answers. A chatbot cannot know what you have not told it, so it is worth spending an hour to write things down properly.' ),
			array( 'h2', 'Fixed menus and AI assistants' ),
			array( 'p', 'Some bots only follow a fixed menu, such as "press 1 for prices". An AI assistant can understand a message written in the customer\'s own words. Hasnivo uses clear step-by-step flows for orders and appointments, so every order and booking is complete and accurate, and an AI assistant for general questions that it answers from your own information.' ),
			array( 'h2', 'A day in the life of a chatbot' ),
			array( 'ul', array(
				'**Morning:** a customer asks your opening hours and location, and gets the answer in seconds.',
				'**Afternoon:** another customer orders food. The bot collects the items, asks pickup or delivery and gives an order number.',
				'**Late night:** a customer asks about delivery charges. The bot answers, and your team sees the whole conversation the next morning.',
			) ),
			array( 'h2', 'What a chatbot cannot do' ),
			array( 'p', 'It cannot replace human judgement. Complaints, special requests and negotiations are best handled by a person, so choose a system where your staff can take over any chat. Treat the bot as a fast first responder, not a replacement for your team.' ),
		),
		'whatsapp-chatbot-for-small-business-pakistan' => array(
			array( 'h2', 'Three examples' ),
			array( 'ul', array(
				'**A restaurant** shares its menu, takes orders for pickup or delivery and gives each order a number.',
				'**A clinic** answers timings and fees, offers free slots and reminds patients before the visit.',
				'**A salon** shares services and prices, books a slot and sends a reminder.',
			) ),
			array( 'h2', 'Common worries' ),
			array( 'ul', array(
				'**"Customers will not like talking to a bot."** Most customers want a fast, correct answer. Keep a person ready for anything personal.',
				'**"It sounds too technical."** You do not need technical skills. You request access, scan a QR code and add your information.',
				'**"I will lose control."** Your team shares one inbox, can read every chat and can pause the bot at any time.',
			) ),
			array( 'h2', 'How to tell if it is working' ),
			array( 'ul', array(
				'Customers get an answer in seconds, including at night.',
				'Your staff type fewer repeat answers.',
				'More orders, bookings and enquiries are captured after hours.',
				'Fewer appointments are missed because reminders go out automatically.',
			) ),
		),
		'how-to-take-food-orders-on-whatsapp' => array(
			array( 'h2', 'What to include in your menu' ),
			array( 'ul', array(
				'A clear name and a price for every item.',
				'Categories, such as burgers, biryani, drinks and desserts.',
				'Sizes or variants as separate items, so the total is always right.',
				'Only items you can actually serve right now. Update the menu when something runs out.',
			) ),
			array( 'h2', 'What to ask for delivery orders' ),
			array( 'ul', array(
				'The full delivery address and a nearby landmark.',
				'A contact number the rider can call.',
				'Your delivery area and delivery charges, stated clearly before the customer confirms.',
				'The payment method you accept, such as cash on delivery.',
			) ),
			array( 'h2', 'Common mistakes to avoid' ),
			array( 'ul', array(
				'Sending the whole menu in one long message. Show it by category.',
				'Not giving an order number, which makes follow-up confusing.',
				'No human backup for special requests.',
				'Forgetting to update prices when they change.',
			) ),
			array( 'h2', 'After the order is placed' ),
			array( 'p', 'Your team sees the order in the shared inbox and can reply to the customer in the same chat. You can export your contacts and orders as a CSV file whenever you need them, which helps with daily reports.' ),
		),
		'whatsapp-appointment-booking-automatically' => array(
			array( 'h2', 'What details to collect' ),
			array( 'ul', array(
				'The customer\'s name and contact number.',
				'The service they want, or the doctor or department for a clinic.',
				'Their preferred day, then a choice from the free slots.',
			) ),
			array( 'h2', 'How to reduce missed appointments' ),
			array( 'ul', array(
				'Send a reminder in the same chat before the visit.',
				'Make it easy to reply and change the time.',
				'Keep slot lengths realistic so your schedule does not run late.',
			) ),
			array( 'h2', 'Who benefits most' ),
			array( 'p', 'Any business that sells time: clinics, salons, tutors, offices and consultants. If your team spends part of every day agreeing times over chat, automatic booking gives that time back.' ),
			array( 'h2', 'Common mistakes' ),
			array( 'ul', array(
				'Showing slots that are not really free, which causes double bookings.',
				'Leaving no gap between appointments.',
				'No way for a person to step in when a customer has a special request.',
			) ),
		),
		'whatsapp-auto-reply-vs-ai-chatbot' => array(
			array( 'h2', 'When an auto reply is enough' ),
			array( 'ul', array(
				'You receive few messages and answer them yourself.',
				'You only want to say hello or tell customers you are closed.',
				'You do not take orders or bookings on WhatsApp.',
			) ),
			array( 'h2', 'When you need a chatbot' ),
			array( 'ul', array(
				'Customers ask about prices, menus, timings or delivery all day.',
				'You want to take orders or book appointments in the chat.',
				'Messages arrive at night and you lose customers who do not get a reply.',
				'More than one person needs to answer from the same number.',
			) ),
			array( 'h2', 'A simple way to decide' ),
			array( 'p', 'Notice how often your staff type the same answer. If it happens many times a day, a chatbot will save hours every week. If it happens rarely, a greeting message may be all you need.' ),
		),
		'reply-to-whatsapp-customers-faster' => array(
			array( 'h2', 'What slows replies down' ),
			array( 'ul', array(
				'One phone shared by several people.',
				'Messages arriving at night or during a rush.',
				'Typing the same answer again and again.',
				'No clear owner for the inbox.',
			) ),
			array( 'h2', 'Set a response goal' ),
			array( 'p', 'Decide how quickly you want to reply, for example within a few minutes during business hours, and instantly for common questions through the bot. Check how you are doing every week and adjust.' ),
			array( 'h2', 'Keep the tone simple' ),
			array( 'p', 'Short, friendly answers work best. Reply in the language the customer writes in, and put the key information, such as the price or the time, in the first sentence.' ),
		),
		'how-to-set-up-a-whatsapp-chatbot' => array(
			array( 'h2', 'What to prepare before you start' ),
			array( 'ul', array(
				'The WhatsApp business number you want to connect, on a phone with WhatsApp installed.',
				'Your menu or list of services with prices.',
				'Your working hours and delivery or service area.',
				'Your policies, such as refunds or cancellations.',
				'Who on your team will watch the inbox.',
			) ),
			array( 'h2', 'Test before you go live' ),
			array( 'ul', array(
				'Message the number from another phone and ask for the menu or prices.',
				'Place a test order or book a test appointment.',
				'Ask something the bot should not know, to see how it responds.',
				'Ask to speak to a person, and confirm your team can take over.',
			) ),
			array( 'h2', 'After you go live' ),
			array( 'p', 'Read a few real chats each week. If customers keep asking something the bot cannot answer, add that information. Small improvements every week make the bot better over time.' ),
		),
		'whatsapp-chatbot-cost' => array(
			array( 'h2', 'Questions to ask any provider' ),
			array( 'ul', array(
				'What is included in each plan?',
				'Are there limits on contacts or monthly messages?',
				'Are there extra charges for the official WhatsApp platform?',
				'Can my staff take over any chat?',
				'Can I export my data?',
				'Can I change plans or stop later?',
			) ),
			array( 'h2', 'Costs to watch for' ),
			array( 'ul', array(
				'Per-message charges on the official platform.',
				'Setup fees.',
				'Extra charges for additional numbers or features.',
			) ),
			array( 'h2', 'Doing the maths' ),
			array( 'p', 'Estimate the hours your team spends each week answering repeat questions, and think about the orders or bookings you lose to slow replies. Then compare that with the monthly price of the plan.' ),
		),
	);
}

/** All articles: base data plus the extra sections placed before the closing section. */
function hnvl_articles() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$all   = hnvl_articles_base();
	$extra = hnvl_articles_extra();
	foreach ( $all as $slug => $a ) {
		if ( ! empty( $extra[ $slug ] ) ) {
			$at         = max( 0, count( $a['body'] ) - 2 );
			$a['body']  = array_merge( array_slice( $a['body'], 0, $at ), $extra[ $slug ], array_slice( $a['body'], $at ) );
			$all[ $slug ] = $a;
		}
	}
	$cache = $all;
	return $all;
}

/** Inline markup: [anchor](slug:article-slug) | [anchor](/path/) | **bold**. Text is escaped first. */
function hnvl_ins_inline( $text ) {
	$t = esc_html( $text );
	$t = preg_replace_callback(
		'/\[([^\]]+)\]\(([^)]+)\)/',
		function ( $m ) {
			$to = html_entity_decode( $m[2], ENT_QUOTES );
			if ( 0 === strpos( $to, 'slug:' ) ) {
				$href = home_url( '/insights/' . substr( $to, 5 ) . '/' );
			} else {
				$href = home_url( $to );
			}
			return '<a href="' . esc_url( $href ) . '">' . $m[1] . '</a>';
		},
		$t
	);
	return preg_replace( '/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $t );
}

function hnvl_ins_plain( $text ) {
	$t = preg_replace( '/\[([^\]]+)\]\(([^)]+)\)/', '$1', $text );
	return str_replace( '**', '', $t );
}

function hnvl_ins_minutes( $a ) {
	$words = str_word_count( $a['quick'] );
	foreach ( $a['body'] as $b ) {
		$words += str_word_count( hnvl_ins_plain( is_array( $b[1] ) ? implode( ' ', $b[1] ) : $b[1] ) );
	}
	return max( 2, (int) ceil( $words / 200 ) );
}

/** Cover image URL for an article (original illustration shipped with the plugin). */
function hnvl_ins_img( $slug ) {
	return HNVL_URL . 'assets/insights/' . $slug . '.png';
}

/**
 * In-article figures. Each entry: array( number of H2 sections before it, file name, alt text, caption ).
 * The figure is shown at the end of that section.
 */
function hnvl_ins_figs( $slug ) {
	$m = array(
		'what-is-a-whatsapp-ai-chatbot'                => array(
			array( 1, 'what-is-a-whatsapp-ai-chatbot-flow', 'Four steps: the customer writes, the bot checks your information, a reply is sent within seconds and your team is alerted', 'How a WhatsApp AI chatbot handles one customer message.' ),
			array( 4, 'what-is-a-whatsapp-ai-chatbot-control', 'Three ways you stay in control of a chatbot: real answers from your own information, staff can step in, and the bot can be put on hold', 'You decide what the bot knows, and a person can take over at any time.' ),
		),
		'whatsapp-chatbot-for-small-business-pakistan' => array(
			array( 2, 'whatsapp-chatbot-for-small-business-pakistan-uses', 'Six practical uses of a WhatsApp chatbot: price questions, orders, appointments, leads, reminders and after-hours replies', 'Six everyday jobs a chatbot can take off your team.' ),
			array( 3, 'whatsapp-chatbot-for-small-business-pakistan-start', 'Where to start: restaurants begin with the menu and orders, clinics and salons with booking, any business with its most repeated question', 'Start with the question you answer most often.' ),
		),
		'how-to-take-food-orders-on-whatsapp'          => array(
			array( 2, 'how-to-take-food-orders-on-whatsapp-build', 'Building a food order in WhatsApp: the customer picks items, the bot checks the total, asks pickup or delivery and then asks for an address', 'From first message to a complete order.' ),
			array( 4, 'how-to-take-food-orders-on-whatsapp-handoff', 'The bot handles routine orders, staff take over special requests and hand the chat back to the bot', 'Your staff can step in for special requests and hand back.' ),
		),
		'whatsapp-appointment-booking-automatically'   => array(
			array( 1, 'whatsapp-appointment-booking-automatically-slots', 'An example day where booked hours are greyed out and only free hours are shown to customers', 'Set your working hours once and only free slots are offered.' ),
			array( 3, 'whatsapp-appointment-booking-automatically-reminder', 'Booking is confirmed, a reminder is sent before the visit and the customer confirms or asks to change', 'A reminder in the same chat helps reduce missed appointments.' ),
		),
		'whatsapp-auto-reply-vs-ai-chatbot'            => array(
			array( 3, 'whatsapp-auto-reply-vs-ai-chatbot-table', 'Table comparing a WhatsApp auto reply with an AI chatbot on reply type, orders and bookings, best use and setup effort', 'An auto reply and an AI chatbot compared.' ),
			array( 6, 'whatsapp-auto-reply-vs-ai-chatbot-decide', 'Decision guide: if staff type the same answer many times a day choose an AI chatbot, if rarely a greeting message may be enough', 'How often do you repeat the same answer?' ),
		),
		'reply-to-whatsapp-customers-faster'           => array(
			array( 2, 'reply-to-whatsapp-customers-faster-tips', 'Seven tips for replying faster on WhatsApp, from listing repeat questions to reviewing weekly', 'The seven tips at a glance.' ),
			array( 3, 'reply-to-whatsapp-customers-faster-slow', 'Four things that slow replies down, and what helps: automate repeat answers, share one inbox and name an inbox owner', 'Common causes of slow replies and what helps.' ),
		),
		'how-to-set-up-a-whatsapp-chatbot'             => array(
			array( 4, 'how-to-set-up-a-whatsapp-chatbot-prepare', 'Checklist to prepare before setup: your WhatsApp business number, menu or services with prices, working hours, policies and who watches the inbox', 'Have these ready before you start.' ),
			array( 5, 'how-to-set-up-a-whatsapp-chatbot-test', 'Four tests before going live: message from another phone, place a test order or booking, ask something unknown and ask for a person', 'Four quick tests before you go live.' ),
		),
		'whatsapp-chatbot-cost'                        => array(
			array( 1, 'whatsapp-chatbot-cost-factors', 'Five things that affect the price of a WhatsApp chatbot: the plan, volume, features, platform charges and setup help', 'What goes into your monthly price.' ),
			array( 6, 'whatsapp-chatbot-cost-maths', 'Comparing what slow replies cost your business with the monthly price of a plan', 'Weigh the cost of slow replies against the plan price.' ),
		),
	);
	return isset( $m[ $slug ] ) ? $m[ $slug ] : array();
}

/** Echo the figures that belong at the end of section $after. */
function hnvl_ins_echo_figs( $figs, $after ) {
	foreach ( $figs as $f ) {
		if ( (int) $f[0] === (int) $after ) {
			echo '<figure class="art-fig"><img src="' . esc_url( HNVL_URL . 'assets/insights/' . $f[1] . '.png' ) . '" width="1200" height="560" alt="' . esc_attr( $f[2] ) . '" loading="lazy"><figcaption>' . esc_html( $f[3] ) . '</figcaption></figure>';
		}
	}
}

/** Alt text describing what the cover image shows. */
function hnvl_ins_alt( $slug ) {
	$alts = array(
		'what-is-a-whatsapp-ai-chatbot'                => 'A customer asks a business about opening hours on WhatsApp and the AI chatbot replies within seconds',
		'whatsapp-chatbot-for-small-business-pakistan' => 'Checklist of what a WhatsApp chatbot does for a small business: price questions, orders, appointments, leads and after-hours replies',
		'how-to-take-food-orders-on-whatsapp'          => 'A WhatsApp chat where a customer orders two chicken biryani and a zinger and the bot confirms order number 1042 for delivery',
		'whatsapp-appointment-booking-automatically'   => 'A WhatsApp chat offering free appointment slots, confirming a 5:30 PM booking and sending a reminder',
		'whatsapp-auto-reply-vs-ai-chatbot'            => 'Comparison of a fixed WhatsApp auto reply and an AI chatbot that answers the actual delivery question',
		'reply-to-whatsapp-customers-faster'           => 'A clock showing replies in seconds and a WhatsApp chat where a customer gets an instant answer about delivery',
		'how-to-set-up-a-whatsapp-chatbot'             => 'Three setup steps: request access, scan the QR code and turn on features',
		'whatsapp-chatbot-cost'                        => 'Four plan columns, Free, Starter, Business and Pro, to compare what each WhatsApp chatbot plan includes',
	);
	return isset( $alts[ $slug ] ) ? $alts[ $slug ] : '';
}

function hnvl_ins_path( $slug = '' ) {
	return '' === $slug ? '/insights/' : '/insights/' . $slug . '/';
}

/** Which Insights page (if any) is requested: '' none, '_index', or an article slug. */
function hnvl_insights_key() {
	if ( is_admin() ) {
		return '';
	}
	$p = trailingslashit( hnvl_request_path() );
	if ( '/insights/' === $p ) {
		return '_index';
	}
	if ( 0 === strpos( $p, '/insights/' ) ) {
		$slug = trim( substr( $p, 10 ), '/' );
		if ( '' !== $slug && isset( hnvl_articles()[ $slug ] ) ) {
			return $slug;
		}
	}
	return '';
}

add_filter(
	'hnvl_sitemap_urls',
	function ( $urls ) {
		$urls[] = array( home_url( '/insights/' ), '0.7' );
		foreach ( hnvl_articles() as $slug => $a ) {
			$urls[] = array( home_url( hnvl_ins_path( $slug ) ), '0.6' );
		}
		return $urls;
	}
);

function hnvl_ins_head( $title, $desc, $url, $graph, $type, $img = '' ) {
	if ( '' === $img ) {
		$img = HNVL_URL . 'assets/og-image.png';
	}
	$ver = HNVL_VERSION . '.' . (int) @filemtime( HNVL_DIR . 'assets/style.css' );
	$cfg = array(
		'whatsapp'  => hnvl_sanitize_phone( hnvl_opt( 'whatsapp' ) ),
		'email'     => sanitize_email( hnvl_opt( 'email' ) ),
		'social'    => array(),
		'ga4Id'     => hnvl_sanitize_ga4( hnvl_opt( 'ga4' ) ),
		'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
		'siteUrl'   => home_url( '/' ),
		'aiEnabled' => false,
	);
	?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#060A18">
<meta name="color-scheme" content="dark">
<title><?php echo esc_html( $title ); ?></title>
<meta name="description" content="<?php echo esc_attr( $desc ); ?>">
<link rel="canonical" href="<?php echo esc_url( $url ); ?>">
<meta property="og:type" content="<?php echo esc_attr( $type ); ?>">
<meta property="og:site_name" content="Hasnivo Tech">
<meta property="og:title" content="<?php echo esc_attr( $title ); ?>">
<meta property="og:description" content="<?php echo esc_attr( $desc ); ?>">
<meta property="og:url" content="<?php echo esc_url( $url ); ?>">
<meta property="og:image" content="<?php echo esc_url( $img ); ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="<?php echo esc_url( $img ); ?>">
<link rel="icon" href="<?php echo esc_url( HNVL_URL . 'assets/favicon.svg' ); ?>" type="image/svg+xml">
<link rel="icon" href="<?php echo esc_url( HNVL_URL . 'assets/logo-512.png' ); ?>" type="image/png" sizes="512x512">
<link rel="apple-touch-icon" href="<?php echo esc_url( HNVL_URL . 'assets/logo-512.png' ); ?>">
<meta name="hasnivo-config" content="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,700;12..96,800&amp;family=DM+Sans:wght@400;500;700&amp;family=JetBrains+Mono:wght@500&amp;display=swap">
<link rel="stylesheet" href="<?php echo esc_url( HNVL_URL . 'assets/style.css?ver=' . $ver ); ?>">
<style>
.vt-hero{padding:clamp(7rem,14vw,10rem) 0 2rem}.vt-hero h1{font-family:'Bricolage Grotesque',sans-serif;font-size:clamp(2rem,5vw,3.3rem);line-height:1.1;margin:.6rem 0 1rem;max-width:22ch}
.vt-crumb{font-size:.85rem;opacity:.7}.vt-crumb a{color:inherit}.vt-cards{display:grid;gap:1rem;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));margin-top:1.5rem}
.vt-card{border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);border-radius:16px;padding:1.2rem;display:block;text-decoration:none;color:inherit}.vt-card:hover{border-color:rgba(37,214,240,.5)}.vt-card h3{margin:.3rem 0 .5rem;font-size:1.1rem}.vt-card p{margin:0;opacity:.85}
.vt-sec{padding:2rem 0}.vt-sec h2{font-family:'Bricolage Grotesque',sans-serif;font-size:clamp(1.4rem,3vw,2rem);margin:1.6rem 0 .6rem}
.art{max-width:760px}.art p,.art li{line-height:1.75;font-size:1.05rem;opacity:.92}.art ul{padding-left:1.2rem}.art li{margin:.35rem 0}.art a{color:#25D6F0}
.art-meta{font-size:.9rem;opacity:.7;margin:.2rem 0 1.2rem}.quick{border:1px solid rgba(37,214,240,.35);background:rgba(37,214,240,.06);border-radius:14px;padding:1rem 1.2rem;margin:1rem 0 1.5rem}.quick b{display:block;font-size:.8rem;letter-spacing:.08em;text-transform:uppercase;color:#25D6F0;margin-bottom:.3rem}.quick p{margin:0}
.art-img{display:block;width:100%;height:auto;border-radius:18px;border:1px solid rgba(255,255,255,.1);margin:1.2rem 0 1.4rem}.vt-card .thumb{display:block;width:100%;height:auto;border-radius:12px;margin:0 0 .8rem}.art-fig{margin:1.4rem 0 1.6rem}.art-fig img{display:block;width:100%;height:auto;border-radius:16px;border:1px solid rgba(255,255,255,.1)}.art-fig figcaption{font-size:.85rem;color:#8FA3C7;margin-top:.55rem}
.tk{border-left:3px solid #3B74FF;padding:.2rem 0 .2rem 1rem;margin:1.5rem 0}
</style>
<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); // phpcs:ignore ?></script>
</head>
<body class="hnvl-insights">
<svg class="sprite" width="0" height="0" aria-hidden="true" focusable="false"><symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol><symbol id="i-close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol></svg>
<header class="site-header" id="top">
  <div class="wrap nav">
    <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Hasnivo Tech home"><span class="brand-name">Hasnivo<small>TECH</small></span></a>
    <ul class="nav-links" id="navLinks">
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#features' ) ); ?>">Features</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#plans' ) ); ?>">Plans</a></li>
      <li><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>">FAQ</a></li>
      <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Contact</a></li>
    </ul>
    <div class="nav-cta">
      <a class="btn btn-primary btn-sm" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a>
      <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navLinks" aria-label="Open menu"><svg class="ic"><use href="#i-menu"/></svg></button>
    </div>
  </div>
</header>
<main>
	<?php
}

function hnvl_ins_foot( $with_cta = true ) {
	$ver = HNVL_VERSION . '.' . (int) @filemtime( HNVL_DIR . 'assets/style.css' );
	if ( $with_cta ) :
		?>
<section class="vt-sec">
  <div class="wrap center-cta">
    <h2>Ready to answer every customer on WhatsApp?</h2>
    <p>Request access and we will set up your account. The bot replies in the language your customer writes in.</p>
    <div class="hero-actions"><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/request-access/' ) ); ?>">Request access</a><a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/plans/' ) ); ?>">See plans</a></div>
  </div>
</section>
		<?php
	endif;
	?>
</main>
<footer class="site-footer"><div class="wrap"><div class="copyright"><span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> Hasnivo Tech. All rights reserved.</span><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></div></div></footer>
<script src="<?php echo esc_url( HNVL_URL . 'assets/vertical.js?ver=' . $ver ); ?>" defer></script>
</body>
</html>
	<?php
}

add_action( 'template_redirect', 'hnvl_render_insights', 2 );
function hnvl_render_insights() {
	$key = hnvl_insights_key();
	if ( '' === $key ) {
		return;
	}
	$all = hnvl_articles();
	$org = home_url( '/' ) . '#organization';
	$pub = array(
		'@type' => 'Organization',
		'@id'   => $org,
		'name'  => 'Hasnivo Tech',
		'url'   => home_url( '/' ),
		'logo'  => array( '@type' => 'ImageObject', 'url' => HNVL_URL . 'assets/logo-512.png' ),
	);
	status_header( 200 );
	nocache_headers();
	header( 'Content-Type: text/html; charset=UTF-8' );
	header( 'Cache-Control: public, max-age=300' );

	if ( '_index' === $key ) {
		$url   = home_url( '/insights/' );
		$title = 'WhatsApp Chatbot Insights and Guides for Business Owners | Hasnivo Tech';
		$desc  = 'Practical guides on WhatsApp AI chatbots: how they work, how to take food orders and appointments, cost, setup and replying to customers faster.';
		$items = array();
		$i     = 1;
		foreach ( $all as $slug => $a ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $i++, 'url' => home_url( hnvl_ins_path( $slug ) ), 'name' => $a['h1'] );
		}
		$graph = array(
			array( '@type' => 'CollectionPage', 'name' => 'Hasnivo Tech Insights', 'url' => $url, 'description' => $desc, 'isPartOf' => array( '@id' => home_url( '/' ) . '#website' ), 'publisher' => $pub ),
			array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
				array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Hasnivo Tech', 'item' => home_url( '/' ) ),
				array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Insights', 'item' => $url ),
			) ),
			array( '@type' => 'ItemList', 'itemListElement' => $items ),
		);
		hnvl_ins_head( $title, $desc, $url, $graph, 'website' );
		?>
<section class="vt-hero"><div class="wrap">
  <p class="vt-crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Hasnivo Tech</a> / Insights</p>
  <span class="eyebrow">Insights</span>
  <h1>WhatsApp Chatbot Insights for Business Owners</h1>
  <p class="hero-lead">Plain-language guides on WhatsApp AI chatbots: what they are, what they cost, and how restaurants, clinics and shops use them to answer customers faster.</p>
</div></section>
<section class="vt-sec"><div class="wrap">
  <div class="vt-cards">
		<?php foreach ( $all as $slug => $a ) : ?>
    <a class="vt-card" href="<?php echo esc_url( home_url( hnvl_ins_path( $slug ) ) ); ?>"><img class="thumb" src="<?php echo esc_url( hnvl_ins_img( $slug ) ); ?>" width="1200" height="630" alt="<?php echo esc_attr( hnvl_ins_alt( $slug ) ); ?>" loading="lazy"><span class="eyebrow"><?php echo esc_html( $a['kw'] ); ?></span><h3><?php echo esc_html( $a['h1'] ); ?></h3><p><?php echo esc_html( $a['desc'] ); ?></p></a>
		<?php endforeach; ?>
  </div>
</div></section>
		<?php
		hnvl_ins_foot();
		exit;
	}

	$a     = $all[ $key ];
	$url   = home_url( hnvl_ins_path( $key ) );
	$faq   = array();
	foreach ( $a['faq'] as $f ) {
		$faq[] = array( '@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ) );
	}
	$graph = array(
		array(
			'@type'            => 'Article',
			'headline'         => $a['h1'],
			'description'      => $a['desc'],
			'keywords'         => $a['kw'],
			'datePublished'    => $a['date'],
			'dateModified'     => $a['date'],
			'inLanguage'       => 'en',
			'image'            => array( '@type' => 'ImageObject', 'url' => hnvl_ins_img( $key ), 'width' => 1200, 'height' => 630 ),
			'mainEntityOfPage' => $url,
			'author'           => array( '@type' => 'Organization', 'name' => 'Hasnivo Tech', 'url' => home_url( '/' ) ),
			'publisher'        => $pub,
		),
		array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Hasnivo Tech', 'item' => home_url( '/' ) ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Insights', 'item' => home_url( '/insights/' ) ),
			array( '@type' => 'ListItem', 'position' => 3, 'name' => $a['h1'], 'item' => $url ),
		) ),
		array( '@type' => 'FAQPage', 'mainEntity' => $faq ),
	);
	hnvl_ins_head( $a['title'], $a['desc'], $url, $graph, 'article', hnvl_ins_img( $key ) );
	?>
<section class="vt-hero"><div class="wrap art">
  <p class="vt-crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Hasnivo Tech</a> / <a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">Insights</a> / <?php echo esc_html( $a['kw'] ); ?></p>
  <span class="eyebrow"><?php echo esc_html( $a['kw'] ); ?></span>
  <h1><?php echo esc_html( $a['h1'] ); ?></h1>
  <p class="art-meta">By Hasnivo Tech &middot; <time datetime="<?php echo esc_attr( $a['date'] ); ?>"><?php echo esc_html( wp_date( 'F j, Y', strtotime( $a['date'] ) ) ); ?></time> &middot; <?php echo (int) hnvl_ins_minutes( $a ); ?> min read</p>
  <img class="art-img" src="<?php echo esc_url( hnvl_ins_img( $key ) ); ?>" width="1200" height="630" alt="<?php echo esc_attr( hnvl_ins_alt( $key ) ); ?>" fetchpriority="high">
  <div class="quick"><b>Quick answer</b><p><?php echo esc_html( $a['quick'] ); ?></p></div>
</div></section>
<section class="vt-sec" style="padding-top:0"><div class="wrap art">
	<?php
	$figs = hnvl_ins_figs( $key );
	$h2n  = 0;
	foreach ( $a['body'] as $b ) {
		if ( 'h2' === $b[0] ) {
			if ( $h2n > 0 ) {
				hnvl_ins_echo_figs( $figs, $h2n );
			}
			++$h2n;
			echo '<h2>' . esc_html( $b[1] ) . '</h2>';
		} elseif ( 'p' === $b[0] ) {
			echo '<p>' . hnvl_ins_inline( $b[1] ) . '</p>'; // phpcs:ignore
		} else {
			echo '<ul>';
			foreach ( $b[1] as $li ) {
				echo '<li>' . hnvl_ins_inline( $li ) . '</li>'; // phpcs:ignore
			}
			echo '</ul>';
		}
	}
	hnvl_ins_echo_figs( $figs, $h2n );
	?>
  <div class="tk"><strong>Key takeaways</strong><ul>
	<?php foreach ( $a['takeaways'] as $tk ) : ?><li><?php echo esc_html( $tk ); ?></li><?php endforeach; ?>
  </ul></div>
  <h2>Frequently asked questions</h2>
  <div class="faq-list">
	<?php foreach ( $a['faq'] as $f ) : ?>
    <details class="faq-item" name="faq"><summary><h3><?php echo esc_html( $f[0] ); ?></h3></summary><p><?php echo esc_html( $f[1] ); ?></p></details>
	<?php endforeach; ?>
  </div>
</div></section>
<section class="vt-sec"><div class="wrap">
  <h2>Keep reading</h2>
  <div class="vt-cards">
	<?php foreach ( $a['related'] as $slug ) : if ( ! isset( $all[ $slug ] ) ) { continue; } $r = $all[ $slug ]; ?>
    <a class="vt-card" href="<?php echo esc_url( home_url( hnvl_ins_path( $slug ) ) ); ?>"><img class="thumb" src="<?php echo esc_url( hnvl_ins_img( $slug ) ); ?>" width="1200" height="630" alt="<?php echo esc_attr( hnvl_ins_alt( $slug ) ); ?>" loading="lazy"><span class="eyebrow"><?php echo esc_html( $r['kw'] ); ?></span><h3><?php echo esc_html( $r['h1'] ); ?></h3><p><?php echo esc_html( $r['quick'] ); ?></p></a>
	<?php endforeach; ?>
  </div>
</div></section>
	<?php
	hnvl_ins_foot();
	exit;
}
