<?php
/**
 * Email (SMTP) settings: sends the site's email (access requests, contact form) through the owner's
 * mailbox, e.g. Gmail with an App Password, because a VPS usually cannot send mail directly.
 * Settings > Hasnivo Email. The password is typed by the owner in the admin; it is stored encrypted and never shown again.
 * Optional: define HNVL_SMTP_PASS in wp-config.php to keep the password out of the database.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hnvl_smtp_defaults() {
	return array(
		'host'      => 'smtp.gmail.com',
		'port'      => 587,
		'secure'    => 'tls',
		'user'      => '',
		'pass_enc'  => '',
		'from_name' => 'Hasnivo Tech',
	);
}

function hnvl_smtp_get() {
	$o = get_option( 'hnvl_smtp', array() );
	return array_merge( hnvl_smtp_defaults(), is_array( $o ) ? $o : array() );
}

function hnvl_smtp_key() {
	return hash( 'sha256', wp_salt( 'auth' ), true );
}

function hnvl_smtp_encrypt( $plain ) {
	if ( '' === $plain ) {
		return '';
	}
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return 'p:' . base64_encode( $plain ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}
	$iv  = random_bytes( 16 );
	$enc = openssl_encrypt( $plain, 'aes-256-cbc', hnvl_smtp_key(), OPENSSL_RAW_DATA, $iv );
	return 'e:' . base64_encode( $iv . $enc ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
}

function hnvl_smtp_decrypt( $stored ) {
	if ( '' === $stored ) {
		return '';
	}
	if ( 'p:' === substr( $stored, 0, 2 ) ) {
		return (string) base64_decode( substr( $stored, 2 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}
	if ( 'e:' !== substr( $stored, 0, 2 ) || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}
	$raw = base64_decode( substr( $stored, 2 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	if ( false === $raw || strlen( $raw ) < 17 ) {
		return '';
	}
	$dec = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', hnvl_smtp_key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
	return false === $dec ? '' : $dec;
}

function hnvl_smtp_password() {
	if ( defined( 'HNVL_SMTP_PASS' ) && HNVL_SMTP_PASS ) {
		return (string) HNVL_SMTP_PASS;
	}
	$s = hnvl_smtp_get();
	return hnvl_smtp_decrypt( (string) $s['pass_enc'] );
}

function hnvl_smtp_ready() {
	$s = hnvl_smtp_get();
	return '' !== $s['host'] && '' !== $s['user'] && '' !== hnvl_smtp_password();
}

/* ---------- send through SMTP ---------- */

add_action( 'phpmailer_init', 'hnvl_smtp_configure' );
function hnvl_smtp_configure( $phpmailer ) {
	if ( ! hnvl_smtp_ready() ) {
		return;
	}
	$s                    = hnvl_smtp_get();
	$phpmailer->isSMTP();
	$phpmailer->Host       = $s['host'];
	$phpmailer->Port       = (int) $s['port'];
	$phpmailer->SMTPAuth   = true;
	$phpmailer->Username   = $s['user'];
	$phpmailer->Password   = hnvl_smtp_password();
	$phpmailer->SMTPSecure = in_array( $s['secure'], array( 'tls', 'ssl' ), true ) ? $s['secure'] : '';
	$phpmailer->SMTPAutoTLS = ( 'tls' === $s['secure'] );
	// Gmail only accepts mail "from" the signed-in address.
	$phpmailer->setFrom( $s['user'], $s['from_name'], false );
}

add_action(
	'wp_mail_failed',
	function ( $err ) {
		$msg = is_wp_error( $err ) ? $err->get_error_message() : 'unknown error';
		update_option( 'hnvl_smtp_last_error', mb_substr( wp_strip_all_tags( $msg ), 0, 300 ), false );
	}
);

/* ---------- settings page ---------- */

add_action( 'admin_menu', 'hnvl_smtp_menu' );
function hnvl_smtp_menu() {
	add_options_page( 'Hasnivo Email', 'Hasnivo Email', 'manage_options', 'hnvl-smtp', 'hnvl_smtp_page' );
}

add_action( 'admin_post_hnvl_save_smtp', 'hnvl_smtp_save' );
function hnvl_smtp_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', 403 );
	}
	check_admin_referer( 'hnvl_smtp' );
	$old  = hnvl_smtp_get();
	$pass = isset( $_POST['pass'] ) ? trim( (string) wp_unslash( $_POST['pass'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$pass = preg_replace( '/\s+/', '', $pass ); // Google shows App Passwords in groups of 4.
	$new  = array(
		'host'      => sanitize_text_field( wp_unslash( isset( $_POST['host'] ) ? $_POST['host'] : '' ) ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'port'      => max( 1, min( 65535, (int) ( isset( $_POST['port'] ) ? $_POST['port'] : 587 ) ) ),
		'secure'    => in_array( isset( $_POST['secure'] ) ? $_POST['secure'] : '', array( 'tls', 'ssl', 'none' ), true ) ? sanitize_key( $_POST['secure'] ) : 'tls', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'user'      => sanitize_email( wp_unslash( isset( $_POST['user'] ) ? $_POST['user'] : '' ) ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'from_name' => sanitize_text_field( wp_unslash( isset( $_POST['from_name'] ) ? $_POST['from_name'] : '' ) ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		'pass_enc'  => '' !== $pass ? hnvl_smtp_encrypt( $pass ) : $old['pass_enc'], // blank = keep the saved password
	);
	if ( '' === $new['from_name'] ) {
		$new['from_name'] = 'Hasnivo Tech';
	}
	update_option( 'hnvl_smtp', $new, false );
	delete_option( 'hnvl_smtp_last_error' );
	wp_safe_redirect( add_query_arg( array( 'page' => 'hnvl-smtp', 'saved' => 1 ), admin_url( 'options-general.php' ) ) );
	exit;
}

add_action( 'admin_post_hnvl_test_smtp', 'hnvl_smtp_test' );
function hnvl_smtp_test() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', 403 );
	}
	check_admin_referer( 'hnvl_smtp_test' );
	delete_option( 'hnvl_smtp_last_error' );
	$to = sanitize_email( hnvl_opt( 'email' ) );
	$ok = is_email( $to ) && wp_mail( $to, 'Hasnivo Tech: test email', "This is a test email from your website.\nIf you can read this, request notifications will reach you.\n" );
	wp_safe_redirect( add_query_arg( array( 'page' => 'hnvl-smtp', 'test' => $ok ? 'ok' : 'fail' ), admin_url( 'options-general.php' ) ) );
	exit;
}

function hnvl_smtp_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s    = hnvl_smtp_get();
	$err  = (string) get_option( 'hnvl_smtp_last_error', '' );
	$has  = '' !== hnvl_smtp_password();
	$to   = sanitize_email( hnvl_opt( 'email' ) );
	$test = isset( $_GET['test'] ) ? sanitize_key( $_GET['test'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap"><h1>Hasnivo Email (SMTP)</h1>';
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success"><p>Saved. Ab "Send test email" dabayen.</p></div>';
	}
	if ( 'ok' === $test ) {
		echo '<div class="notice notice-success"><p>Test email bhej di gayi hai ' . esc_html( $to ) . ' par. Inbox (ya Spam) check karein.</p></div>';
	} elseif ( 'fail' === $test ) {
		echo '<div class="notice notice-error"><p>Email nahi gayi.' . ( '' !== $err ? ' Wajah: <code>' . esc_html( $err ) . '</code>' : '' ) . '</p></div>';
	}
	echo '<p>Ye site ki emails (Request access aur Contact) aap ke Gmail ke zariye bhejta hai. Email aap ke "Contact email" (<b>' . esc_html( $to ) . '</b>) par aayegi.</p>';
	echo '<ol style="max-width:720px"><li>Google Account → Security → <b>2-Step Verification</b> ON karein.</li><li>Phir Google Account mein <b>"App passwords"</b> search karein, ek naam (jaise Hasnivo Website) dein aur 16 harf ka code copy karein.</li><li>Neeche apna Gmail aur wo code dalein, Save karein, phir "Send test email".</li></ol>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="hnvl_save_smtp">';
	wp_nonce_field( 'hnvl_smtp' );
	echo '<table class="form-table" role="presentation">';
	echo '<tr><th>Gmail address</th><td><input type="email" name="user" class="regular-text" value="' . esc_attr( $s['user'] ) . '" placeholder="yourname@gmail.com" autocomplete="off"></td></tr>';
	echo '<tr><th>App Password</th><td><input type="password" name="pass" class="regular-text" value="" autocomplete="new-password" placeholder="' . ( $has ? '(saved - khali chhorein to wahi rahega)' : 'xxxx xxxx xxxx xxxx' ) . '"><p class="description">Apna asli Gmail password nahi, sirf App Password.</p></td></tr>';
	echo '<tr><th>Sender name</th><td><input type="text" name="from_name" class="regular-text" value="' . esc_attr( $s['from_name'] ) . '"></td></tr>';
	echo '<tr><th>Server</th><td><input type="text" name="host" value="' . esc_attr( $s['host'] ) . '"> Port <input type="number" name="port" style="width:80px" value="' . (int) $s['port'] . '"> <select name="secure">';
	foreach ( array( 'tls' => 'TLS (587)', 'ssl' => 'SSL (465)', 'none' => 'None' ) as $k => $l ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['secure'], $k, false ) . '>' . esc_html( $l ) . '</option>';
	}
	echo '</select><p class="description">Gmail ke liye ye settings jaisi hain waisi hi rehne dein.</p></td></tr>';
	echo '</table>';
	submit_button( 'Save' );
	echo '</form>';
	echo '<hr><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="hnvl_test_smtp">';
	wp_nonce_field( 'hnvl_smtp_test' );
	submit_button( 'Send test email', 'secondary', 'submit', false );
	echo '</form></div>';
}
