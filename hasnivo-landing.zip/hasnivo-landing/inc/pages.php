<?php
/**
 * Gives the other pages (Plans, Request access, Contact, ...) the same look as the new Home page.
 * Only an extra stylesheet is added; the old theme still renders the content. Deactivating the plugin removes it.
 *
 * @package hasnivo-landing
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'body_class', 'hnvl_skin_body_class' );
function hnvl_skin_body_class( $classes ) {
	if ( ! is_admin() && ! hnvl_is_landing() ) {
		$classes[] = 'hnvl-skin';
	}
	return $classes;
}

add_action( 'wp_enqueue_scripts', 'hnvl_skin_assets', 50 );
function hnvl_skin_assets() {
	if ( is_admin() || hnvl_is_landing() ) {
		return;
	}
	wp_enqueue_style( 'hnvl-skin-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=DM+Sans:wght@400;500;700&family=JetBrains+Mono:wght@500&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters
	wp_enqueue_style( 'hnvl-skin', HNVL_URL . 'assets/pages.css', array(), HNVL_VERSION . '.' . (int) @filemtime( HNVL_DIR . 'assets/pages.css' ) );
}

/**
 * Same menu on every page as on the Home page (Home, Features, Plans, Services, FAQ, Contact).
 * Replaces only the old theme's main menu; the rest of the header is untouched.
 */
add_filter( 'pre_wp_nav_menu', 'hnvl_same_menu', 10, 2 );
function hnvl_same_menu( $output, $args ) {
	if ( is_admin() || hnvl_is_landing() || ! isset( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $output;
	}
	$items = array(
		'Home'     => '/#home',
		'Features' => '/#features',
		'Plans'    => '/#plans',
		'Insights' => '/insights/',
		'Services' => '/#services',
		'FAQ'      => '/#faq',
		'Contact'  => '/#contact',
	);
	$html = '<ul class="menu hnvl-menu">';
	foreach ( $items as $label => $path ) {
		$html .= '<li><a href="' . esc_url( home_url( $path ) ) . '">' . esc_html( $label ) . '</a></li>';
	}
	return $html . '</ul>';
}

/**
 * The old Blog was removed. Send /blog/ to Insights (301) and show "Insights" in the old theme's footer link.
 */
add_action( 'template_redirect', 'hnvl_blog_redirect', 1 );
function hnvl_blog_redirect() {
	if ( is_admin() ) {
		return;
	}
	if ( 'blog' === trim( hnvl_request_path(), '/' ) ) {
		wp_safe_redirect( home_url( '/insights/' ), 301 );
		exit;
	}
}

add_action( 'template_redirect', 'hnvl_footer_blog_link', 3 );
function hnvl_footer_blog_link() {
	if ( is_admin() || hnvl_is_landing() ) {
		return;
	}
	ob_start(
		function ( $html ) {
			return str_replace(
				'<a href="' . home_url( '/blog/' ) . '">Blog</a>',
				'<a href="' . home_url( '/insights/' ) . '">Insights</a>',
				$html
			);
		}
	);
}
