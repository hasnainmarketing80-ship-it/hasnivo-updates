/* Hasnivo Tech landing: animated WhatsApp demo scenes + feature visuals. No inline code, CSP-safe. */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ------------------------------------------------------------------ hero phone */
  const feed = $('#waFeed');
  if (feed) {
    const nameEl = $('#waName'), subEl = $('#waSub'), avEl = $('#waAv');
    const tabs = $$('.scene-tab');
    const floats = { order: $('#fOrder'), book: $('#fBook'), reply: $('#fReply') };
    let run = 0, visible = true;
    const cancel = {};
    new IntersectionObserver(es => es.forEach(e => { visible = e.isIntersecting; })).observe(feed);

    const wait = async (ms, id) => {
      if (reduced) { if (id !== run) throw cancel; return; }
      await sleep(ms);
      while (!visible && id === run) await sleep(300);
      if (id !== run) throw cancel;
    };
    const scroll = () => { feed.scrollTo({ top: feed.scrollHeight, behavior: reduced ? 'auto' : 'smooth' }); };
    const push = n => { feed.appendChild(n); requestAnimationFrame(() => n.classList.add('show')); scroll(); return n; };

    const bubble = (who, text, time, extra) => {
      const b = el('div', 'wa-msg ' + who);
      b.appendChild(el('span', 'wa-t', text));
      const m = el('span', 'wa-meta');
      m.appendChild(el('time', null, time));
      if (who === 'me') m.appendChild(el('i', 'wa-tick', '✓✓'));
      b.appendChild(m);
      if (extra) b.classList.add(extra);
      return b;
    };
    const typing = () => { const t = el('div', 'wa-msg bot wa-typing'); for (let i = 0; i < 3; i++) t.appendChild(el('b')); return t; };

    async function bot(text, time, id, think) {
      const t = push(typing());
      await wait(think || 900, id);
      t.remove();
      return push(bubble('bot', text, time));
    }
    async function me(text, time, id, pause) {
      await wait(pause || 700, id);
      return push(bubble('me', text, time));
    }
    function card(cls) { return el('div', 'wa-card ' + cls); }
    function chips(labels) {
      const c = el('div', 'wa-chips');
      labels.forEach(l => c.appendChild(el('span', 'wa-chip', l)));
      return c;
    }
    function checkSvg() {
      const ns = 'http://www.w3.org/2000/svg';
      const s = document.createElementNS(ns, 'svg'); s.setAttribute('viewBox', '0 0 52 52'); s.setAttribute('class', 'okmark'); s.setAttribute('aria-hidden', 'true');
      const c = document.createElementNS(ns, 'circle'); c.setAttribute('cx', '26'); c.setAttribute('cy', '26'); c.setAttribute('r', '23');
      const p = document.createElementNS(ns, 'path'); p.setAttribute('d', 'M15 27l7 7 15-16');
      s.appendChild(c); s.appendChild(p); return s;
    }
    function notify(key) {
      const f = floats[key]; if (!f || reduced) { if (f) f.classList.add('on'); return; }
      f.classList.add('on'); setTimeout(() => f.classList.remove('on'), 3600);
    }
    function days() {
      const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], out = [], d = new Date();
      d.setDate(d.getDate() + 1);
      for (let i = 0; i < 5; i++) { out.push([names[d.getDay()], d.getDate()]); d.setDate(d.getDate() + 1); }
      return out;
    }

    const scenes = {
      food: {
        name: 'Biryani Kitchen', sub: 'online · open 24 hours', av: 'BK',
        async play(id) {
          await me('Hi, can you send me the menu?', '2:14 AM', id, 400);
          await bot('Hello! 👋 We are open 24 hours. Here is our menu:', '2:14 AM', id);
          const m = card('menu'); m.appendChild(el('b', 'wa-card-rest', '🍽 Biryani Kitchen')); m.appendChild(el('b', 'wa-card-h', 'Fast Food · 5 items'));
          [['🍔', 'Zinger Burger', 'Rs 450'], ['🍛', 'Chicken Biryani', 'Rs 380'], ['🥔', 'Aloo Biryani', 'Rs 280'], ['🌯', 'Chicken Shawarma', 'Rs 220'], ['🍟', 'Fries', 'Rs 180']].forEach(it => {
            const r = el('div', 'row'); r.appendChild(el('i', 'em', it[0])); r.appendChild(el('span', null, it[1])); r.appendChild(el('em', 'pr', it[2])); m.appendChild(r);
          });
          push(m); await wait(1000, id);
          await me('2 Chicken Biryani and 1 Zinger', '2:15 AM', id, 900);
          await bot('Great choice! 😋 Pickup or home delivery?', '2:15 AM', id);
          const c = push(chips(['Pickup', 'Home delivery'])); await wait(900, id);
          c.lastChild.classList.add('tap'); await wait(450, id);
          await me('Home delivery', '2:15 AM', id, 200);
          await bot('Please send your address 📍', '2:15 AM', id, 700);
          await me('Gulberg, Street 4, House 12', '2:16 AM', id, 1200);
          await bot('Thank you! Confirming your order…', '2:16 AM', id, 800);
          const o = card('order'); o.appendChild(checkSvg());
          const t = el('div', 'ot'); t.appendChild(el('b', null, 'ORDER #1042 CONFIRMED'));
          t.appendChild(el('span', null, '2 × Chicken Biryani, 1 × Zinger Burger')); t.appendChild(el('span', null, 'Total Rs 1,210 · Home delivery'));
          o.appendChild(t); push(o); notify('order'); await wait(1300, id);
          const tr = card('track'); tr.appendChild(el('b', 'wa-card-h', 'Order status'));
          const stp = el('div', 'steps3');
          [['✅', 'Confirmed'], ['🍳', 'Preparing'], ['🛵', 'On the way']].forEach(x => { const d = el('div', 'st'); d.appendChild(el('i', null, x[0])); d.appendChild(el('span', null, x[1])); stp.appendChild(d); });
          tr.appendChild(stp); push(tr);
          for (let i = 0; i < 3; i++) { await wait(900, id); stp.children[i].classList.add('on'); }
          await wait(600, id); await bot('Your order will arrive in about 25 minutes. Thank you! 🙏', '2:17 AM', id, 800);
        }
      },
      appt: {
        name: 'Smile Dental Clinic', sub: 'online · books appointments', av: 'SD',
        async play(id) {
          await me('I need a checkup appointment tomorrow', '9:41 PM', id, 400);
          await bot('Of course! 😊 Here are tomorrow\'s free times. Which one suits you?', '9:41 PM', id);
          const c = card('cal'); c.appendChild(el('b', 'wa-card-h', 'Checkup · Smile Dental'));
          const dr = el('div', 'days'); days().forEach((d, i) => { const x = el('div', 'day' + (i === 0 ? ' sel' : '')); x.appendChild(el('small', null, d[0])); x.appendChild(el('b', null, String(d[1]))); dr.appendChild(x); });
          c.appendChild(dr);
          const sl = el('div', 'slots'); const slots = [['11:00 AM', 0], ['1:00 PM', 1], ['3:00 PM', 0], ['5:30 PM', 0]];
          slots.forEach(s => sl.appendChild(el('span', 'slot' + (s[1] ? ' off' : ''), s[0]))); c.appendChild(sl);
          c.appendChild(el('small', 'cal-foot', 'Only free times are shown'));
          push(c); await wait(1100, id);
          sl.children[0].classList.add('hover'); await wait(500, id); sl.children[0].classList.remove('hover');
          sl.children[2].classList.add('pick'); await wait(500, id);
          await me('3:00 PM works', '9:42 PM', id, 200);
          await bot('Done ✅ Your booking is confirmed.', '9:42 PM', id, 800);
          const b = card('booked'); b.appendChild(checkSvg());
          const t = el('div', 'ot'); t.appendChild(el('b', null, 'BOOKING CONFIRMED'));
          t.appendChild(el('span', null, 'Checkup · Tomorrow 3:00 PM')); t.appendChild(el('span', null, '⏰ Reminder arrives in this chat'));
          b.appendChild(t); push(b); notify('book'); await wait(1600, id);
          const rem = el('div', 'wa-note', '⏰ Next day, 1 hour before'); push(rem); await wait(900, id);
          await bot('⏰ Reminder: your appointment at Smile Dental is today at 3:00 PM. See you soon!', '2:00 PM', id, 900);
        }
      },
      help: {
        name: 'Your Business', sub: 'online · 24/7 AI assistant', av: 'AI',
        async play(id) {
          await me('What are your opening hours?', '11:20 PM', id, 400);
          await bot('We are open 24 hours, day or night. I am always here. 🌙', '11:20 PM', id);
          const v = el('div', 'wa-msg me voice'); const p = el('i', 'play', '▶'); v.appendChild(p);
          const w = el('div', 'wave'); for (let i = 0; i < 18; i++) w.appendChild(el('b')); v.appendChild(w);
          v.appendChild(el('span', 'wa-meta', '0:07 ✓✓')); await wait(1100, id); push(v);
          await bot('Got your voice note 🎧 Delivery to your area costs Rs 150.', '11:21 PM', id, 1300);
          await bot('Would you like to talk to someone from our team?', '11:21 PM', id, 800);
          const c = push(chips(['No thanks', 'Yes, please'])); await wait(1000, id);
          c.lastChild.classList.add('tap'); await wait(450, id);
          await me('Yes, please connect me to the team', '11:21 PM', id, 200);
          const n = el('div', 'wa-note', '👤 Ahmed (your team) joined the chat'); push(n); notify('reply');
          await bot('Hello! I am Ahmed. How can I help you?', '11:22 PM', id, 1200);
        }
      }
    };
    /* ---------------------------------------------------------------- interactive flow
       The visitor picks a demo, watches the sample chat, gives feedback, chooses a bot and leaves details.
       Typed answers go through the input bar; plan and bot type are drop-downs inside the chat. */
    let CFG = {};
    try { CFG = JSON.parse((document.querySelector('meta[name="hasnivo-config"]') || {}).content || '{}'); } catch (_) { CFG = {}; }
    let planList = [];
    try { planList = (JSON.parse((document.getElementById('hnvl-plans') || {}).textContent || '{}').plans || []); } catch (_) { planList = []; }
    const BOT_TYPES = ['Food & order / Restaurants', 'Clinic / Appointment booking', 'Other'];
    const DEMO_NAMES = { food: 'Restaurant orders', appt: 'Clinic appointments', help: 'Customer support' };
    const botFor = { food: BOT_TYPES[0], appt: BOT_TYPES[1], help: BOT_TYPES[2] };
    const form = $('#waForm'), input = $('#waInput'), sendBtn = $('#waSend'), tagEl = $('#waTag');
    let expect = null; /* { type, resolve } while the bot is waiting for typed text */
    let pick = null;   /* { resolve } while a button row is waiting */

    const now = () => new Date().toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' });
    const setHead = (name, sub, av, tag) => { nameEl.textContent = name; subEl.textContent = sub; avEl.textContent = av; if (tagEl) tagEl.textContent = tag; };
    const head = () => setHead('Hasnivo Tech', 'online · AI assistant', 'HT', 'Live');
    const setTabs = key => tabs.forEach(t => { const on = t.dataset.scene === key; t.classList.toggle('on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); });
    function setInput(type, hint) {
      if (!input) return;
      input.disabled = !type; sendBtn.disabled = !type;
      input.type = type || 'text'; input.value = '';
      input.setAttribute('inputmode', type === 'tel' ? 'tel' : type === 'email' ? 'email' : 'text');
      input.placeholder = type ? hint : 'Tap an option above';
      if (type && !reduced) input.focus({ preventScroll: true });
    }
    const hsay = (text, id, think) => bot(text, now(), id, think);

    /* a row of real buttons; resolves with the tapped key */
    function choose(id, items) {
      return new Promise((resolve, reject) => {
        const row = el('div', 'wa-chips live');
        items.forEach(it => {
          const b = el('button', 'wa-chip', it[1]); b.type = 'button';
          b.addEventListener('click', () => {
            if (id !== run || !pick) return;
            pick = null; row.classList.add('done');
            $$('.wa-chip', row).forEach(x => { x.disabled = true; if (x !== b) x.classList.add('dim'); });
            b.classList.add('tap');
            resolve([it[0], it[1]]);
          });
          row.appendChild(b);
        });
        push(row); pick = { resolve, reject, id };
      });
    }
    /* free text typed by the visitor; validated before it is accepted */
    function ask(id, type, hint, valid, retry) {
      return new Promise(resolve => {
        setInput(type, hint);
        expect = { id, valid, retry, resolve, type };
      });
    }
    if (form) form.addEventListener('submit', async e => {
      e.preventDefault();
      const v = input.value.trim(); if (!v) return;
      if (!expect) return;
      const ex = expect;
      push(bubble('me', v, now()));
      if (!ex.valid(v)) { input.value = ''; try { await hsay(ex.retry, ex.id, 600); } catch (_) { } return; }
      expect = null; setInput(null);
      ex.resolve(v);
    });

    function formCard(id) {
      return new Promise(resolve => {
        const c = card('lead'); c.appendChild(el('b', 'wa-card-h', 'Almost done'));
        const mk = (label, opts, sel) => {
          const w = el('label', 'lf'); w.appendChild(el('span', null, label));
          const s = el('select'); opts.forEach(o => { const x = el('option', null, o[1]); x.value = o[0]; s.appendChild(x); }); s.value = sel; w.appendChild(s); c.appendChild(w); return s;
        };
        const plans = planList.length ? planList.map(p => [p.name, p.name + ' · ' + p.price + (p.per || '')]) : [['Free', 'Free']];
        const pSel = mk('Plan', plans, (planList.find(p => p.popular) || planList[0] || { name: 'Free' }).name);
        const bSel = mk('Bot type', BOT_TYPES.map(t => [t, t]), botType);
        const go = el('button', 'lf-go', 'Send my details'); go.type = 'button'; c.appendChild(go);
        go.addEventListener('click', () => { if (id !== run) return; go.disabled = true; pSel.disabled = true; bSel.disabled = true; go.textContent = 'Sending…'; resolve({ plan: pSel.value, bot: bSel.value }); });
        push(c);
      });
    }
    async function submitLead(payload) {
      const t = await fetch(CFG.ajaxUrl + '?action=hnvl_token', { credentials: 'same-origin' }).then(r => r.json());
      if (!t || !t.success) throw new Error('token');
      const body = new URLSearchParams(Object.assign({ action: 'hnvl_demo_lead', nonce: t.data.nonce, website: '' }, payload));
      const res = await fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) throw new Error('failed');
    }

    let demoKey = null, rating = '', botType = BOT_TYPES[0];

    async function playScene(key, id) {
      demoKey = key; setTabs(key);
      const sc = scenes[key];
      push(el('div', 'wa-note', 'Connecting you to a sample business…')); await wait(900, id);
      setHead(sc.name, sc.sub, sc.av, 'Sample');
      feed.textContent = '';
      await sc.play(id);
      await wait(1500, id);
      push(el('div', 'wa-note', 'Sample chat ended')); await wait(700, id);
      head();
    }

    async function flow(startKey, id) {
      try {
        head(); feed.textContent = ''; feed.scrollTop = 0; setInput(null); setTabs(startKey || null);
        Object.values(floats).forEach(f => f && f.classList.remove('on'));
        let key = startKey;
        if (!key) {
          await hsay('Hi 👋 Welcome to Hasnivo Tech. I can show you how a WhatsApp bot talks to your customers. What would you like to see?', id, 700);
          const c = await choose(id, [['food', '🍔 Restaurant orders'], ['appt', '📅 Clinic appointments'], ['help', '💬 Customer support']]);
          key = c[0]; push(bubble('me', c[1], now()));
        }
        await playScene(key, id);

        await hsay('That was a sample chat. How did it feel?', id, 800);
        const r = await choose(id, [['Loved it', '😍 Loved it'], ['Good', '👍 Good'], ['Not sure yet', '🤔 Not sure yet']]);
        rating = r[0]; push(bubble('me', r[1], now()));
        await hsay(rating === 'Not sure yet' ? 'No problem, it is a lot to take in. 🙂 Which bot would suit your business best?' : 'Glad to hear it! 🙌 Which bot would you like to buy?', id, 900);
        const b = await choose(id, [[BOT_TYPES[0], '🍔 Food & order bot'], [BOT_TYPES[1], '📅 Appointment bot'], [BOT_TYPES[2], '✨ Something else']]);
        botType = b[0]; push(bubble('me', b[1], now()));

        await hsay('Great choice! Let me take a few details so our team can set it up for you.', id, 900);
        await hsay('What is your name?', id, 700);
        const name = await ask(id, 'text', 'Type your name', v => v.length >= 2 && v.length <= 100, 'Please enter your name (at least 2 letters).');
        await hsay('Nice to meet you, ' + name.split(/\s+/)[0] + '! 😊 What is your WhatsApp number?', id, 800);
        const phone = await ask(id, 'tel', 'e.g. 0321 1234567', v => /^\d{8,15}$/.test(v.replace(/[\s\-().]/g, '').replace(/^\+/, '')), 'That number does not look right. Please send it with digits only, for example 0321 1234567.');
        await hsay('And your email address?', id, 700);
        const email = await ask(id, 'email', 'name@example.com', v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) && v.length <= 254, 'That email does not look right. Please check it and send again.');
        await hsay('Last step: choose your plan and the type of bot.', id, 800);
        let sent = false;
        while (!sent) {
          const ch = await formCard(id);
          try {
            await submitLead({ name, phone, email, plan: ch.plan, bot: ch.bot, demo: DEMO_NAMES[demoKey] || '', rating });
            sent = true;
            await hsay('Thank you, ' + name.split(/\s+/)[0] + '! ✅ Your details reached our team.', id, 1000);
            const o = card('order'); o.appendChild(checkSvg());
            const t = el('div', 'ot'); t.appendChild(el('b', null, 'REQUEST SENT'));
            t.appendChild(el('span', null, ch.bot)); t.appendChild(el('span', null, 'Plan: ' + ch.plan + ' · We will message you on WhatsApp'));
            o.appendChild(t); push(o); await wait(900, id);
          } catch (e) {
            if (e === cancel) throw e;
            const wa = CFG.whatsapp ? 'https://wa.me/' + CFG.whatsapp : '';
            await hsay('Sorry, I could not send your details just now.' + (wa ? ' You can also message us directly on WhatsApp.' : ' Please try again.'), id, 800);
            const items = [['again', '↻ Try again']]; const rr = await choose(id, items); push(bubble('me', rr[1], now()));
          }
        }
        if (CFG.whatsapp) {
          const a = el('a', 'wa-link', '💬 Chat with us on WhatsApp'); a.href = 'https://wa.me/' + CFG.whatsapp + '?text=' + encodeURIComponent('Hello Hasnivo Tech, I tried the demo chat and I am interested in the ' + botType + ' bot.'); a.target = '_blank'; a.rel = 'noopener noreferrer';
          push(a);
        }
        await wait(500, id);
        await hsay('Want to see another demo?', id, 800);
        const again = await choose(id, [['food', '🍔 Restaurant orders'], ['appt', '📅 Clinic appointments'], ['help', '💬 Customer support']]);
        push(bubble('me', again[1], now()));
        start(again[0]);
      } catch (e) { if (e !== cancel) throw e; }
    }
    function start(key) { run++; pick = null; expect = null; flow(key || null, run); }
    tabs.forEach(t => t.addEventListener('click', () => start(t.dataset.scene)));
    const replay = $('#waReplay'); if (replay) replay.addEventListener('click', () => start(null));
    start(null);

    /* gentle 3D tilt that follows the pointer (desktop only) */
    const stage = $('#stage');
    if (stage && !reduced && window.matchMedia('(hover:hover) and (min-width: 900px)').matches) {
      const hero = $('.hero');
      hero.addEventListener('pointermove', e => {
        const r = stage.getBoundingClientRect();
        const x = (e.clientX - (r.left + r.width / 2)) / window.innerWidth, y = (e.clientY - (r.top + r.height / 2)) / window.innerHeight;
        stage.style.setProperty('--ry', (-6 + x * 14).toFixed(2) + 'deg');
        stage.style.setProperty('--rx', (3 - y * 10).toFixed(2) + 'deg');
      });
      hero.addEventListener('pointerleave', () => { stage.style.removeProperty('--ry'); stage.style.removeProperty('--rx'); });
    }
  }

  /* ------------------------------------------------------------------ feature visuals */
  function loopViz(root, steps, gap) {
    if (!root) return;
    let i = 0, on = false;
    const tick = () => { if (!on) return; steps[i % steps.length](); i++; };
    new IntersectionObserver(es => es.forEach(e => { on = e.isIntersecting; })).observe(root);
    if (reduced) { steps[steps.length - 1](); return; }
    setInterval(tick, gap);
  }

  const appt = $('[data-viz="appt"]');
  if (appt) {
    const d = new Date(); d.setDate(d.getDate() + 1);
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const head = el('div', 'viz-h'); head.appendChild(el('b', null, 'Checkup')); head.appendChild(el('span', null, d.toLocaleString('en', { month: 'long', year: 'numeric' }))); appt.appendChild(head);
    const row = el('div', 'days');
    for (let i = 0; i < 6; i++) { const x = el('div', 'day' + (i === 0 ? ' sel' : '')); x.appendChild(el('small', null, names[d.getDay()])); x.appendChild(el('b', null, String(d.getDate()))); row.appendChild(x); d.setDate(d.getDate() + 1); }
    appt.appendChild(row);
    const sl = el('div', 'slots'); ['11:00 AM', '1:00 PM', '3:00 PM', '5:30 PM'].forEach((t, i) => sl.appendChild(el('span', 'slot' + (i === 1 ? ' off' : ''), t))); appt.appendChild(sl);
    const done = el('div', 'viz-done', '✓ Booking confirmed · reminder goes out automatically'); appt.appendChild(done);
    const reset = () => { $$('.slot', sl).forEach(s => s.classList.remove('pick', 'hover')); done.classList.remove('on'); };
    loopViz(appt, [
      () => { reset(); sl.children[0].classList.add('hover'); },
      () => { reset(); sl.children[2].classList.add('hover'); },
      () => { sl.children[2].classList.remove('hover'); sl.children[2].classList.add('pick'); },
      () => { done.classList.add('on'); },
      () => { },
    ], 1100);
  }

  const food = $('[data-viz="food"]');
  if (food) {
    food.appendChild(el('div', 'viz-rest', '🍽 Biryani Kitchen')); const head = el('div', 'viz-h'); head.appendChild(el('b', null, 'Fast Food')); head.appendChild(el('span', null, '5 items')); food.appendChild(head);
    const items = [['Zinger Burger', 1], ['Chicken Biryani', 2], ['Aloo Biryani', 0], ['Chicken Shawarma', 0], ['Fries', 0]], qs = [];
    items.forEach(it => { const r = el('div', 'frow'); r.appendChild(el('span', null, it[0])); const q = el('div', 'qty'); q.appendChild(el('i', null, '−')); const n = el('b', null, '0'); q.appendChild(n); q.appendChild(el('i', null, '+')); r.appendChild(q); food.appendChild(r); qs.push([n, r, it[1]]); });
    const opts = el('div', 'opts'); opts.appendChild(el('span', 'opt', 'Pickup')); opts.appendChild(el('span', 'opt', 'Home delivery')); food.appendChild(opts);
    const send = el('div', 'viz-send', 'Place order'); food.appendChild(send);
    const reset = () => { qs.forEach(q => { q[0].textContent = '0'; q[1].classList.remove('hot'); }); $$('.opt', opts).forEach(o => o.classList.remove('pick')); send.classList.remove('sent'); send.textContent = 'Place order'; };
    loopViz(food, [
      () => { reset(); qs[0][0].textContent = '1'; qs[0][1].classList.add('hot'); },
      () => { qs[0][1].classList.remove('hot'); qs[1][0].textContent = '2'; qs[1][1].classList.add('hot'); },
      () => { qs[1][1].classList.remove('hot'); opts.lastChild.classList.add('pick'); },
      () => { send.classList.add('sent'); send.textContent = '✓ Order #1043 sent to you and your team'; },
      () => { },
    ], 1100);
  }

  /* marquee: duplicate track once so the loop is seamless */
  const mq = $('.marquee-track');
  if (mq && !reduced) mq.appendChild(mq.firstElementChild.cloneNode(true));
})();
