/* Hasnivo Tech landing: animated WhatsApp demo scenes + feature visuals. No inline code, CSP-safe. */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ------------------------------------------------------------------ hero phone */
  const feed = $('#waFeed');
  if (feed) {
    const nameEl = $('#waName'), subEl = $('#waSub'), avEl = $('#waAv');
    const tabs = $$('.scene-tab');
    const floats = { order: $('#fOrder'), book: $('#fBook'), reply: $('#fReply') };
    let run = 0, visible = true;
    const cancel = {};
    new IntersectionObserver(es => es.forEach(e => { visible = e.isIntersecting; })).observe(feed);

    const wait = async (ms, id) => {
      if (reduced) return;
      await sleep(ms);
      while (!visible && id === run) await sleep(300);
      if (id !== run) throw cancel;
    };
    const scroll = () => { feed.scrollTo({ top: feed.scrollHeight, behavior: reduced ? 'auto' : 'smooth' }); };
    const push = n => { feed.appendChild(n); requestAnimationFrame(() => n.classList.add('show')); scroll(); return n; };

    const bubble = (who, text, time, extra) => {
      const b = el('div', 'wa-msg ' + who);
      b.appendChild(el('span', 'wa-t', text));
      const m = el('span', 'wa-meta');
      m.appendChild(el('time', null, time));
      if (who === 'me') m.appendChild(el('i', 'wa-tick', '✓✓'));
      b.appendChild(m);
      if (extra) b.classList.add(extra);
      return b;
    };
    const typing = () => { const t = el('div', 'wa-msg bot wa-typing'); for (let i = 0; i < 3; i++) t.appendChild(el('b')); return t; };

    async function bot(text, time, id, think) {
      const t = push(typing());
      await wait(think || 900, id);
      t.remove();
      return push(bubble('bot', text, time));
    }
    async function me(text, time, id, pause) {
      await wait(pause || 700, id);
      return push(bubble('me', text, time));
    }
    function card(cls) { return el('div', 'wa-card ' + cls); }
    function chips(labels) {
      const c = el('div', 'wa-chips');
      labels.forEach(l => c.appendChild(el('span', 'wa-chip', l)));
      return c;
    }
    function checkSvg() {
      const ns = 'http://www.w3.org/2000/svg';
      const s = document.createElementNS(ns, 'svg'); s.setAttribute('viewBox', '0 0 52 52'); s.setAttribute('class', 'okmark'); s.setAttribute('aria-hidden', 'true');
      const c = document.createElementNS(ns, 'circle'); c.setAttribute('cx', '26'); c.setAttribute('cy', '26'); c.setAttribute('r', '23');
      const p = document.createElementNS(ns, 'path'); p.setAttribute('d', 'M15 27l7 7 15-16');
      s.appendChild(c); s.appendChild(p); return s;
    }
    function notify(key) {
      const f = floats[key]; if (!f || reduced) { if (f) f.classList.add('on'); return; }
      f.classList.add('on'); setTimeout(() => f.classList.remove('on'), 3600);
    }
    function days() {
      const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], out = [], d = new Date();
      d.setDate(d.getDate() + 1);
      for (let i = 0; i < 5; i++) { out.push([names[d.getDay()], d.getDate()]); d.setDate(d.getDate() + 1); }
      return out;
    }

    const scenes = {
      food: {
        name: 'Biryani Kitchen', sub: 'online · open 24 hours', av: 'BK',
        async play(id) {
          await me('Hi, can you send me the menu?', '2:14 AM', id, 400);
          await bot('Hello! 👋 We are open 24 hours. Here is our menu:', '2:14 AM', id);
          const m = card('menu'); m.appendChild(el('b', 'wa-card-rest', '🍽 Biryani Kitchen')); m.appendChild(el('b', 'wa-card-h', 'Fast Food · 5 items'));
          [['🍔', 'Zinger Burger', 'Rs 450'], ['🍛', 'Chicken Biryani', 'Rs 380'], ['🥔', 'Aloo Biryani', 'Rs 280'], ['🌯', 'Chicken Shawarma', 'Rs 220'], ['🍟', 'Fries', 'Rs 180']].forEach(it => {
            const r = el('div', 'row'); r.appendChild(el('i', 'em', it[0])); r.appendChild(el('span', null, it[1])); r.appendChild(el('em', 'pr', it[2])); m.appendChild(r);
          });
          push(m); await wait(1000, id);
          await me('2 Chicken Biryani and 1 Zinger', '2:15 AM', id, 900);
          await bot('Great choice! 😋 Pickup or home delivery?', '2:15 AM', id);
          const c = push(chips(['Pickup', 'Home delivery'])); await wait(900, id);
          c.lastChild.classList.add('tap'); await wait(450, id);
          await me('Home delivery', '2:15 AM', id, 200);
          await bot('Please send your address 📍', '2:15 AM', id, 700);
          await me('Gulberg, Street 4, House 12', '2:16 AM', id, 1200);
          await bot('Thank you! Confirming your order…', '2:16 AM', id, 800);
          const o = card('order'); o.appendChild(checkSvg());
          const t = el('div', 'ot'); t.appendChild(el('b', null, 'ORDER #1042 CONFIRMED'));
          t.appendChild(el('span', null, '2 × Chicken Biryani, 1 × Zinger Burger')); t.appendChild(el('span', null, 'Total Rs 1,210 · Home delivery'));
          o.appendChild(t); push(o); notify('order'); await wait(1300, id);
          const tr = card('track'); tr.appendChild(el('b', 'wa-card-h', 'Order status'));
          const stp = el('div', 'steps3');
          [['✅', 'Confirmed'], ['🍳', 'Preparing'], ['🛵', 'On the way']].forEach(x => { const d = el('div', 'st'); d.appendChild(el('i', null, x[0])); d.appendChild(el('span', null, x[1])); stp.appendChild(d); });
          tr.appendChild(stp); push(tr);
          for (let i = 0; i < 3; i++) { await wait(900, id); stp.children[i].classList.add('on'); }
          await wait(600, id); await bot('Your order will arrive in about 25 minutes. Thank you! 🙏', '2:17 AM', id, 800);
        }
      },
      appt: {
        name: 'Smile Dental Clinic', sub: 'online · books appointments', av: 'SD',
        async play(id) {
          await me('I need a checkup appointment tomorrow', '9:41 PM', id, 400);
          await bot('Of course! 😊 Here are tomorrow\'s free times. Which one suits you?', '9:41 PM', id);
          const c = card('cal'); c.appendChild(el('b', 'wa-card-h', 'Checkup · Smile Dental'));
          const dr = el('div', 'days'); days().forEach((d, i) => { const x = el('div', 'day' + (i === 0 ? ' sel' : '')); x.appendChild(el('small', null, d[0])); x.appendChild(el('b', null, String(d[1]))); dr.appendChild(x); });
          c.appendChild(dr);
          const sl = el('div', 'slots'); const slots = [['11:00 AM', 0], ['1:00 PM', 1], ['3:00 PM', 0], ['5:30 PM', 0]];
          slots.forEach(s => sl.appendChild(el('span', 'slot' + (s[1] ? ' off' : ''), s[0]))); c.appendChild(sl);
          c.appendChild(el('small', 'cal-foot', 'Only free times are shown'));
          push(c); await wait(1100, id);
          sl.children[0].classList.add('hover'); await wait(500, id); sl.children[0].classList.remove('hover');
          sl.children[2].classList.add('pick'); await wait(500, id);
          await me('3:00 PM works', '9:42 PM', id, 200);
          await bot('Done ✅ Your booking is confirmed.', '9:42 PM', id, 800);
          const b = card('booked'); b.appendChild(checkSvg());
          const t = el('div', 'ot'); t.appendChild(el('b', null, 'BOOKING CONFIRMED'));
          t.appendChild(el('span', null, 'Checkup · Tomorrow 3:00 PM')); t.appendChild(el('span', null, '⏰ Reminder arrives in this chat'));
          b.appendChild(t); push(b); notify('book'); await wait(1600, id);
          const rem = el('div', 'wa-note', '⏰ Next day, 1 hour before'); push(rem); await wait(900, id);
          await bot('⏰ Reminder: your appointment at Smile Dental is today at 3:00 PM. See you soon!', '2:00 PM', id, 900);
        }
      },
      help: {
        name: 'Your Business', sub: 'online · 24/7 AI assistant', av: 'AI',
        async play(id) {
          await me('What are your opening hours?', '11:20 PM', id, 400);
          await bot('We are open 24 hours, day or night. I am always here. 🌙', '11:20 PM', id);
          const v = el('div', 'wa-msg me voice'); const p = el('i', 'play', '▶'); v.appendChild(p);
          const w = el('div', 'wave'); for (let i = 0; i < 18; i++) w.appendChild(el('b')); v.appendChild(w);
          v.appendChild(el('span', 'wa-meta', '0:07 ✓✓')); await wait(1100, id); push(v);
          await bot('Got your voice note 🎧 Delivery to your area costs Rs 150.', '11:21 PM', id, 1300);
          await bot('Would you like to talk to someone from our team?', '11:21 PM', id, 800);
          const c = push(chips(['No thanks', 'Yes, please'])); await wait(1000, id);
          c.lastChild.classList.add('tap'); await wait(450, id);
          await me('Yes, please connect me to the team', '11:21 PM', id, 200);
          const n = el('div', 'wa-note', '👤 Ahmed (your team) joined the chat'); push(n); notify('reply');
          await bot('Hello! I am Ahmed. How can I help you?', '11:22 PM', id, 1200);
        }
      }
    };
    const order = ['food', 'appt', 'help'];
    let current = 'food';

    async function show(key, auto) {
      const id = ++run; current = key;
      tabs.forEach(t => { const on = t.dataset.scene === key; t.classList.toggle('on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); });
      Object.values(floats).forEach(f => f && f.classList.remove('on'));
      feed.textContent = ''; feed.scrollTop = 0;
      const sc = scenes[key];
      nameEl.textContent = sc.name; subEl.textContent = sc.sub; avEl.textContent = sc.av;
      try {
        await sc.play(id);
        if (reduced || !auto) { if (!reduced && !auto) { /* user picked: keep looping from here */ } }
        if (reduced) return;
        await wait(4200, id);
        show(order[(order.indexOf(key) + 1) % order.length], true);
      } catch (e) { if (e !== cancel) throw e; }
    }
    tabs.forEach(t => t.addEventListener('click', () => show(t.dataset.scene, false)));
    const replay = $('#waReplay'); if (replay) replay.addEventListener('click', () => show(current, false));
    show('food', true);

    /* gentle 3D tilt that follows the pointer (desktop only) */
    const stage = $('#stage');
    if (stage && !reduced && window.matchMedia('(hover:hover) and (min-width: 900px)').matches) {
      const hero = $('.hero');
      hero.addEventListener('pointermove', e => {
        const r = stage.getBoundingClientRect();
        const x = (e.clientX - (r.left + r.width / 2)) / window.innerWidth, y = (e.clientY - (r.top + r.height / 2)) / window.innerHeight;
        stage.style.setProperty('--ry', (-6 + x * 14).toFixed(2) + 'deg');
        stage.style.setProperty('--rx', (3 - y * 10).toFixed(2) + 'deg');
      });
      hero.addEventListener('pointerleave', () => { stage.style.removeProperty('--ry'); stage.style.removeProperty('--rx'); });
    }
  }

  /* ------------------------------------------------------------------ feature visuals */
  function loopViz(root, steps, gap) {
    if (!root) return;
    let i = 0, on = false;
    const tick = () => { if (!on) return; steps[i % steps.length](); i++; };
    new IntersectionObserver(es => es.forEach(e => { on = e.isIntersecting; })).observe(root);
    if (reduced) { steps[steps.length - 1](); return; }
    setInterval(tick, gap);
  }

  const appt = $('[data-viz="appt"]');
  if (appt) {
    const d = new Date(); d.setDate(d.getDate() + 1);
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const head = el('div', 'viz-h'); head.appendChild(el('b', null, 'Checkup')); head.appendChild(el('span', null, d.toLocaleString('en', { month: 'long', year: 'numeric' }))); appt.appendChild(head);
    const row = el('div', 'days');
    for (let i = 0; i < 6; i++) { const x = el('div', 'day' + (i === 0 ? ' sel' : '')); x.appendChild(el('small', null, names[d.getDay()])); x.appendChild(el('b', null, String(d.getDate()))); row.appendChild(x); d.setDate(d.getDate() + 1); }
    appt.appendChild(row);
    const sl = el('div', 'slots'); ['11:00 AM', '1:00 PM', '3:00 PM', '5:30 PM'].forEach((t, i) => sl.appendChild(el('span', 'slot' + (i === 1 ? ' off' : ''), t))); appt.appendChild(sl);
    const done = el('div', 'viz-done', '✓ Booking confirmed · reminder goes out automatically'); appt.appendChild(done);
    const reset = () => { $$('.slot', sl).forEach(s => s.classList.remove('pick', 'hover')); done.classList.remove('on'); };
    loopViz(appt, [
      () => { reset(); sl.children[0].classList.add('hover'); },
      () => { reset(); sl.children[2].classList.add('hover'); },
      () => { sl.children[2].classList.remove('hover'); sl.children[2].classList.add('pick'); },
      () => { done.classList.add('on'); },
      () => { },
    ], 1100);
  }

  const food = $('[data-viz="food"]');
  if (food) {
    food.appendChild(el('div', 'viz-rest', '🍽 Biryani Kitchen')); const head = el('div', 'viz-h'); head.appendChild(el('b', null, 'Fast Food')); head.appendChild(el('span', null, '5 items')); food.appendChild(head);
    const items = [['Zinger Burger', 1], ['Chicken Biryani', 2], ['Aloo Biryani', 0], ['Chicken Shawarma', 0], ['Fries', 0]], qs = [];
    items.forEach(it => { const r = el('div', 'frow'); r.appendChild(el('span', null, it[0])); const q = el('div', 'qty'); q.appendChild(el('i', null, '−')); const n = el('b', null, '0'); q.appendChild(n); q.appendChild(el('i', null, '+')); r.appendChild(q); food.appendChild(r); qs.push([n, r, it[1]]); });
    const opts = el('div', 'opts'); opts.appendChild(el('span', 'opt', 'Pickup')); opts.appendChild(el('span', 'opt', 'Home delivery')); food.appendChild(opts);
    const send = el('div', 'viz-send', 'Place order'); food.appendChild(send);
    const reset = () => { qs.forEach(q => { q[0].textContent = '0'; q[1].classList.remove('hot'); }); $$('.opt', opts).forEach(o => o.classList.remove('pick')); send.classList.remove('sent'); send.textContent = 'Place order'; };
    loopViz(food, [
      () => { reset(); qs[0][0].textContent = '1'; qs[0][1].classList.add('hot'); },
      () => { qs[0][1].classList.remove('hot'); qs[1][0].textContent = '2'; qs[1][1].classList.add('hot'); },
      () => { qs[1][1].classList.remove('hot'); opts.lastChild.classList.add('pick'); },
      () => { send.classList.add('sent'); send.textContent = '✓ Order #1043 sent to you and your team'; },
      () => { },
    ], 1100);
  }

  /* marquee: duplicate track once so the loop is seamless */
  const mq = $('.marquee-track');
  if (mq && !reduced) mq.appendChild(mq.firstElementChild.cloneNode(true));
})();
