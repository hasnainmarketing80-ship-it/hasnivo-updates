(function () {
  'use strict';
  var rows = document.getElementById('hnvl-rows'), tpl = document.getElementById('hnvl-tpl'), add = document.getElementById('hnvl-add'), empty = document.getElementById('hnvl-empty');
  if (!rows || !tpl || !add) { return; }
  function renumber() {
    var list = rows.querySelectorAll('.hnvl-row');
    list.forEach(function (r, i) {
      r.querySelector('.hnvl-no').textContent = 'Jawab ' + (i + 1);
      r.querySelectorAll('[name^="kb["]').forEach(function (f) { f.name = f.name.replace(/^kb\[[^\]]*\]/, 'kb[' + i + ']'); });
    });
    if (empty) { empty.hidden = list.length > 0; }
  }
  add.addEventListener('click', function () {
    rows.appendChild(tpl.content.cloneNode(true));
    renumber();
    var last = rows.lastElementChild; if (last) { var f = last.querySelector('input'); if (f) { f.focus(); } }
  });
  rows.addEventListener('click', function (e) {
    if (e.target.classList.contains('hnvl-del')) {
      if (window.confirm('Yeh jawab delete karein?')) { e.target.closest('.hnvl-row').remove(); renumber(); }
    }
  });
  renumber();
})();
