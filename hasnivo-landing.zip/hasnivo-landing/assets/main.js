/* ---- Site settings: edit these, nothing else needs to change ---- */
const CONFIG = Object.assign(
  { whatsapp: '', email: '', social: {}, ga4Id: '', ajaxUrl: '' },
  (function () { try { return JSON.parse(document.querySelector('meta[name="hasnivo-config"]').content); } catch (_) { return {}; } })()
);   // values come from Appearance > Customize > Hasnivo Tech Settings

(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* Apply settings to every WhatsApp, email and social link */
  $$('[data-wa]').forEach(a => { if (CONFIG.whatsapp) a.href = 'https://wa.me/' + CONFIG.whatsapp; else a.remove(); });
  $$('[data-mail]').forEach(a => { a.href = 'mailto:' + CONFIG.email; if (a.classList.contains('mail') || a.textContent.includes('@')) a.textContent = CONFIG.email; });
  $$('[data-social]').forEach(a => { const u = CONFIG.social[a.dataset.social]; if (u) a.href = u; });

  /* Sticky header shadow + mobile menu */
  const header = $('.site-header');
  const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 8);
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

  const menuBtn = $('#menuBtn'), links = $('#navLinks');
  const setMenu = open => {
    links.classList.toggle('open', open);
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    menuBtn.firstElementChild.firstElementChild.setAttribute('href', open ? '#i-close' : '#i-menu');
  };
  menuBtn.addEventListener('click', () => setMenu(!links.classList.contains('open')));
  $$('a', links).forEach(a => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  /* Highlight the nav link of the section in view */
  if ('IntersectionObserver' in window) {
    const spy = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) $$('[data-spy]').forEach(a => a.classList.toggle('active', a.dataset.spy === en.target.id));
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    $$('main section[id]').forEach(s => spy.observe(s));
  }

  /* Service cards: light follows the pointer */
  $$('.svc').forEach(card => card.addEventListener('pointermove', e => {
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    card.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }));

  /* Contact form */
  const form = $('#contactForm'), ok = $('#formOk');
  const rules = {
    name:    v => v.trim().length >= 2 ? '' : 'Enter your name (at least 2 characters).',
    email:   v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email, like name@company.com.',
    phone:   v => { const d = v.replace(/[\s\-().]/g, '').replace(/^\+/, ''); return /^\d{8,15}$/.test(d) ? '' : 'Enter your WhatsApp number with country code, like +92 300 0000000.'; },
    service: v => v ? '' : 'Choose the service you need.',
    message: v => v.trim().length >= 10 ? '' : 'Write at least 10 characters about what you need.'
  };
  function check(name) {
    const input = form.elements[name], wrap = input.closest('.field');
    const msg = rules[name](input.value);
    wrap.classList.toggle('bad', !!msg);
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    $('#e-' + name).textContent = msg;
    return !msg;
  }
  Object.keys(rules).forEach(n => {
    const el = form.elements[n];
    el.addEventListener('blur', () => check(n));
    el.addEventListener('input', () => { if (el.closest('.field').classList.contains('bad')) check(n); ok.classList.remove('on'); });
  });

  let lastText = '';
  const okTitle = $('h4', ok), okMsg = $('p', ok);
  async function postToServer(payload) {
    const t = await fetch(CONFIG.ajaxUrl + '?action=hnvl_token', { credentials: 'same-origin' }).then(r => r.json());
    if (!t || !t.success) throw new Error('No token');
    const body = new URLSearchParams(Object.assign({ action: 'hnvl_contact', nonce: t.data.nonce, website: '' }, payload));
    const res = await fetch(CONFIG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error('Request failed');
  }
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const results = Object.keys(rules).map(check);
    if (results.includes(false)) { const first = $('.field.bad input, .field.bad select, .field.bad textarea', form); if (first) first.focus(); return; }
    const f = Object.fromEntries(new FormData(form).entries());
    if (f.website) return; // honeypot: real visitors never fill this
    lastText = 'Hello Hasnivo Tech,\n\nName: ' + f.name.trim() + '\nEmail: ' + f.email.trim() + '\nWhatsApp: ' + f.phone.trim() + '\nService: ' + f.service + '\n\n' + f.message.trim();
    if (CONFIG.whatsapp) { $('#okWa').href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(lastText); } else { $('#okWa').remove(); }
    $('#okMail').href = 'mailto:' + CONFIG.email + '?subject=' + encodeURIComponent('Enquiry: ' + f.service) + '&body=' + encodeURIComponent(lastText);
    let sent = false;
    if (CONFIG.ajaxUrl) {
      const btn = $('button[type="submit"]', form);
      btn.disabled = true; btn.textContent = 'Sending...';
      try { await postToServer({ name: f.name.trim(), email: f.email.trim(), phone: f.phone.trim(), service: f.service, message: f.message.trim() }); sent = true; }
      catch (_) { sent = false; }
      btn.disabled = false; btn.textContent = 'Send Enquiry';
    }
    if (sent) {
      okTitle.textContent = 'Thank you. We received your enquiry.';
      okMsg.textContent = 'We will reply soon. For a faster answer, message us on WhatsApp too.';
    } else if (CONFIG.ajaxUrl) {
      okTitle.textContent = 'We could not send the form.';
      okMsg.textContent = 'Please send your enquiry by WhatsApp or email instead. Your message is ready below.';
    } else {
      okTitle.textContent = 'Your enquiry is ready.';
      okMsg.textContent = 'Choose how to send it. WhatsApp is the fastest way to reach us.';
    }
    ok.classList.add('on'); ok.focus();
    track('generate_lead', { service: f.service, method: sent ? 'form' : 'handoff' });
  });
  $('#okCopy').addEventListener('click', async e => {
    const b = e.currentTarget;
    try { await navigator.clipboard.writeText(lastText); b.textContent = 'Copied'; }
    catch (_) { b.textContent = 'Copy not available'; }
    setTimeout(() => b.textContent = 'Copy message', 1800);
  });

  /* ---- Analytics: GA4 loads only when CONFIG.ga4Id is set ---- */
  function loadGA(id) {
    if (!/^G-[A-Z0-9]{6,}$/.test(id)) return;
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    const s = document.createElement('script');
    s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + id;
    document.head.appendChild(s);
    window.gtag('js', new Date()); window.gtag('config', id);
  }
  function track(name, params) { if (window.gtag) window.gtag('event', name, params || {}); }
  document.addEventListener('click', e => {
    const a = e.target.closest('a'); if (!a) return;
    if (a.hasAttribute('data-wa') || a.id === 'okWa') track('whatsapp_click', { location: a.closest('footer') ? 'footer' : 'page' });
    else if (a.matches('.btn-primary')) track('cta_click', { label: a.textContent.trim() });
  });
  loadGA(CONFIG.ga4Id);

  /* ---- Motion: scroll progress, reveals, ambient pause. Skipped when reduced motion is requested. ---- */
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const bar = $('#progress');
  if (bar) {
    if (reduced) { bar.hidden = true; }
    else {
      let ticking = false;
      const update = () => {
        ticking = false;
        const d = document.documentElement, max = d.scrollHeight - d.clientHeight;
        bar.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, d.scrollTop / max) : 0) + ')';
      };
      window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    }
  }
  if (!reduced && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => entries.forEach(en => {
      if (!en.isIntersecting) return;
      const el = en.target;
      el.classList.add('in'); io.unobserve(el);
      setTimeout(() => el.classList.remove('rv', 'draw', 'in'), 2200); // hand hover transitions back to the component
    }), { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });
    const vh = window.innerHeight;
    $$('.section-head, .about-copy, .glance, .vm-card, .svc, .why-item, .step, .guide, .faq-item, .contact-card').forEach(el => {
      if (el.getBoundingClientRect().top < vh) return; // already on screen: leave it fully visible
      const i = Array.prototype.indexOf.call(el.parentElement.children, el);
      el.style.setProperty('--d', Math.min(i, 6) * 70 + 'ms');
      el.classList.add('rv'); io.observe(el);
    });
    const steps = $('.steps');
    if (steps && steps.getBoundingClientRect().top >= vh) { steps.classList.add('draw'); io.observe(steps); }
    const hero = $('.hero');
    if (hero) new IntersectionObserver(es => es.forEach(en => hero.classList.toggle('paused', !en.isIntersecting))).observe(hero);
  }
})();
