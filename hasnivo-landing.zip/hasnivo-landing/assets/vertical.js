/* Hasnivo Tech: small script for the industry pages (menu button and Google Analytics only). */
(function () {
  'use strict';
  var CONFIG = {};
  try { CONFIG = JSON.parse(document.querySelector('meta[name="hasnivo-config"]').content) || {}; } catch (_) { CONFIG = {}; }
  var btn = document.getElementById('menuBtn'), links = document.getElementById('navLinks');
  if (btn && links) {
    btn.addEventListener('click', function () {
      var open = !links.classList.contains('open');
      links.classList.toggle('open', open);
      btn.setAttribute('aria-expanded', String(open));
      btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      var use = btn.querySelector('use');
      if (use) { use.setAttribute('href', open ? '#i-close' : '#i-menu'); }
    });
  }
  var id = CONFIG.ga4Id;
  if (id && /^G-[A-Z0-9]+$/.test(id)) {
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    var s = document.createElement('script');
    s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + id;
    document.head.appendChild(s);
    window.gtag('js', new Date()); window.gtag('config', id);
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a) { return; }
      if (/\/request-access\//.test(a.href)) { window.gtag('event', 'request_access_click', { page: location.pathname }); }
      else if (/wa\.me\//.test(a.href)) { window.gtag('event', 'whatsapp_click', { page: location.pathname }); }
    });
  }
}());
