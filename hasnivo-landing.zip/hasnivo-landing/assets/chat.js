/* Hasnivo assistant: live chat widget. Answers from a built-in knowledge base (works with no setup).
   If the site owner adds an API key on the server, unmatched questions go to an AI answer instead.
   No inline code, CSP-safe. */
(function () {
  'use strict';
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let CONFIG = {};
  try { CONFIG = JSON.parse(document.querySelector('meta[name="hasnivo-config"]').content) || {}; } catch (_) { CONFIG = {}; }
  const SITE = (CONFIG.siteUrl || '/').replace(/\/?$/, '/');
  const WA = CONFIG.whatsapp ? 'https://wa.me/' + CONFIG.whatsapp : '';
  const MAIL = CONFIG.email ? 'mailto:' + CONFIG.email : '';
  const LINKS = {
    plans: SITE + '#plans', features: SITE + '#features', services: SITE + '#services', contact: SITE + '#contact',
    request: SITE + 'request-access/', free: SITE + 'request-access/?plan=free',
    signin: 'https://app.hasnivo.tech/login.php', blog: SITE + 'blog/', wa: WA, mail: MAIL
  };
  const A = (label, key) => ({ label, key });

  /* ---------- knowledge base: only facts that are on the Hasnivo site ---------- */
  const KB = [
    { id: 'greet', k: ['salam', 'assalam', 'aoa', 'hello', 'hi', 'hey', 'good morning', 'good evening'],
      en: 'Hello! 👋 I\'m the Hasnivo assistant. Ask me about our WhatsApp AI chatbots, plans, appointments, food orders or how to get started.',
      ur: 'Assalam o alaikum! 👋 Main Hasnivo ka assistant hoon. WhatsApp AI chatbot, plans, appointments, food orders ya shuru karne ke baare mein kuch bhi poochh sakte hain.' },
    { id: 'what', k: ['what do you do', 'what is hasnivo', 'about', 'who are you', 'kya karte', 'kya kaam', 'kon ho', 'kaun ho', 'hasnivo kya', 'kya hai', 'kam kya'],
      en: 'Hasnivo Tech builds WhatsApp AI bots for businesses. The bot replies to your customers instantly (even at 2 AM), takes appointments and food orders inside WhatsApp, and your team sees every chat in one shared inbox. We also do automation, lead generation and API integration.',
      ur: 'Hasnivo Tech businesses ke liye WhatsApp AI bots banata hai. Bot aap ke customers ko foran jawab deta hai (raat 2 baje bhi), WhatsApp ke andar hi appointments aur food orders leta hai, aur aap ki team ko har chat ek shared inbox mein nazar aati hai. Saath mein automation, lead generation aur API integration bhi karte hain.',
      a: [A('See plans', 'plans'), A('Request access', 'request')] },
    { id: 'plans', k: ['price', 'pricing', 'plan', 'plans', 'cost', 'kitne', 'kitna', 'qeemat', 'rate', 'charges', 'fee', 'fees', 'rs', 'rupee', 'rupay', 'monthly', 'mahana', 'paisay', 'paise', 'kharcha'],
      en: 'Monthly plans:\n• Free: Rs 0 (1 WhatsApp number, 200 contacts, 300 messages/month)\n• Starter: Rs 3,999 (3 numbers, 10,000 contacts, 15,000 messages/month, human handover, CSV export)\n• Business: Rs 7,999 (50,000 contacts, 35,000 messages/month, appointment booking, media, voice notes, full AI bot setup)\n• Pro: Rs 14,999 (everything in Business, for high-volume teams)\nSome features depend on how your workspace is set up.',
      ur: 'Mahana plans:\n• Free: Rs 0 (1 WhatsApp number, 200 contacts, 300 messages/month)\n• Starter: Rs 3,999 (3 numbers, 10,000 contacts, 15,000 messages/month, human handover, CSV export)\n• Business: Rs 7,999 (50,000 contacts, 35,000 messages/month, appointment booking, media, voice notes, full AI bot setup)\n• Pro: Rs 14,999 (Business ki sab cheezein, zyada volume wali teams ke liye)\nKuch features aap ke workspace ki setting par depend karte hain.',
      a: [A('Compare plans', 'plans'), A('Start free', 'free')] },
    { id: 'free', k: ['free', 'muft', 'trial', 'try', 'test', 'demo', 'mufat'],
      en: 'Yes, there is a Free plan: 1 WhatsApp number, 200 contacts, 300 messages a month, with the AI chatbot. It\'s a simple way to try it with your own number.',
      ur: 'Ji, Free plan hai: 1 WhatsApp number, 200 contacts, mahine ke 300 messages, AI chatbot ke saath. Apne number par aazmane ka aasaan tareeqa hai.',
      a: [A('Start free', 'free')] },
    { id: 'which', k: ['which plan', 'konsa plan', 'kaun sa plan', 'best plan', 'recommend', 'suggest', 'mere liye', 'for me', 'starter', 'business plan', 'pro plan', 'choose'],
      en: 'A quick guide: Free to try with one number. Starter for solo operators and small teams (3 numbers, handover, CSV). Business if you take bookings (appointments, media, voice notes, full AI bot setup). Pro for high-volume teams.',
      ur: 'Mukhtasar rehnumai: Free ek number par try karne ke liye. Starter akele operators aur chhoti teams ke liye (3 numbers, handover, CSV). Business agar aap bookings lete hain (appointments, media, voice notes, full AI bot setup). Pro zyada volume wali teams ke liye.',
      a: [A('See plans', 'plans'), A('Talk to a person', 'contact')] },
    { id: 'appt', k: ['appointment', 'appointments', 'booking', 'bookings', 'book', 'slot', 'slots', 'clinic', 'salon', 'tutor', 'calendar', 'reminder', 'doctor', 'time lena'],
      en: 'Appointments work inside WhatsApp: customers pick a service, a day and a free slot in the chat. You set your working hours once. Only open times are offered (no double bookings), and the confirmation and reminder come in the same chat. Your team sees every booking in the inbox. Appointment booking is on the Business plan.',
      ur: 'Appointments WhatsApp ke andar hi hoti hain: customer chat mein service, din aur khali time chunta hai. Aap kaam ke auqaat sirf ek baar set karte hain. Sirf khali time dikhaye jate hain (double booking nahi), aur confirmation aur reminder usi chat mein aate hain. Har booking team ko inbox mein nazar aati hai. Appointment booking Business plan mein hai.',
      a: [A('See plans', 'plans'), A('Request access', 'request')] },
    { id: 'food', k: ['food', 'order', 'orders', 'menu', 'restaurant', 'delivery', 'biryani', 'burger', 'khana', 'dukaan', 'shop', 'pickup'],
      en: 'For restaurants and food shops, the bot shows your menu by category with prices, takes items and quantities, offers pickup or home delivery, and asks for the address for delivery orders. An order number goes to the customer and to your team.',
      ur: 'Restaurants aur food shops ke liye bot menu category ke mutabiq prices ke saath dikhata hai, items aur quantity leta hai, pickup ya home delivery poochta hai, aur delivery ke liye address maangta hai. Order number customer aur team dono ko jata hai.',
      a: [A('Request access', 'request')] },
    { id: 'start', k: ['start', 'begin', 'how', 'get started', 'shuru', 'kaise', 'access', 'request', 'signup', 'sign up', 'account', 'join', 'register', 'setup', 'set up', 'kese'],
      en: 'It\'s three steps. 1) Request access: send the short form and we create your account and send a link to set your password. 2) Connect your number: scan the QR code from your WhatsApp. 3) Start replying: turn on appointments, the menu or the AI assistant.',
      ur: 'Teen qadam hain. 1) Request access: chhota form bhejein, hum aap ka account bana kar password set karne ka link bhejte hain. 2) Apna number connect karein: apne WhatsApp se QR code scan karein. 3) Jawab dena shuru karein: appointments, menu ya AI assistant on karein.',
      a: [A('Request access', 'request'), A('Start free', 'free')] },
    { id: 'qr', k: ['qr', 'connect', 'number', 'pair', 'scan', 'cloud api', 'official', 'link number'],
      en: 'You connect by scanning a QR code from your WhatsApp, which pairs your number in about a minute. The Cloud API is available on eligible plans.',
      ur: 'Aap apne WhatsApp se QR code scan karke number connect karte hain, takreeban ek minute mein. Cloud API eligible plans par available hai.',
      a: [A('Request access', 'request')] },
    { id: 'lang', k: ['urdu', 'english', 'language', 'roman', 'zaban', 'languages'],
      en: 'The bot replies in the language your customer writes in, including Urdu and English.',
      ur: 'Bot Urdu aur English dono mein jawab deta hai.' },
    { id: 'team', k: ['inbox', 'team', 'handover', 'hand over', 'human', 'insaan', 'agent', 'staff', 'employee', 'reply myself'],
      en: 'Your whole team shares one inbox on one number, so nobody passes one phone around. With human handover you can put the bot on hold and reply yourself when it matters.',
      ur: 'Aap ki poori team ek number par ek shared inbox istemal karti hai, ek phone idhar udhar dene ki zaroorat nahi. Human handover se aap bot ko hold par rakh kar khud jawab de sakte hain.',
      a: [A('See features', 'features')] },
    { id: 'voice', k: ['voice', 'audio', 'voice note', 'voice notes', 'awaz'],
      en: 'The bot understands voice messages on eligible plans (voice note understanding is part of the Business plan).',
      ur: 'Bot eligible plans par voice messages samajhta hai (voice note understanding Business plan mein shamil hai).' },
    { id: 'csv', k: ['csv', 'export', 'download data', 'excel', 'contacts export'],
      en: 'CSV export lets you take your contacts and orders out whenever you need. It is included from the Starter plan.',
      ur: 'CSV export se aap apne contacts aur orders jab chahein nikaal sakte hain. Yeh Starter plan se shamil hai.' },
    { id: 'ai', k: ['ai', 'chatgpt', 'smart', 'chatbot', 'bot', 'assistant', 'jawab', 'answers', 'automatic'],
      en: 'The AI assistant replies from your own services and policies once you switch it on, and hands over to your team when a person is needed. It is part of every plan.',
      ur: 'AI assistant aap ki apni services aur policies ke mutabiq jawab deta hai jab aap isay on karte hain, aur jab insaan ki zaroorat ho to team ko handover kar deta hai. Yeh har plan mein hai.',
      a: [A('See features', 'features')] },
    { id: 'services', k: ['service', 'services', 'integration', 'api', 'crm', 'lead', 'leads', 'automation', 'custom', 'website', 'saas', 'sheets'],
      en: 'Besides the WhatsApp bot we offer: WhatsApp Business automation, AI customer support, lead generation and research, AI business automation, custom chatbot integration, and SaaS and API integration.',
      ur: 'WhatsApp bot ke ilawa hum yeh bhi dete hain: WhatsApp Business automation, AI customer support, lead generation aur research, AI business automation, custom chatbot integration, aur SaaS aur API integration.',
      a: [A('See services', 'services'), A('Talk to a person', 'contact')] },
    { id: 'pay', k: ['pay', 'payment', 'bank', 'invoice', 'paisay dene', 'adaigi', 'qr payment', 'jazzcash', 'easypaisa'],
      en: 'For paid plans, the request flow includes a payment step after you send the request. If you are unsure, our team can guide you.',
      ur: 'Paid plans mein request bhejne ke baad payment ka step aata hai. Agar koi confusion ho to hamari team rehnumai kar degi.',
      a: [A('Talk to a person', 'contact')] },
    { id: 'time', k: ['how long', 'kitne din', 'kitna time', 'kab tak', 'time lagega', 'duration'],
      en: 'Pairing your number takes about a minute with the QR code. How long a full bot setup takes depends on your business, so please ask our team for a specific answer.',
      ur: 'QR code se number pair karne mein takreeban ek minute lagta hai. Poora bot setup kitne waqt mein hoga yeh aap ke business par depend karta hai, is liye pakka jawab hamari team se lein.',
      a: [A('Talk to a person', 'contact')] },
    { id: 'login', k: ['login', 'log in', 'sign in', 'signin', 'password', 'forgot', 'dashboard', 'app'],
      en: 'Existing customers can sign in to the Hasnivo app here. If you don\'t have an account yet, request access first.',
      ur: 'Maujooda customers yahan se Hasnivo app mein sign in kar sakte hain. Agar account nahi hai to pehle request access karein.',
      a: [A('Sign in', 'signin'), A('Request access', 'request')] },
    { id: 'contact', k: ['contact', 'talk', 'call', 'whatsapp', 'email', 'human support', 'baat', 'rabta', 'support', 'help', 'madad', 'phone'],
      en: 'You can reach our team directly:', ur: 'Hamari team se seedha rabta karein:', a: [A('WhatsApp us', 'wa'), A('Email us', 'mail'), A('Contact form', 'contact')] },
    { id: 'thanks', k: ['thanks', 'thank', 'shukriya', 'jazak', 'shukria', 'thx'],
      en: 'You\'re welcome! Anything else I can help with?', ur: 'Khushi hui! Kuch aur poochna ho to batayein.' },
    { id: 'bye', k: ['bye', 'goodbye', 'allah hafiz', 'khuda hafiz'],
      en: 'Goodbye! Request access any time, we\'re happy to help.', ur: 'Allah hafiz! Jab chahein request access karein, hum madad ke liye hazir hain.', a: [A('Request access', 'request')] }
  ];
  /* Owner-added answers (Chat Knowledge page in WordPress admin). Checked before the built-in ones. */
  // Plans answer follows the owner's "Home Plans" page (falls back to the built-in text).
  try {
    const P = JSON.parse(document.getElementById('hnvl-plans').textContent);
    if (P && Array.isArray(P.plans) && P.plans.length) {
      const e = KB.find(x => x.id === 'plans');
      if (e) {
        const lines = P.plans.map(p => '• ' + p.name + ': ' + p.price + (p.per || '') + (p.features.length ? ' (' + p.features.slice(0, 5).join(', ') + ')' : ''));
        const tail = P.note ? '\n' + P.note : '';
        e.en = 'Monthly plans:\n' + lines.join('\n') + tail;
        e.ur = 'Mahana plans:\n' + lines.join('\n') + tail;
      }
    }
  } catch (_) { /* keep defaults */ }
  let CUSTOM = [];
  try {
    const raw = JSON.parse(document.getElementById('hnvl-kb').textContent);
    if (Array.isArray(raw)) {
      CUSTOM = raw.filter(e => e && Array.isArray(e.k) && (e.en || e.ur)).map(e => ({ id: 'custom', k: e.k, en: String(e.en || e.ur), ur: String(e.ur || e.en), a: Array.isArray(e.a) ? e.a.filter(x => x && x.label && /^(https?:|mailto:)/.test(x.href || '')) : null }));
    }
  } catch (_) { CUSTOM = []; }
  const FALLBACK = {
    en: 'I\'m not sure I have a reliable answer for that. Our team can help directly:',
    ur: 'Mujhe is ka pakka jawab nahi pata. Hamari team seedha madad kar sakti hai:',
    a: [A('WhatsApp us', 'wa'), A('Email us', 'mail'), A('Contact form', 'contact')]
  };
  const QUICK = [['Plans & pricing', 'plans'], ['How to start', 'start'], ['Appointments', 'appt'], ['Food orders', 'food'], ['Talk to a person', 'contact']];

  /* ---------- language + matching ---------- */
  const URDU_HINTS = ['kya', 'hai', 'hain', 'kitne', 'kitna', 'mujhe', 'aap', 'apna', 'apne', 'karna', 'kar', 'karo', 'ka', 'ki', 'ke', 'mein', 'main', 'nahi', 'nahin', 'chahiye', 'bata', 'batao', 'batayein', 'kaise', 'kese', 'kab', 'kon', 'kaun', 'shukriya', 'salam', 'assalam', 'janab', 'bhai', 'wala', 'wali', 'hamara', 'mera', 'meri', 'liye', 'se', 'ko', 'par', 'bhi', 'ya'];
  const STRONG = ['hai', 'hain', 'kya', 'kitne', 'kitna', 'chahiye', 'mujhe', 'aap', 'nahi', 'kaise', 'kese', 'shukriya', 'batao', 'batayein'];
  const isUrdu = t => /[\u0600-\u06FF]/.test(t) || t.split(/\s+/).some(w => STRONG.includes(w)) || t.split(/\s+/).filter(w => URDU_HINTS.includes(w)).length >= 2;
  const norm = t => ' ' + t.toLowerCase().replace(/[^a-z0-9؀-ۿ\s]/g, ' ').replace(/\s+/g, ' ').trim() + ' ';
  function match(text) {
    const n = norm(text); let best = null, bestScore = 0;
    CUSTOM.forEach(e => {
      let s = 0;
      e.k.forEach(k => { const kk = norm(k); if (kk.trim() && n.indexOf(kk) !== -1) s += kk.trim().indexOf(' ') !== -1 ? 4 : 3; });
      if (s > bestScore) { best = e; bestScore = s; }
    });
    if (best) return best;
    KB.forEach(e => {
      let s = 0;
      e.k.forEach(k => { if (n.indexOf(' ' + k + ' ') !== -1) s += k.indexOf(' ') !== -1 ? 3 : 2; });
      if (e.id === 'greet' && n.trim().split(' ').length > 4) s = 0; // a greeting inside a long question is not a greeting
      if (s > bestScore) { best = e; bestScore = s; }
    });
    return bestScore >= 2 ? best : null;
  }

  /* ---------- UI ---------- */
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  const root = el('div', 'hc'); root.id = 'hcRoot';
  const fab = el('button', 'hc-fab'); fab.type = 'button'; fab.setAttribute('aria-label', 'Open chat with Hasnivo assistant'); fab.setAttribute('aria-expanded', 'false'); fab.setAttribute('aria-controls', 'hcPanel');
  fab.appendChild(el('span', 'hc-fab-ic', '💬')); fab.appendChild(el('span', 'hc-fab-tx', 'Ask us')); fab.appendChild(el('i', 'hc-dot'));
  const teaser = el('div', 'hc-teaser', 'Have a question? Ask us 👋'); teaser.hidden = true;
  const panel = el('div', 'hc-panel'); panel.id = 'hcPanel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Chat with Hasnivo assistant'); panel.hidden = true;
  const head = el('div', 'hc-head');
  const av = el('div', 'hc-av', 'H'); const ht = el('div', 'hc-ht'); ht.appendChild(el('strong', null, 'Hasnivo Assistant')); ht.appendChild(el('span', null, '● online · replies in your language'));
  const x = el('button', 'hc-x'); x.type = 'button'; x.setAttribute('aria-label', 'Close chat'); x.textContent = '✕';
  head.appendChild(av); head.appendChild(ht); head.appendChild(x);
  const log = el('div', 'hc-log'); log.setAttribute('role', 'log'); log.setAttribute('aria-live', 'polite');
  const quick = el('div', 'hc-quick');
  const form = el('form', 'hc-form'); form.setAttribute('autocomplete', 'off');
  const input = el('input', 'hc-in'); input.type = 'text'; input.maxLength = 300; input.placeholder = 'Type your question…'; input.setAttribute('aria-label', 'Your question');
  const send = el('button', 'hc-send'); send.type = 'submit'; send.setAttribute('aria-label', 'Send'); send.textContent = '➤';
  form.appendChild(input); form.appendChild(send);
  const note = el('div', 'hc-note', 'Automated assistant. For anything specific, our team will help.');
  panel.appendChild(head); panel.appendChild(log); panel.appendChild(quick); panel.appendChild(form); panel.appendChild(note);
  root.appendChild(teaser); root.appendChild(panel); root.appendChild(fab);
  document.body.appendChild(root);

  const history = []; let busy = false, greeted = false, aiNonce = '';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const scroll = () => { log.scrollTop = log.scrollHeight; };

  function actions(list, wrap) {
    const row = el('div', 'hc-actions');
    list.forEach(a => {
      const href = a.href || LINKS[a.key]; if (!href) return;
      const b = el('a', 'hc-act', a.label); b.href = href;
      if (/^https?:/.test(href) && href.indexOf(location.host) === -1) { b.target = '_blank'; b.rel = 'noopener noreferrer'; }
      if (['plans', 'features', 'services', 'contact'].indexOf(a.key) !== -1) b.addEventListener('click', () => { close(); });
      row.appendChild(b);
    });
    if (row.children.length) wrap.appendChild(row);
  }
  function addMsg(who, text, acts) {
    const m = el('div', 'hc-m ' + who);
    const t = el('div', 'hc-t'); text.split('\n').forEach((ln, i) => { if (i) t.appendChild(document.createElement('br')); t.appendChild(document.createTextNode(ln)); });
    m.appendChild(t); if (acts && who === 'bot') actions(acts, m);
    log.appendChild(m); requestAnimationFrame(() => m.classList.add('in')); scroll(); return m;
  }
  function typing() { const m = el('div', 'hc-m bot in hc-typing'); for (let i = 0; i < 3; i++) m.appendChild(el('b')); log.appendChild(m); scroll(); return m; }

  async function aiAnswer(text) {
    if (!CONFIG.aiEnabled || !CONFIG.ajaxUrl) return null;
    try {
      if (!aiNonce) { const t = await fetch(CONFIG.ajaxUrl + '?action=hnvl_token', { credentials: 'same-origin' }).then(r => r.json()); aiNonce = t.data.ai_nonce; }
      const body = new URLSearchParams({ action: 'hnvl_ai', nonce: aiNonce, messages: JSON.stringify(history.slice(-6)) });
      const res = await fetch(CONFIG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body }).then(r => r.json());
      return res && res.success && res.data && res.data.reply ? String(res.data.reply) : null;
    } catch (_) { return null; }
  }

  async function reply(text) {
    busy = true; send.disabled = true;
    history.push({ role: 'user', content: text.slice(0, 300) });
    const ur = isUrdu(norm(text)); const entry = match(text);
    const t = typing();
    let out = null;
    if (!entry) out = await aiAnswer(text);
    await sleep(reduced ? 0 : 650 + Math.min(700, text.length * 8));
    t.remove();
    if (out) { addMsg('bot', out, [A('Talk to a person', 'contact')]); history.push({ role: 'assistant', content: out.slice(0, 600) }); }
    else {
      const e = entry || FALLBACK; const body = ur ? e.ur : e.en;
      addMsg('bot', body, e.a); history.push({ role: 'assistant', content: body.slice(0, 600) });
    }
    busy = false; send.disabled = false; if (!panel.hidden) input.focus();
  }
  function ask(text) { if (busy || !text.trim()) return; addMsg('me', text.trim()); input.value = ''; reply(text.trim()); }

  QUICK.forEach(q => { const b = el('button', 'hc-q', q[0]); b.type = 'button'; b.addEventListener('click', () => { ask(q[0]); }); quick.appendChild(b); });
  form.addEventListener('submit', e => { e.preventDefault(); ask(input.value); });

  function open() {
    panel.hidden = false; teaser.hidden = true; fab.setAttribute('aria-expanded', 'true'); root.classList.add('open');
    if (!greeted) { greeted = true; addMsg('bot', 'Hello! 👋 I am the Hasnivo assistant. Ask me about our WhatsApp AI chatbots, plans, appointments or food orders, in any language you like.', null); }
    setTimeout(() => input.focus(), 50);
    try { sessionStorage.setItem('hcSeen', '1'); } catch (_) { }
  }
  function close() { panel.hidden = true; fab.setAttribute('aria-expanded', 'false'); root.classList.remove('open'); fab.focus(); }
  fab.addEventListener('click', () => { panel.hidden ? open() : close(); });
  x.addEventListener('click', close);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !panel.hidden) close(); });
  teaser.addEventListener('click', open);

  let seen = false; try { seen = sessionStorage.getItem('hcSeen') === '1'; } catch (_) { }
  if (!seen && !reduced) { setTimeout(() => { if (panel.hidden) { teaser.hidden = false; teaser.classList.add('in'); setTimeout(() => { teaser.hidden = true; }, 9000); } }, 7000); }
  window.hasnivoChat = { open: open, close: close };
})();
