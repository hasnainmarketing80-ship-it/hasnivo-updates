<?php
/**
 * Plugin Name: Hasnivo Landing
 * Description: Replaces only the Home page with the new Hasnivo Tech landing page. Plans, Request access, Blog, Contact, Sign in and every other page keep using the current theme.
 * Version: 1.17.4
 * Author: Hasnivo Tech
 * License: GPL-2.0-or-later
 * Text Domain: hasnivo-landing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HNVL_DIR', plugin_dir_path( __FILE__ ) );
define( 'HNVL_URL', plugin_dir_url( __FILE__ ) );
require_once HNVL_DIR . 'inc/core.php';
require_once HNVL_DIR . 'inc/admin.php';
require_once HNVL_DIR . 'inc/plans.php';
require_once HNVL_DIR . 'inc/pages.php';
require_once HNVL_DIR . 'inc/hardening.php';
require_once HNVL_DIR . 'inc/notify.php';
require_once HNVL_DIR . 'inc/smtp.php';
require_once HNVL_DIR . 'inc/verticals.php';
require_once HNVL_DIR . 'inc/insights.php';
require_once HNVL_DIR . 'inc/updater.php';

// Use our template for the front page only. Everything else is left to the active theme.
add_filter(
	'template_include',
	function ( $template ) {
		if ( is_front_page() && ! is_feed() && ! is_embed() && ! is_robots() ) {
			return HNVL_DIR . 'templates/landing.php';
		}
		return $template;
	},
	99
);
