(function () {
  var d = document, de = d.documentElement;
  de.className += ' js';
  var btn = d.querySelector('.nav-btn'), nav = d.getElementById('nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var o = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', o ? 'true' : 'false');
    });
    nav.addEventListener('click', function (e) { if (e.target.tagName === 'A') { nav.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); } });
  }
  var els = [].slice.call(d.querySelectorAll('.rv'));
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .08 });
    els.forEach(function (e) { io.observe(e); });
  } else { els.forEach(function (e) { e.classList.add('in'); }); }

  var f = d.getElementById('hnvForm');
  if (f && window.HNV) {
    var msg = f.querySelector('.form-msg'), sub = f.querySelector('button[type=submit]');
    var say = function (t, c) { msg.textContent = t; msg.className = 'form-msg ' + c; };
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var fd = new FormData(f);
      if (!fd.get('name') || String(fd.get('name')).length < 2) { say('Please enter your name.', 'err'); return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fd.get('email') || '')) { say('Please enter a valid email address.', 'err'); return; }
      if (String(fd.get('message') || '').length < 5) { say('Please write a short message.', 'err'); return; }
      sub.disabled = true; say('Sending...', '');
      fetch(HNV.ajax + '?action=hnv_token', { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (t) {
        fd.append('action', 'hnv_contact'); fd.append('nonce', t.data.nonce);
        return fetch(HNV.ajax, { method: 'POST', body: fd, credentials: 'same-origin' });
      }).then(function (r) { return r.json(); }).then(function (j) {
        if (j.success) { say(j.data.message, 'ok'); f.reset(); } else { say((j.data && j.data.message) || 'Something went wrong. Please try again.', 'err'); }
        sub.disabled = false;
      }).catch(function () { say('Could not send. Please email us or use WhatsApp.', 'err'); sub.disabled = false; });
    });
  }
})();
