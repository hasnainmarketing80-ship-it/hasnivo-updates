jQuery(function ($) {
  $('.hnv-pick').on('click', function (e) {
    e.preventDefault();
    var btn = $(this), target = $('#' + btn.data('target')), multi = !!btn.data('multi'), type = btn.data('type') || 'image';
    var frame = wp.media({ title: 'Choose', multiple: multi, library: { type: type } });
    frame.on('select', function () {
      var sel = frame.state().get('selection').toJSON();
      if (multi) {
        var cur = target.val().trim();
        target.val((cur ? cur + '\n' : '') + sel.map(function (a) { return a.url; }).join('\n'));
      } else if (sel[0]) { target.val(sel[0].url); }
    });
    frame.open();
  });
});
