<?php
/**
 * Plugin Name: Hasnivo Platform
 * Description: HASNIVO company website: dynamic Products (with a landing page for each), Services, Solutions, Digital Skills, About and Contact, all managed from the HASNIVO menu in WordPress admin. No code needed to add a product.
 * Version: 1.0.2
 * Author: Hasnivo
 * License: GPL-2.0-or-later
 * Text Domain: hasnivo-platform
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HNV_VER', '1.0.2' );
define( 'HNV_DIR', plugin_dir_path( __FILE__ ) );
define( 'HNV_URL', plugin_dir_url( __FILE__ ) );

require_once HNV_DIR . 'inc/data.php';
require_once HNV_DIR . 'inc/seed.php';
require_once HNV_DIR . 'inc/admin.php';
require_once HNV_DIR . 'inc/render.php';
require_once HNV_DIR . 'inc/router.php';
require_once HNV_DIR . 'inc/contact.php';

add_action( 'init', 'hnv_migrate_102', 20 );
register_activation_hook(
	__FILE__,
	function () {
		hnv_register_types();
		hnv_router_rules();
		hnv_seed_defaults();
		flush_rewrite_rules();
	}
);
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
