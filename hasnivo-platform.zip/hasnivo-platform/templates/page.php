<?php
/** Full-page template for every Hasnivo Platform page. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$hnv_r = hnv_route();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
hnv_header( $hnv_r );
echo '<main id="main">';
hnv_render_body( $hnv_r );
echo '</main>';
hnv_footer();
wp_footer();
?>
</body>
</html>
