<?php
/**
 * Contact form: nonce, honeypot, rate limit, validation. Saved in HASNIVO > Enquiries and emailed.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_ajax_nopriv_hnv_token', 'hnv_ajax_token' );
add_action( 'wp_ajax_hnv_token', 'hnv_ajax_token' );
function hnv_ajax_token() {
	nocache_headers();
	wp_send_json_success( array( 'nonce' => wp_create_nonce( 'hnv_contact' ) ) );
}

add_action( 'wp_ajax_nopriv_hnv_contact', 'hnv_ajax_contact' );
add_action( 'wp_ajax_hnv_contact', 'hnv_ajax_contact' );
function hnv_ajax_contact() {
	$fail = function ( $m, $c = 400 ) {
		wp_send_json_error( array( 'message' => $m ), $c );
	};
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'hnv_contact' ) ) {
		$fail( 'Please reload the page and try again.', 403 );
	}
	if ( ! empty( $_POST['website'] ) ) {
		wp_send_json_success( array( 'message' => 'Thank you.' ) ); // honeypot: pretend success
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	$key = 'hnv_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		$fail( 'Too many messages. Please try again in a few minutes.', 429 );
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );

	$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone = isset( $_POST['phone'] ) ? preg_replace( '/[^0-9+ ()-]/', '', wp_unslash( $_POST['phone'] ) ) : '';
	$int   = isset( $_POST['interest'] ) ? sanitize_text_field( wp_unslash( $_POST['interest'] ) ) : '';
	$msg   = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	if ( strlen( $name ) < 2 || strlen( $name ) > 100 ) {
		$fail( 'Please enter your name.' );
	}
	if ( ! is_email( $email ) ) {
		$fail( 'Please enter a valid email address.' );
	}
	if ( strlen( $msg ) < 5 || strlen( $msg ) > 2000 ) {
		$fail( 'Please write a short message.' );
	}
	$phone = substr( $phone, 0, 30 );
	$int   = substr( $int, 0, 120 );

	$id = wp_insert_post(
		array(
			'post_type'    => 'hnv_enquiry',
			'post_status'  => 'private',
			'post_title'   => $name . ' - ' . ( $int ? $int : 'Enquiry' ),
			'post_content' => "Name: $name\nEmail: $email\nPhone: $phone\nInterest: $int\n\n$msg",
		)
	);
	$to = hnv_opt( 'email' );
	if ( is_email( $to ) ) {
		$body = "New website enquiry\n\nName: $name\nEmail: $email\nPhone: $phone\nInterest: $int\n\n$msg\n";
		if ( $phone ) {
			$body .= "\nReply on WhatsApp: https://wa.me/" . preg_replace( '/\D+/', '', $phone ) . "\n";
		}
		if ( $id && ! is_wp_error( $id ) ) {
			$body .= "\nView in admin: " . admin_url( 'post.php?post=' . (int) $id . '&action=edit' ) . "\n";
		}
		wp_mail( $to, 'New enquiry: ' . $int . ' - ' . $name, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
	}
	wp_send_json_success( array( 'message' => 'Thank you, ' . $name . '. We have your message and will reply soon.' ) );
}
