<?php
/**
 * Data layer: custom post types, categories, field helpers, option helpers.
 * Nothing here is ever deleted when the plugin is deactivated.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', 'hnv_register_types', 5 );
function hnv_register_types() {
	register_post_type(
		'hnv_product',
		array(
			'labels'       => array(
				'name'          => 'Products',
				'singular_name' => 'Product',
				'add_new_item'  => 'Add new product',
				'edit_item'     => 'Edit product',
				'menu_name'     => 'Products',
				'all_items'     => 'All products',
			),
			'public'       => true,
			'has_archive'  => 'products',
			'rewrite'      => array( 'slug' => 'products', 'with_front' => false ),
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
			'show_in_menu' => 'hnv-home',
			'show_in_rest' => false,
		)
	);
	register_post_type(
		'hnv_service',
		array(
			'labels'       => array(
				'name'          => 'Services',
				'singular_name' => 'Service',
				'add_new_item'  => 'Add new service',
				'edit_item'     => 'Edit service',
				'menu_name'     => 'Services',
				'all_items'     => 'All services',
			),
			'public'       => true,
			'has_archive'  => 'services',
			'rewrite'      => array( 'slug' => 'services', 'with_front' => false ),
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
			'show_in_menu' => 'hnv-home',
			'show_in_rest' => false,
		)
	);
	register_taxonomy(
		'hnv_category',
		'hnv_product',
		array(
			'labels'       => array(
				'name'          => 'Product categories',
				'singular_name' => 'Product category',
				'add_new_item'  => 'Add new category',
				'menu_name'     => 'Categories',
			),
			'public'       => true,
			'hierarchical' => true,
			'rewrite'      => array( 'slug' => 'products/category', 'with_front' => false ),
			'show_in_rest' => false,
		)
	);
	register_post_type(
		'hnv_enquiry',
		array(
			'labels'              => array(
				'name'          => 'Enquiries',
				'singular_name' => 'Enquiry',
				'menu_name'     => 'Enquiries',
				'edit_item'     => 'View enquiry',
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => 'hnv-home',
			'exclude_from_search' => true,
			'supports'            => array( 'title', 'editor' ),
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
			'capabilities'        => array( 'create_posts' => 'do_not_allow' ),
		)
	);
}

/** Product field definitions: key => [label, type, help]. Used by admin and render. */
function hnv_product_fields() {
	return array(
		'tagline'   => array( 'Short tagline', 'text', 'One line under the product name, e.g. "Learning management for schools".' ),
		'status'    => array( 'Status', 'status', 'Live shows normally. Beta and Coming soon show a badge and hide the buy button.' ),
		'accent'    => array( 'Accent colour', 'color', 'Colour used on this product page.' ),
		'logo'      => array( 'Product logo', 'media', 'Square logo image (PNG, SVG or JPG).' ),
		'banner'    => array( 'Promotional banner', 'media', 'Wide image shown at the top of the product page and on cards.' ),
		'images'    => array( 'Screenshots', 'gallery', 'One image URL per line, or use the button to add from the media library.' ),
		'video'     => array( 'Promotional video URL', 'url', 'YouTube link, or a direct .mp4 link from your media library.' ),
		'features'  => array( 'Features', 'lines', 'One feature per line. Optional description after a pipe: Attendance | Mark and track daily attendance.' ),
		'specs'     => array( 'Specifications', 'lines', 'One per line as Name: Value, e.g. Platform: Web and mobile.' ),
		'price'     => array( 'Pricing', 'text', 'Shown on the page, e.g. "From Rs 15,000 / month" or "Free".' ),
		'price_note' => array( 'Pricing note', 'text', 'Small print under the price (optional).' ),
		'demo_url'  => array( 'Demo URL', 'url', 'Link to a live demo or the product app, e.g. https://ilmseekho.hasnivo.com' ),
		'buy_url'   => array( 'Purchase URL', 'url', 'Where visitors buy or sign up. Leave empty to send them to the Contact page.' ),
		'docs_url'  => array( 'Documentation URL', 'url', 'Link to guides or documentation.' ),
		'powered'   => array( 'Brand line', 'text', 'e.g. "IlmSeekho, powered by Hasnivo".' ),
		'show_plans' => array( 'Show chatbot plans', 'check', 'Show the Hasnivo WhatsApp chatbot plans (from the existing Plans settings) on this product page.' ),
	);
}

function hnv_service_fields() {
	return array(
		'tagline' => array( 'Short description', 'text', 'One or two sentences shown on the service card.' ),
		'icon'    => array( 'Icon', 'icon', 'Pick the icon shown on the card.' ),
		'bullets' => array( 'What is included', 'lines', 'One point per line.' ),
		'banner'  => array( 'Service graphic', 'media', 'Optional wide image for the service page.' ),
	);
}

function hnv_meta( $id, $key, $default = '' ) {
	$v = get_post_meta( $id, '_hnv_' . $key, true );
	return ( '' === $v || false === $v ) ? $default : $v;
}

function hnv_lines( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $l ) {
		$l = trim( $l );
		if ( '' !== $l ) {
			$out[] = $l;
		}
	}
	return $out;
}

/** Products sorted by menu order then date. */
function hnv_products( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'post_type'      => 'hnv_product',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
			'no_found_rows'  => true,
		)
	);
	return get_posts( $args );
}

function hnv_services() {
	return get_posts(
		array(
			'post_type'      => 'hnv_service',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
			'no_found_rows'  => true,
		)
	);
}

function hnv_categories() {
	$t = get_terms( array( 'taxonomy' => 'hnv_category', 'hide_empty' => false ) );
	return is_wp_error( $t ) ? array() : $t;
}

/** Image URL of a product: its own uploaded logo, else the featured image, else empty. */
function hnv_product_logo( $id ) {
	$l = hnv_meta( $id, 'logo' );
	if ( '' === $l && has_post_thumbnail( $id ) ) {
		$l = get_the_post_thumbnail_url( $id, 'medium' );
	}
	return $l;
}

/* ---------------------------------------------------------------------------
 * Site options (editable from HASNIVO > Homepage & content)
 * ------------------------------------------------------------------------- */

function hnv_option_defaults() {
	return array(
		'hero_kicker' => 'HASNIVO · Digital technology & products',
		'hero_title'  => 'Empowering your digital future.',
		'hero_sub'    => 'We build software, AI chatbots, learning platforms and digital products for schools, businesses and creators, and we keep launching more.',
		'cta1_text'   => 'Explore products',
		'cta1_url'    => '/products/',
		'cta2_text'   => 'Talk to us',
		'cta2_url'    => '/contact/',
		'stats'       => "5+|Product lines\n7|Core services\n24/7|AI chat automation\n100%|Built for mobile",
		'banners'     => "New · IlmSeekho LMS|Run attendance, assignments, exams and live classes from one school dashboard.|See IlmSeekho|/products/ilmseekho/\nWhatsApp AI chatbots|Reply to customers instantly, take orders and book appointments on WhatsApp.|See plans|/plans/",
		'solutions'   => "Schools & academies|Attendance, timetables, lectures, exams and parent updates in one LMS.|education|/products/ilmseekho/\nRestaurants & food|WhatsApp ordering bots that take orders, share menus and confirm delivery.|food|/services/whatsapp-business-automation/\nClinics & healthcare|Appointment booking, reminders and patient questions answered automatically.|health|/services/ai-chatbot-development/\nOnline stores|E-commerce sites with product catalogues, payments and WhatsApp order alerts.|store|/services/e-commerce-development/\nGrowing businesses|Custom software and automation that removes repetitive manual work.|growth|/services/business-automation/",
		'skills'      => "WhatsApp chatbot basics|Learn how AI chatbots answer customers, take orders and hand over to people.|Beginner\nAI tools for business|Practical use of AI assistants for writing, support and daily office work.|Beginner\nWebsite and WordPress|Build and manage a professional business website without code.|Intermediate\nDigital marketing essentials|Social media, content planning and simple advertising for small businesses.|Beginner\nBusiness automation|Connect forms, sheets, WhatsApp and email so routine tasks run by themselves.|Intermediate",
		'about'       => "Hasnivo is a digital technology company building software, AI tools and digital products.\nWe started by helping businesses answer customers faster with WhatsApp AI chatbots. Today we also build learning platforms, websites and custom software, and we are growing into a platform where new products launch all the time.\nOur approach is simple: build practical tools, keep them easy to use, and support the people who rely on them.",
		'email'       => 'hasnivotech@gmail.com',
		'whatsapp'    => '923216740220',
		'address'     => 'Pakistan · serving clients worldwide',
		'ga4'         => '',
	);
}

function hnv_opt( $key ) {
	$d = hnv_option_defaults();
	$o = get_option( 'hnv_options', array() );
	if ( is_array( $o ) && isset( $o[ $key ] ) && '' !== trim( (string) $o[ $key ] ) ) {
		return (string) $o[ $key ];
	}
	return isset( $d[ $key ] ) ? $d[ $key ] : '';
}

function hnv_wa_digits() {
	return preg_replace( '/\D+/', '', hnv_opt( 'whatsapp' ) );
}

/** Make a URL from an option value: absolute stays, "/path" becomes site URL. */
function hnv_link( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) {
		return '';
	}
	if ( preg_match( '#^https?://#i', $u ) ) {
		return $u;
	}
	if ( 0 === strpos( $u, '/' ) ) {
		return home_url( $u );
	}
	return '';
}
