<?php
/**
 * Page rendering. Every page is plain, escaped HTML; the styles are in assets/hnv.css.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hnv_img( $v ) {
	$v = (string) $v;
	if ( 0 === strpos( $v, 'plugin:' ) ) {
		return HNV_URL . 'assets/' . substr( $v, 7 );
	}
	return $v;
}

function hnv_ic( $k ) {
	$p = array(
		'web'   => '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 9h18M8 21h8M12 18v3"/>',
		'store' => '<path d="M4 9l1.5-5h13L20 9M4 9v10h16V9M4 9h16M9 19v-6h6v6"/>',
		'bot'   => '<rect x="4" y="8" width="16" height="11" rx="4"/><path d="M12 8V4M9 13.5h.01M15 13.5h.01M9.5 16.5h5"/><circle cx="12" cy="3.5" r="1"/>',
		'chat'  => '<path d="M21 12a8 8 0 0 1-11.7 7L4 20l1.2-4.6A8 8 0 1 1 21 12z"/><path d="M9 11h6M9 14h4"/>',
		'code'  => '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 5l-3 14"/>',
		'flow'  => '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="12" r="2.5"/><circle cx="6" cy="18" r="2.5"/><path d="M8.5 6H12a3 3 0 0 1 3 3v.5M8.5 18H12a3 3 0 0 0 3-3v-.5"/>',
		'spark' => '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM18 16l.8 2.2L21 19l-2.2.8L18 22l-.8-2.2L15 19l2.2-.8z"/>',
		'book'  => '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.500zM4 5.500V21M9 8h7"/>',
		'app'   => '<rect x="7" y="2.500" width="10" height="19" rx="2.500"/><path d="M11 18.500h2"/>',
		'game'  => '<rect x="3" y="8" width="18" height="10" rx="5"/><path d="M8 11v4M6 13h4M15.500 12.500h.01M18 14.500h.01"/>',
		'box'   => '<path d="M12 3l8 4.500v9L12 21l-8-4.500v-9zM4 7.500l8 4.500 8-4.500M12 12v9"/>',
		'education' => '<path d="M2 9l10-5 10 5-10 5zM6 11.500V16c0 1.500 2.700 3 6 3s6-1.500 6-3v-4.500M22 9v6"/>',
		'food'  => '<path d="M6 3v8a2 2 0 0 0 2 2v8M10 3v8a2 2 0 0 1-2 2M18 21V3c-2 1.500-3 4-3 7s1 4 3 4"/>',
		'health' => '<path d="M12 21s-7-4.500-9-9.500C1.700 7.500 4 4 7.500 4 9.500 4 11 5 12 6.500 13 5 14.500 4 16.500 4 20 4 22.300 7.500 21 11.500 19 16.500 12 21 12 21zM12 9v5M9.500 11.500h5"/>',
		'growth' => '<path d="M3 20h18M5 16l4-5 3 3 6-8M14 6h4v4"/>',
		'check' => '<path d="M5 12.500l4.500 4.500L19 7.500"/>',
		'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'play'  => '<path d="M8 5.500v13l11-6.500z"/>',
		'wa'    => '<path d="M20 12a8 8 0 0 1-11.700 7L4 20l1.200-4.300A8 8 0 1 1 20 12z"/><path d="M9 8.500c.5 3 2.500 5 5.500 5.500l1-1.500-2-1-1 .8c-1-.4-1.800-1.200-2.200-2.200l.8-1-1-2z"/>',
		'mail'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
		'pin'   => '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.500"/>',
	);
	$d = isset( $p[ $k ] ) ? $p[ $k ] : $p['spark'];
	return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $d . '</svg>';
}

function hnv_status_badge( $id ) {
	$s = hnv_meta( $id, 'status', 'live' );
	if ( 'live' === $s ) {
		return '';
	}
	return '<span class="badge badge-' . esc_attr( $s ) . '">' . esc_html( 'beta' === $s ? 'Beta' : 'Coming soon' ) . '</span>';
}

function hnv_brand_logo( $cls = '' ) {
	return '<span class="brand ' . esc_attr( $cls ) . '"><img src="' . esc_url( HNV_URL . 'assets/img/hasnivo-mark.svg' ) . '" width="36" height="36" alt=""><span class="brand-name">HASNIVO</span></span>';
}

function hnv_nav_items() {
	return array(
		'/'                => 'Home',
		'/products/'       => 'Products',
		'/services/'       => 'Services',
		'/solutions/'      => 'Solutions',
		'/digital-skills/' => 'Digital Skills',
		'/about/'          => 'About Us',
		'/contact/'        => 'Contact Us',
	);
}

function hnv_active_nav( $r ) {
	$map = array( 'home' => '/', 'products' => '/products/', 'product' => '/products/', 'category' => '/products/', 'services' => '/services/', 'service' => '/services/', 'solutions' => '/solutions/', 'digital-skills' => '/digital-skills/', 'about' => '/about/', 'contact' => '/contact/', 'plans' => '/products/' );
	return isset( $map[ $r['type'] ] ) ? $map[ $r['type'] ] : '';
}

function hnv_header( $r ) {
	$act = hnv_active_nav( $r );
	echo '<a class="skip" href="#main">Skip to content</a><header class="hd" id="top"><div class="wrap hd-in">';
	echo '<a class="hd-brand" href="' . esc_url( home_url( '/' ) ) . '" aria-label="HASNIVO home">' . hnv_brand_logo() . '</a>';
	echo '<button class="nav-btn" type="button" aria-expanded="false" aria-controls="nav" aria-label="Menu"><span></span><span></span><span></span></button>';
	echo '<nav class="nav" id="nav" aria-label="Main">';
	foreach ( hnv_nav_items() as $path => $label ) {
		echo '<a href="' . esc_url( home_url( $path ) ) . '"' . ( $act === $path ? ' class="on" aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}
	echo '<a class="btn btn-sm nav-cta" href="' . esc_url( home_url( '/contact/' ) ) . '">Get a quote</a>';
	echo '</nav></div></header>';
}

function hnv_footer() {
	$wa = hnv_wa_digits();
	echo '<footer class="ft"><div class="wrap ft-grid"><div class="ft-about">' . hnv_brand_logo();
	echo '<p>Empowering Your Digital Future.</p><p class="muted">Software, AI chatbots, learning platforms and digital products.</p>';
	echo '<p class="muted small">' . esc_html( hnv_opt( 'address' ) ) . '</p></div>';
	echo '<div><h3>Products</h3><ul>';
	foreach ( array_slice( hnv_products(), 0, 5 ) as $p ) {
		echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( $p->post_title ) . '</a></li>';
	}
	echo '<li><a href="' . esc_url( home_url( '/products/' ) ) . '">All products</a></li></ul></div>';
	echo '<div><h3>Services</h3><ul>';
	foreach ( array_slice( hnv_services(), 0, 6 ) as $p ) {
		echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( $p->post_title ) . '</a></li>';
	}
	echo '</ul></div><div><h3>Company</h3><ul>';
	foreach ( array( '/solutions/' => 'Solutions', '/digital-skills/' => 'Digital Skills', '/about/' => 'About Us', '/contact/' => 'Contact Us', '/plans/' => 'Chatbot plans', '/insights/' => 'Insights' ) as $u => $l ) {
		echo '<li><a href="' . esc_url( home_url( $u ) ) . '">' . esc_html( $l ) . '</a></li>';
	}
	echo '</ul></div><div><h3>Get in touch</h3><ul>';
	echo '<li><a href="mailto:' . esc_attr( hnv_opt( 'email' ) ) . '">' . hnv_ic( 'mail' ) . esc_html( hnv_opt( 'email' ) ) . '</a></li>';
	if ( $wa ) {
		echo '<li><a href="https://wa.me/' . esc_attr( $wa ) . '" rel="noopener">' . hnv_ic( 'wa' ) . 'Chat on WhatsApp</a></li>';
	}
	echo '</ul></div></div><div class="wrap ft-base"><span>&copy; ' . esc_html( gmdate( 'Y' ) ) . ' HASNIVO. All rights reserved.</span><span class="muted">Ilm Seekho is powered by Hasnivo.</span></div></footer>';
	if ( $wa ) {
		echo '<a class="wa-fab" href="https://wa.me/' . esc_attr( $wa ) . '" rel="noopener" aria-label="Chat on WhatsApp">' . hnv_ic( 'wa' ) . '</a>';
	}
}

/* ------------------------------ Parts ------------------------------ */

function hnv_page_head( $kicker, $title, $sub = '', $crumbs = array() ) {
	echo '<section class="ph"><div class="wrap">';
	if ( $crumbs ) {
		echo '<nav class="crumbs" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
		foreach ( $crumbs as $c ) {
			echo '<span>/</span>' . ( $c[1] ? '<a href="' . esc_url( $c[1] ) . '">' . esc_html( $c[0] ) . '</a>' : '<span>' . esc_html( $c[0] ) . '</span>' );
		}
		echo '</nav>';
	}
	echo '<p class="kick">' . esc_html( $kicker ) . '</p><h1>' . esc_html( $title ) . '</h1>';
	if ( $sub ) {
		echo '<p class="lead">' . esc_html( $sub ) . '</p>';
	}
	echo '</div></section>';
}

function hnv_section_head( $kicker, $title, $sub = '' ) {
	echo '<div class="sh rv"><p class="kick">' . esc_html( $kicker ) . '</p><h2>' . esc_html( $title ) . '</h2>' . ( $sub ? '<p class="lead">' . esc_html( $sub ) . '</p>' : '' ) . '</div>';
}

function hnv_product_card( $p ) {
	$ac     = hnv_meta( $p->ID, 'accent', '#3B74FF' );
	$logo   = hnv_product_logo( $p->ID );
	$banner = hnv_meta( $p->ID, 'banner' );
	$tag    = hnv_meta( $p->ID, 'tagline' );
	$sum    = has_excerpt( $p ) ? get_the_excerpt( $p ) : wp_trim_words( wp_strip_all_tags( $p->post_content ), 22 );
	$cats   = get_the_terms( $p->ID, 'hnv_category' );
	echo '<a class="pc rv" href="' . esc_url( get_permalink( $p ) ) . '" style="--ac:' . esc_attr( $ac ) . '">';
	echo '<div class="pc-top">';
	if ( $banner ) {
		echo '<img src="' . esc_url( hnv_img( $banner ) ) . '" alt="" loading="lazy" width="480" height="300">';
	}
	echo hnv_status_badge( $p->ID ) . '</div><div class="pc-body"><div class="pc-id">';
	if ( $logo ) {
		echo '<img class="pc-logo" src="' . esc_url( hnv_img( $logo ) ) . '" alt="" width="44" height="44" loading="lazy">';
	} else {
		echo '<span class="pc-logo pc-ini">' . esc_html( strtoupper( substr( $p->post_title, 0, 1 ) ) ) . '</span>';
	}
	echo '<div><h3>' . esc_html( $p->post_title ) . '</h3>' . ( $tag ? '<p class="muted small">' . esc_html( $tag ) . '</p>' : '' ) . '</div></div>';
	echo '<p>' . esc_html( $sum ) . '</p><div class="pc-foot">';
	if ( $cats && ! is_wp_error( $cats ) ) {
		echo '<span class="chip">' . esc_html( $cats[0]->name ) . '</span>';
	}
	echo '<span class="more">View product ' . hnv_ic( 'arrow' ) . '</span></div></div></a>';
}

function hnv_service_card( $p ) {
	echo '<a class="sc rv" href="' . esc_url( get_permalink( $p ) ) . '"><span class="sc-ic">' . hnv_ic( hnv_meta( $p->ID, 'icon', 'spark' ) ) . '</span><h3>' . esc_html( $p->post_title ) . '</h3><p>' . esc_html( hnv_meta( $p->ID, 'tagline', wp_trim_words( wp_strip_all_tags( $p->post_content ), 20 ) ) ) . '</p><span class="more">Learn more ' . hnv_ic( 'arrow' ) . '</span></a>';
}

function hnv_cta_band( $title = 'Ready to build something with Hasnivo?', $sub = 'Tell us what you need. We reply within one working day.' ) {
	echo '<section class="band rv"><div class="wrap band-in"><div><h2>' . esc_html( $title ) . '</h2><p>' . esc_html( $sub ) . '</p></div><div class="band-btns"><a class="btn" href="' . esc_url( home_url( '/contact/' ) ) . '">Contact us</a>';
	$wa = hnv_wa_digits();
	if ( $wa ) {
		echo '<a class="btn btn-ghost" href="https://wa.me/' . esc_attr( $wa ) . '" rel="noopener">' . hnv_ic( 'wa' ) . 'WhatsApp</a>';
	}
	echo '</div></div></section>';
}

function hnv_video_embed( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '';
	}
	if ( preg_match( '#(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([A-Za-z0-9_-]{11})#', $url, $m ) ) {
		return '<div class="video"><iframe src="https://www.youtube-nocookie.com/embed/' . esc_attr( $m[1] ) . '" title="Product video" loading="lazy" allow="accelerometer; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>';
	}
	if ( preg_match( '#\.(mp4|webm)(\?|$)#i', $url ) ) {
		return '<div class="video"><video controls preload="none" playsinline src="' . esc_url( $url ) . '"></video></div>';
	}
	return '';
}

function hnv_paragraphs( $text ) {
	$o = '';
	foreach ( hnv_lines( $text ) as $l ) {
		$o .= '<p>' . esc_html( $l ) . '</p>';
	}
	return $o;
}

function hnv_hero_art() {
	$nodes = array(
		array( 'LMS', 'book', 'n1' ),
		array( 'AI', 'bot', 'n2' ),
		array( 'WhatsApp', 'chat', 'n3' ),
		array( 'Apps', 'app', 'n4' ),
		array( 'Web', 'web', 'n5' ),
	);
	$o = '<div class="orb" aria-hidden="true"><span class="orb-ring r1"></span><span class="orb-ring r2"></span><span class="orb-ring r3"></span><img class="orb-core" src="' . esc_url( HNV_URL . 'assets/img/hasnivo-mark.svg' ) . '" alt="" width="120" height="120">';
	foreach ( $nodes as $n ) {
		$o .= '<span class="orb-node ' . $n[2] . '">' . hnv_ic( $n[1] ) . '<b>' . esc_html( $n[0] ) . '</b></span>';
	}
	return $o . '</div>';
}

/* ------------------------------ Home ------------------------------ */

function hnv_page_home() {
	$btn2 = hnv_link( hnv_opt( 'cta2_url' ) );
	echo '<section class="hero"><div class="wrap hero-in"><div class="hero-copy"><p class="kick rv">' . esc_html( hnv_opt( 'hero_kicker' ) ) . '</p><h1 class="rv">' . esc_html( hnv_opt( 'hero_title' ) ) . '</h1><p class="lead rv">' . esc_html( hnv_opt( 'hero_sub' ) ) . '</p><div class="hero-btns rv"><a class="btn" href="' . esc_url( hnv_link( hnv_opt( 'cta1_url' ) ) ) . '">' . esc_html( hnv_opt( 'cta1_text' ) ) . hnv_ic( 'arrow' ) . '</a>' . ( $btn2 ? '<a class="btn btn-ghost" href="' . esc_url( $btn2 ) . '">' . esc_html( hnv_opt( 'cta2_text' ) ) . '</a>' : '' ) . '</div></div>';
	echo '<div class="hero-art rv">' . hnv_hero_art() . '</div></div>';
	$stats = hnv_lines( hnv_opt( 'stats' ) );
	if ( $stats ) {
		echo '<div class="wrap"><ul class="stats">';
		foreach ( $stats as $s ) {
			$x = array_map( 'trim', explode( '|', $s, 2 ) );
			echo '<li><b>' . esc_html( $x[0] ) . '</b><span>' . esc_html( isset( $x[1] ) ? $x[1] : '' ) . '</span></li>';
		}
		echo '</ul></div>';
	}
	echo '</section>';

	// Featured product spotlight: the first live product with a banner.
	$prods = hnv_products();
	if ( $prods ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'Products', 'Software that works for you', 'Our growing family of digital products. New ones appear here the moment we publish them.' );
		echo '<div class="grid g3">';
		foreach ( array_slice( $prods, 0, 6 ) as $p ) {
			hnv_product_card( $p );
		}
		echo '</div><p class="center rv"><a class="btn btn-ghost" href="' . esc_url( home_url( '/products/' ) ) . '">See all products' . hnv_ic( 'arrow' ) . '</a></p></div></section>';
		$f = $prods[0];
		$imgs = hnv_lines( hnv_meta( $f->ID, 'images' ) );
		echo '<section class="sec spot"><div class="wrap spot-in"><div class="spot-copy rv"><p class="kick">Featured · ' . esc_html( $f->post_title ) . '</p><h2>' . esc_html( hnv_meta( $f->ID, 'tagline', $f->post_title ) ) . '</h2><p class="lead">' . esc_html( has_excerpt( $f ) ? get_the_excerpt( $f ) : wp_trim_words( wp_strip_all_tags( $f->post_content ), 28 ) ) . '</p><ul class="ticks">';
		foreach ( array_slice( hnv_lines( hnv_meta( $f->ID, 'features' ) ), 0, 5 ) as $ft ) {
			echo '<li>' . hnv_ic( 'check' ) . esc_html( trim( explode( '|', $ft )[0] ) ) . '</li>';
		}
		echo '</ul><a class="btn" href="' . esc_url( get_permalink( $f ) ) . '">Explore ' . esc_html( $f->post_title ) . hnv_ic( 'arrow' ) . '</a></div>';
		if ( $imgs ) {
			echo '<div class="spot-art rv"><img src="' . esc_url( hnv_img( $imgs[0] ) ) . '" alt="' . esc_attr( $f->post_title ) . ' dashboard" loading="lazy" width="960" height="600"></div>';
		}
		echo '</div></section>';
	}

	$svcs = hnv_services();
	if ( $svcs ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'Services', 'Everything to take your business digital', 'From a first website to custom software and WhatsApp automation.' );
		echo '<div class="grid g4">';
		foreach ( $svcs as $s ) {
			hnv_service_card( $s );
		}
		echo '<a class="sc sc-all rv" href="' . esc_url( home_url( '/services/' ) ) . '"><span class="sc-ic">' . hnv_ic( 'arrow' ) . '</span><h3>All services</h3><p>See everything we offer and how we work.</p><span class="more">View services ' . hnv_ic( 'arrow' ) . '</span></a>';
		echo '</div></div></section>';
	}

	$banners = hnv_lines( hnv_opt( 'banners' ) );
	if ( $banners ) {
		echo '<section class="sec"><div class="wrap grid g2">';
		foreach ( $banners as $b ) {
			$x = array_pad( array_map( 'trim', explode( '|', $b ) ), 4, '' );
			echo '<div class="promo rv"><h3>' . esc_html( $x[0] ) . '</h3><p>' . esc_html( $x[1] ) . '</p>' . ( $x[2] && hnv_link( $x[3] ) ? '<a class="btn btn-sm" href="' . esc_url( hnv_link( $x[3] ) ) . '">' . esc_html( $x[2] ) . hnv_ic( 'arrow' ) . '</a>' : '' ) . '</div>';
		}
		echo '</div></section>';
	}

	echo '<section class="sec"><div class="wrap">';
	hnv_section_head( 'How we work', 'Simple, clear, and built around you' );
	echo '<ol class="steps">';
	foreach ( array( array( 'Listen', 'We learn what you want to achieve, in plain words.' ), array( 'Plan', 'You get a simple plan, a price and a timeline before we start.' ), array( 'Build', 'We build in small steps and show you progress as we go.' ), array( 'Support', 'We train your team and stay with you after launch.' ) ) as $i => $s ) {
		echo '<li class="rv"><span class="num">' . ( $i + 1 ) . '</span><h3>' . esc_html( $s[0] ) . '</h3><p>' . esc_html( $s[1] ) . '</p></li>';
	}
	echo '</ol></div></section>';
	hnv_cta_band();
}

/* ------------------------- Product pages ------------------------- */

function hnv_page_products( $term = null ) {
	if ( $term ) {
		hnv_page_head( 'Products', $term->name, $term->description ? wp_strip_all_tags( $term->description ) : '', array( array( 'Products', home_url( '/products/' ) ), array( $term->name, '' ) ) );
		$list = hnv_products( array( 'tax_query' => array( array( 'taxonomy' => 'hnv_category', 'field' => 'term_id', 'terms' => $term->term_id ) ) ) );
	} else {
		hnv_page_head( 'Products', 'Our products', 'Software and digital products by Hasnivo. Pick one to see features, screenshots and how to get started.', array( array( 'Products', '' ) ) );
		$list = hnv_products();
	}
	echo '<section class="sec sec-tight"><div class="wrap">';
	$cats = array_filter( hnv_categories(), function ( $t ) {
		return $t->count > 0;
	} );
	if ( $cats ) {
		echo '<div class="filters" aria-label="Product categories"><a class="chip' . ( $term ? '' : ' on' ) . '" href="' . esc_url( home_url( '/products/' ) ) . '">All</a>';
		foreach ( $cats as $c ) {
			$l = get_term_link( $c );
			echo '<a class="chip' . ( $term && (int) $term->term_id === (int) $c->term_id ? ' on' : '' ) . '" href="' . esc_url( is_wp_error( $l ) ? '#' : $l ) . '">' . esc_html( $c->name ) . '</a>';
		}
		echo '</div>';
	}
	if ( $list ) {
		echo '<div class="grid g3">';
		foreach ( $list as $p ) {
			hnv_product_card( $p );
		}
		echo '</div>';
	} else {
		echo '<p class="empty">New products are coming soon.</p>';
	}
	echo '</div></section>';
	hnv_cta_band( 'Need something that is not here yet?', 'We build custom software too. Tell us what you have in mind.' );
}

function hnv_render_plans_block() {
	if ( ! function_exists( 'hnvl_plans_enabled' ) ) {
		echo '<p class="center muted">Contact us for pricing.</p>';
		return;
	}
	echo '<div class="grid g4 plans">';
	foreach ( hnvl_plans_enabled() as $pl ) {
		echo '<article class="plan' . ( ! empty( $pl['popular'] ) ? ' pop' : '' ) . ' rv">' . ( ! empty( $pl['popular'] ) ? '<span class="badge">Most popular</span>' : '' ) . '<h3>' . esc_html( $pl['name'] ) . '</h3><p class="price"><b>' . esc_html( $pl['price'] ) . '</b><span> ' . esc_html( $pl['per'] ) . '</span></p>';
		if ( ! empty( $pl['desc'] ) ) {
			echo '<p class="muted small">' . esc_html( $pl['desc'] ) . '</p>';
		}
		echo '<ul class="ticks">';
		foreach ( hnv_lines( $pl['features'] ) as $f ) {
			echo '<li>' . hnv_ic( 'check' ) . esc_html( $f ) . '</li>';
		}
		echo '</ul><a class="btn btn-sm" href="' . esc_url( home_url( '/contact/?plan=' . rawurlencode( $pl['name'] ) ) ) . '">' . esc_html( ! empty( $pl['cta'] ) ? $pl['cta'] : 'Choose' ) . '</a></article>';
	}
	echo '</div>';
}

function hnv_page_product( $p ) {
	$id     = $p->ID;
	$ac     = hnv_meta( $id, 'accent', '#3B74FF' );
	$logo   = hnv_product_logo( $id );
	$status = hnv_meta( $id, 'status', 'live' );
	$demo   = hnv_meta( $id, 'demo_url' );
	$buy    = hnv_meta( $id, 'buy_url' );
	$docs   = hnv_meta( $id, 'docs_url' );
	$banner = hnv_meta( $id, 'banner' );
	$cats   = get_the_terms( $id, 'hnv_category' );
	echo '<div style="--ac:' . esc_attr( $ac ) . '">';
	echo '<section class="ph pdh"><div class="wrap pdh-in"><div class="pdh-copy">';
	echo '<nav class="crumbs" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a><span>/</span><a href="' . esc_url( home_url( '/products/' ) ) . '">Products</a><span>/</span><span>' . esc_html( $p->post_title ) . '</span></nav>';
	echo '<div class="pd-id">';
	if ( $logo ) {
		echo '<img class="pd-logo" src="' . esc_url( hnv_img( $logo ) ) . '" alt="' . esc_attr( $p->post_title ) . ' logo" width="72" height="72">';
	}
	echo '<div>' . hnv_status_badge( $id ) . '<h1>' . esc_html( $p->post_title ) . '</h1></div></div>';
	if ( hnv_meta( $id, 'tagline' ) ) {
		echo '<p class="lead">' . esc_html( hnv_meta( $id, 'tagline' ) ) . '</p>';
	}
	if ( hnv_meta( $id, 'powered' ) ) {
		echo '<p class="powered">' . esc_html( hnv_meta( $id, 'powered' ) ) . '</p>';
	}
	echo '<div class="hero-btns">';
	if ( 'coming' === $status ) {
		echo '<a class="btn" href="' . esc_url( home_url( '/contact/?product=' . rawurlencode( $p->post_title ) ) ) . '">Notify me at launch</a>';
	} else {
		if ( $demo ) {
			echo '<a class="btn" href="' . esc_url( $demo ) . '" rel="noopener">Open ' . ( 'beta' === $status ? 'beta' : 'demo' ) . hnv_ic( 'arrow' ) . '</a>';
		}
		echo '<a class="btn' . ( $demo ? ' btn-ghost' : '' ) . '" href="' . esc_url( $buy ? $buy : home_url( '/contact/?product=' . rawurlencode( $p->post_title ) ) ) . '"' . ( $buy ? ' rel="noopener"' : '' ) . '>' . ( $buy ? 'Get ' . esc_html( $p->post_title ) : 'Request a quote' ) . '</a>';
	}
	if ( $docs ) {
		echo '<a class="btn btn-ghost" href="' . esc_url( $docs ) . '" rel="noopener">Documentation</a>';
	}
	echo '</div></div>';
	if ( $banner ) {
		echo '<div class="pdh-art"><img src="' . esc_url( hnv_img( $banner ) ) . '" alt="' . esc_attr( $p->post_title ) . ' preview" width="960" height="600"></div>';
	}
	echo '</div></section>';

	echo '<section class="sec sec-tight"><div class="wrap narrow rv"><div class="prose">' . wp_kses_post( wpautop( $p->post_content ) ) . '</div>';
	if ( $cats && ! is_wp_error( $cats ) ) {
		echo '<p class="catline">';
		foreach ( $cats as $c ) {
			$l = get_term_link( $c );
			echo '<a class="chip" href="' . esc_url( is_wp_error( $l ) ? '#' : $l ) . '">' . esc_html( $c->name ) . '</a> ';
		}
		echo '</p>';
	}
	echo '</div></section>';

	$video = hnv_video_embed( hnv_meta( $id, 'video' ) );
	if ( $video ) {
		echo '<section class="sec sec-tight"><div class="wrap narrow">';
		hnv_section_head( 'Watch', 'See ' . $p->post_title . ' in action' );
		echo $video . '</div></section>';
	}

	$feats = hnv_lines( hnv_meta( $id, 'features' ) );
	if ( $feats ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'Features', 'What you get' );
		echo '<div class="grid g3">';
		foreach ( $feats as $f ) {
			$x = array_map( 'trim', explode( '|', $f, 2 ) );
			echo '<div class="ft-card rv"><span class="ft-ic">' . hnv_ic( 'check' ) . '</span><h3>' . esc_html( $x[0] ) . '</h3>' . ( isset( $x[1] ) ? '<p>' . esc_html( $x[1] ) . '</p>' : '' ) . '</div>';
		}
		echo '</div></div></section>';
	}

	$road = hnv_lines( hnv_meta( $id, 'roadmap' ) );
	if ( $road ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'Roadmap', 'Coming soon', 'These features are being built and are not available yet.' );
		echo '<div class="grid g3">';
		foreach ( $road as $f ) {
			$x = array_map( 'trim', explode( '|', $f, 2 ) );
			echo '<div class="ft-card rv" style="border-style:dashed;opacity:.85"><span class="ft-ic">' . hnv_ic( 'spark' ) . '</span><h3>' . esc_html( $x[0] ) . '</h3>' . ( isset( $x[1] ) ? '<p>' . esc_html( $x[1] ) . '</p>' : '' ) . '</div>';
		}
		echo '</div></div></section>';
	}

	$imgs = hnv_lines( hnv_meta( $id, 'images' ) );
	if ( $imgs ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'Screenshots', 'A look inside', 'Example dashboards and screens.' );
		echo '<div class="shots">';
		foreach ( $imgs as $i => $u ) {
			echo '<figure class="shot rv"><img src="' . esc_url( hnv_img( $u ) ) . '" alt="' . esc_attr( $p->post_title . ' screenshot ' . ( $i + 1 ) ) . '" loading="lazy" width="960" height="600"></figure>';
		}
		echo '</div></div></section>';
	}

	$specs = hnv_lines( hnv_meta( $id, 'specs' ) );
	$price = hnv_meta( $id, 'price' );
	if ( $specs || $price ) {
		echo '<section class="sec"><div class="wrap grid g2 info">';
		if ( $specs ) {
			echo '<div class="panel rv"><h3>Specifications</h3><dl class="specs">';
			foreach ( $specs as $s ) {
				$x = array_map( 'trim', explode( ':', $s, 2 ) );
				echo '<div><dt>' . esc_html( $x[0] ) . '</dt><dd>' . esc_html( isset( $x[1] ) ? $x[1] : '' ) . '</dd></div>';
			}
			echo '</dl></div>';
		}
		if ( $price && 'coming' !== $status ) {
			echo '<div class="panel rv"><h3>Pricing</h3><p class="price"><b>' . esc_html( $price ) . '</b></p>' . ( hnv_meta( $id, 'price_note' ) ? '<p class="muted">' . esc_html( hnv_meta( $id, 'price_note' ) ) . '</p>' : '' ) . '<a class="btn" href="' . esc_url( $buy ? $buy : home_url( '/contact/?product=' . rawurlencode( $p->post_title ) ) ) . '">' . ( $buy ? 'Get started' : 'Get a quote' ) . '</a></div>';
		}
		echo '</div></section>';
	}

	if ( '1' === hnv_meta( $id, 'show_plans' ) ) {
		echo '<section class="sec" id="plans"><div class="wrap">';
		hnv_section_head( 'Plans', 'Choose your plan', 'Simple monthly plans. Upgrade any time.' );
		hnv_render_plans_block();
		echo '</div></section>';
	}

	$others = array_filter( hnv_products(), function ( $o ) use ( $id ) {
		return (int) $o->ID !== (int) $id;
	} );
	if ( $others ) {
		echo '<section class="sec"><div class="wrap">';
		hnv_section_head( 'More from Hasnivo', 'Other products' );
		echo '<div class="grid g3">';
		foreach ( array_slice( $others, 0, 3 ) as $o ) {
			hnv_product_card( $o );
		}
		echo '</div></div></section>';
	}
	hnv_cta_band( 'Want ' . $p->post_title . ' for your organisation?', 'We will set it up, train your team and support you.' );
	echo '</div>';
}

/* ------------------------- Services & content pages ------------------------- */

function hnv_page_services() {
	hnv_page_head( 'Services', 'Services that move your business forward', 'Websites, online stores, AI chatbots, WhatsApp automation and custom software, delivered with clear prices and timelines.', array( array( 'Services', '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap grid g3">';
	foreach ( hnv_services() as $s ) {
		hnv_service_card( $s );
	}
	echo '</div></section>';
	hnv_cta_band();
}

function hnv_page_service( $p ) {
	hnv_page_head( 'Service', $p->post_title, hnv_meta( $p->ID, 'tagline' ), array( array( 'Services', home_url( '/services/' ) ), array( $p->post_title, '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap grid g2 svc"><div class="rv"><div class="prose">' . wp_kses_post( wpautop( $p->post_content ) ) . '</div><p><a class="btn" href="' . esc_url( home_url( '/contact/?service=' . rawurlencode( $p->post_title ) ) ) . '">Get a quote' . hnv_ic( 'arrow' ) . '</a></p></div>';
	echo '<div class="panel rv"><span class="sc-ic">' . hnv_ic( hnv_meta( $p->ID, 'icon', 'spark' ) ) . '</span><h3>What is included</h3><ul class="ticks">';
	foreach ( hnv_lines( hnv_meta( $p->ID, 'bullets' ) ) as $b ) {
		echo '<li>' . hnv_ic( 'check' ) . esc_html( $b ) . '</li>';
	}
	echo '</ul></div></div></section>';
	$others = array_filter( hnv_services(), function ( $o ) use ( $p ) {
		return (int) $o->ID !== (int) $p->ID;
	} );
	echo '<section class="sec"><div class="wrap">';
	hnv_section_head( 'More services', 'You may also need' );
	echo '<div class="grid g3">';
	foreach ( array_slice( $others, 0, 3 ) as $o ) {
		hnv_service_card( $o );
	}
	echo '</div></div></section>';
	hnv_cta_band();
}

function hnv_page_solutions() {
	hnv_page_head( 'Solutions', 'Digital solutions for your industry', 'Ready-made ways to solve the everyday problems of schools, restaurants, clinics, stores and growing businesses.', array( array( 'Solutions', '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap grid g3">';
	foreach ( hnv_lines( hnv_opt( 'solutions' ) ) as $l ) {
		$x = array_pad( array_map( 'trim', explode( '|', $l ) ), 4, '' );
		$u = hnv_link( $x[3] );
		echo '<' . ( $u ? 'a href="' . esc_url( $u ) . '"' : 'div' ) . ' class="sc rv"><span class="sc-ic">' . hnv_ic( $x[2] ? $x[2] : 'spark' ) . '</span><h3>' . esc_html( $x[0] ) . '</h3><p>' . esc_html( $x[1] ) . '</p>' . ( $u ? '<span class="more">Explore ' . hnv_ic( 'arrow' ) . '</span>' : '' ) . '</' . ( $u ? 'a' : 'div' ) . '>';
	}
	echo '</div></section>';
	hnv_cta_band( 'Not sure which solution fits?', 'Describe your business and we will suggest the simplest option.' );
}

function hnv_page_skills() {
	hnv_page_head( 'Digital Skills', 'Learn practical digital skills', 'Short, practical learning for business owners, teams and students. Tell us which topic you want and we will let you know when the next session opens.', array( array( 'Digital Skills', '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap grid g3">';
	foreach ( hnv_lines( hnv_opt( 'skills' ) ) as $l ) {
		$x = array_pad( array_map( 'trim', explode( '|', $l ) ), 3, '' );
		echo '<div class="sc rv"><span class="chip">' . esc_html( $x[2] ? $x[2] : 'All levels' ) . '</span><h3>' . esc_html( $x[0] ) . '</h3><p>' . esc_html( $x[1] ) . '</p><a class="more" href="' . esc_url( home_url( '/contact/?skill=' . rawurlencode( $x[0] ) ) ) . '">Join the waiting list ' . hnv_ic( 'arrow' ) . '</a></div>';
	}
	echo '</div></section>';
	hnv_cta_band( 'Want training for your team?', 'We can run a private session for your school or business.' );
}

function hnv_page_about() {
	hnv_page_head( 'About Us', 'A digital technology company built for growth', 'Hasnivo. Empowering Your Digital Future.', array( array( 'About Us', '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap narrow rv"><div class="prose">' . hnv_paragraphs( hnv_opt( 'about' ) ) . '</div></div></section>';
	echo '<section class="sec"><div class="wrap">';
	hnv_section_head( 'What we believe', 'Our principles' );
	echo '<div class="grid g3">';
	foreach ( array( array( 'Practical first', 'We build tools that solve real, everyday problems, not features for show.', 'check' ), array( 'Easy for everyone', 'If your team needs a manual to use it, we have not finished the job.', 'spark' ), array( 'Always improving', 'Products and services keep getting better, and new ones keep arriving.', 'growth' ) ) as $v ) {
		echo '<div class="ft-card rv"><span class="ft-ic">' . hnv_ic( $v[2] ) . '</span><h3>' . esc_html( $v[0] ) . '</h3><p>' . esc_html( $v[1] ) . '</p></div>';
	}
	echo '</div></div></section>';
	hnv_cta_band( 'Let us build something together', 'Tell us about your project.' );
}

function hnv_page_plans() {
	hnv_page_head( 'Plans', 'WhatsApp AI chatbot plans', 'Start free and upgrade when you grow.', array( array( 'Products', home_url( '/products/' ) ), array( 'Plans', '' ) ) );
	echo '<section class="sec sec-tight"><div class="wrap">';
	hnv_render_plans_block();
	echo '</div></section>';
	hnv_cta_band();
}

function hnv_page_contact() {
	hnv_page_head( 'Contact Us', 'Tell us what you need', 'We reply within one working day. For a faster answer, message us on WhatsApp.', array( array( 'Contact Us', '' ) ) );
	$pre = '';
	foreach ( array( 'product', 'service', 'plan', 'skill' ) as $k ) {
		if ( isset( $_GET[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$pre = sanitize_text_field( wp_unslash( $_GET[ $k ] ) );
			break;
		}
	}
	$opts = array( 'General question' );
	foreach ( hnv_products() as $p ) {
		$opts[] = 'Product: ' . $p->post_title;
	}
	foreach ( hnv_services() as $s ) {
		$opts[] = 'Service: ' . $s->post_title;
	}
	$opts[] = 'Digital skills training';
	echo '<section class="sec sec-tight"><div class="wrap grid g2 contact"><form class="form rv" id="hnvForm" novalidate>';
	echo '<label>Your name<input name="name" type="text" required maxlength="100" autocomplete="name"></label>';
	echo '<label>Email<input name="email" type="email" required maxlength="120" autocomplete="email"></label>';
	echo '<label>WhatsApp / phone (optional)<input name="phone" type="tel" maxlength="30" autocomplete="tel"></label>';
	echo '<label>I am interested in<select name="interest">';
	foreach ( $opts as $o ) {
		$sel = '' !== $pre && false !== stripos( $o, $pre ) ? ' selected' : '';
		echo '<option' . $sel . '>' . esc_html( $o ) . '</option>';
	}
	echo '</select></label><label>Message<textarea name="message" rows="5" required maxlength="2000"></textarea></label>';
	echo '<input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">';
	echo '<button class="btn" type="submit">Send message' . hnv_ic( 'arrow' ) . '</button><p class="form-msg" role="status" aria-live="polite"></p></form>';
	echo '<div class="panel rv"><h3>Other ways to reach us</h3><ul class="cl">';
	echo '<li>' . hnv_ic( 'mail' ) . '<a href="mailto:' . esc_attr( hnv_opt( 'email' ) ) . '">' . esc_html( hnv_opt( 'email' ) ) . '</a></li>';
	if ( hnv_wa_digits() ) {
		echo '<li>' . hnv_ic( 'wa' ) . '<a href="https://wa.me/' . esc_attr( hnv_wa_digits() ) . '" rel="noopener">Chat on WhatsApp</a></li>';
	}
	echo '<li>' . hnv_ic( 'pin' ) . '<span>' . esc_html( hnv_opt( 'address' ) ) . '</span></li></ul></div></div></section>';
}

/* ------------------------------ Entry ------------------------------ */

function hnv_render_body( $r ) {
	switch ( $r['type'] ) {
		case 'home':
			hnv_page_home();
			break;
		case 'products':
			hnv_page_products();
			break;
		case 'category':
			hnv_page_products( $r['term'] );
			break;
		case 'product':
			hnv_page_product( $r['post'] );
			break;
		case 'services':
			hnv_page_services();
			break;
		case 'service':
			hnv_page_service( $r['post'] );
			break;
		case 'solutions':
			hnv_page_solutions();
			break;
		case 'digital-skills':
			hnv_page_skills();
			break;
		case 'about':
			hnv_page_about();
			break;
		case 'plans':
			hnv_page_plans();
			break;
		case 'contact':
			hnv_page_contact();
			break;
	}
}
