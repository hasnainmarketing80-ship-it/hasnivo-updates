<?php
/**
 * Routing, templates, assets, SEO (meta, Open Graph, schema), sitemap and robots.txt.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hnv_pages() {
	return array(
		'solutions'      => array( 'Solutions', 'Digital solutions for schools, restaurants, clinics, stores and growing businesses.' ),
		'digital-skills' => array( 'Digital Skills', 'Practical digital skills: WhatsApp chatbots, AI tools, websites, marketing and automation.' ),
		'about'          => array( 'About Us', 'About Hasnivo, a digital technology company building software, AI tools and digital products.' ),
		'contact'        => array( 'Contact Us', 'Contact Hasnivo about products, websites, WhatsApp chatbots and custom software.' ),
		'plans'          => array( 'WhatsApp Chatbot Plans', 'Pricing plans for the Hasnivo WhatsApp AI chatbot.' ),
	);
}

add_action( 'init', 'hnv_router_rules', 6 );
function hnv_router_rules() {
	$slugs = implode( '|', array_keys( hnv_pages() ) );
	add_rewrite_rule( '^(' . $slugs . ')/?$', 'index.php?hnv_page=$matches[1]', 'top' );
	add_rewrite_rule( '^hasnivo-sitemap\.xml$', 'index.php?hnv_sitemap=1', 'top' );
}

add_filter(
	'query_vars',
	function ( $v ) {
		$v[] = 'hnv_page';
		$v[] = 'hnv_sitemap';
		return $v;
	}
);

/** Preview mode: the new site is shown to visitors only after HASNIVO > Homepage & content > "Show the new site to everyone" is ticked. */
function hnv_is_public() {
	return '1' === (string) get_option( 'hnv_public', '' );
}

/** What is this request? Returns array( type, ... ) or empty. */
function hnv_route() {
	static $r = null;
	if ( null !== $r ) {
		return $r;
	}
	$r = array();
	if ( ! hnv_is_public() && ! current_user_can( 'manage_options' ) ) {
		return $r; // preview mode: only logged-in administrators see the new site
	}
	if ( get_query_var( 'hnv_page' ) ) {
		$slug = (string) get_query_var( 'hnv_page' );
		if ( isset( hnv_pages()[ $slug ] ) ) {
			$r = array( 'type' => $slug );
		}
	} elseif ( is_front_page() ) {
		$r = array( 'type' => 'home' );
	} elseif ( is_post_type_archive( 'hnv_product' ) ) {
		$r = array( 'type' => 'products' );
	} elseif ( is_tax( 'hnv_category' ) ) {
		$r = array( 'type' => 'category', 'term' => get_queried_object() );
	} elseif ( is_singular( 'hnv_product' ) ) {
		$r = array( 'type' => 'product', 'post' => get_queried_object() );
	} elseif ( is_post_type_archive( 'hnv_service' ) ) {
		$r = array( 'type' => 'services' );
	} elseif ( is_singular( 'hnv_service' ) ) {
		$r = array( 'type' => 'service', 'post' => get_queried_object() );
	}
	return $r;
}

add_action(
	'template_redirect',
	function () {
		if ( get_query_var( 'hnv_sitemap' ) && hnv_is_public() ) {
			hnv_sitemap();
		}
	},
	1
);

add_filter(
	'template_include',
	function ( $tpl ) {
		if ( hnv_route() && ! is_feed() && ! is_embed() && ! is_robots() ) {
			global $wp_query;
			if ( get_query_var( 'hnv_page' ) ) {
				$wp_query->is_404 = false;
				status_header( 200 );
			}
			return HNV_DIR . 'templates/page.php';
		}
		return $tpl;
	},
	100
);

add_filter(
	'redirect_canonical',
	function ( $url ) {
		return get_query_var( 'hnv_page' ) ? false : $url;
	}
);

add_action( 'wp_enqueue_scripts', 'hnv_assets', 9999 );
function hnv_assets() {
	if ( ! hnv_route() ) {
		return;
	}
	global $wp_styles, $wp_scripts;
	$keep = array( 'admin-bar', 'dashicons', 'hnv' );
	if ( $wp_styles ) {
		foreach ( (array) $wp_styles->queue as $h ) {
			if ( 0 !== strpos( $h, 'hnv' ) && ! in_array( $h, $keep, true ) ) {
				wp_dequeue_style( $h );
			}
		}
	}
	wp_enqueue_style( 'hnv', HNV_URL . 'assets/hnv.css', array(), HNV_VER );
	wp_enqueue_script( 'hnv', HNV_URL . 'assets/hnv.js', array(), HNV_VER, true );
	wp_localize_script( 'hnv', 'HNV', array( 'ajax' => admin_url( 'admin-ajax.php' ) ) );
}

add_filter(
	'body_class',
	function ( $c ) {
		return hnv_route() ? array( 'hnv-body' ) : $c;
	},
	99
);

/* ------------------------------ SEO ------------------------------ */

function hnv_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'AIOSEO_VERSION' );
}

function hnv_abs_img( $u ) {
	$u = hnv_img( $u );
	return $u;
}

/** Title, description, canonical, image for the current request. */
function hnv_meta_for( $r ) {
	$site = 'HASNIVO';
	$m    = array(
		'title' => $site . ' | Empowering Your Digital Future',
		'desc'  => 'HASNIVO builds software, AI chatbots, learning platforms (Ilm Seekho LMS), WhatsApp automation and digital products for schools and businesses.',
		'url'   => home_url( '/' ),
		'image' => HNV_URL . 'assets/img/og-image.png',
		'type'  => 'website',
	);
	switch ( $r['type'] ) {
		case 'products':
			$m['title'] = 'Products | ' . $site;
			$m['desc']  = 'Software, learning platforms, AI tools and digital products by HASNIVO.';
			$m['url']   = home_url( '/products/' );
			break;
		case 'category':
			$t          = $r['term'];
			$m['title'] = $t->name . ' | Products | ' . $site;
			$m['desc']  = $t->description ? wp_strip_all_tags( $t->description ) : 'HASNIVO products in ' . $t->name . '.';
			$m['url']   = get_term_link( $t );
			break;
		case 'product':
			$p          = $r['post'];
			$ex         = has_excerpt( $p ) ? get_the_excerpt( $p ) : wp_trim_words( wp_strip_all_tags( $p->post_content ), 28 );
			$m['title'] = $p->post_title . ( hnv_meta( $p->ID, 'tagline' ) ? ': ' . hnv_meta( $p->ID, 'tagline' ) : '' ) . ' | ' . $site;
			$m['desc']  = $ex;
			$m['url']   = get_permalink( $p );
			$img        = hnv_meta( $p->ID, 'banner' );
			if ( $img && ! preg_match( '/\.svg(\?|$)/i', $img ) ) {
				$m['image'] = hnv_img( $img );
			}
			$m['type'] = 'product';
			break;
		case 'services':
			$m['title'] = 'Services | ' . $site;
			$m['desc']  = 'Website development, e-commerce, AI chatbots, WhatsApp automation, custom software and business automation.';
			$m['url']   = home_url( '/services/' );
			break;
		case 'service':
			$p          = $r['post'];
			$m['title'] = $p->post_title . ' | ' . $site;
			$m['desc']  = hnv_meta( $p->ID, 'tagline', wp_trim_words( wp_strip_all_tags( $p->post_content ), 28 ) );
			$m['url']   = get_permalink( $p );
			break;
		default:
			if ( isset( hnv_pages()[ $r['type'] ] ) ) {
				$pg         = hnv_pages()[ $r['type'] ];
				$m['title'] = $pg[0] . ' | ' . $site;
				$m['desc']  = $pg[1];
				$m['url']   = home_url( '/' . $r['type'] . '/' );
			}
	}
	return $m;
}

add_filter(
	'pre_get_document_title',
	function ( $t ) {
		$r = hnv_route();
		if ( ! $r || hnv_seo_plugin_active() ) {
			return $t;
		}
		return hnv_meta_for( $r )['title'];
	},
	20
);

add_action( 'wp_head', 'hnv_head', 2 );
function hnv_head() {
	$r = hnv_route();
	if ( ! $r ) {
		return;
	}
	remove_action( 'wp_head', 'rel_canonical' );
	echo '<link rel="icon" href="' . esc_url( HNV_URL . 'assets/favicon.svg' ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( HNV_URL . 'assets/img/hasnivo-512.png' ) . '" type="image/png" sizes="512x512">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( HNV_URL . 'assets/img/hasnivo-512.png' ) . '">' . "\n";
	echo '<meta name="theme-color" content="#060A18">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=DM+Sans:wght@400;500;700&display=swap">' . "\n";
	$ga = hnv_opt( 'ga4' );
	if ( $ga ) {
		echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . esc_attr( $ga ) . '"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date());gtag("config","' . esc_js( $ga ) . '");</script>' . "\n";
	}
	if ( hnv_seo_plugin_active() ) {
		return;
	}
	$m = hnv_meta_for( $r );
	echo '<meta name="description" content="' . esc_attr( $m['desc'] ) . '">' . "\n";
	echo '<link rel="canonical" href="' . esc_url( $m['url'] ) . '">' . "\n";
	$og = array(
		'og:type'        => 'website',
		'og:site_name'   => 'HASNIVO',
		'og:title'       => $m['title'],
		'og:description' => $m['desc'],
		'og:url'         => $m['url'],
		'og:image'       => $m['image'],
	);
	foreach ( $og as $k => $v ) {
		echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="' . esc_attr( $m['title'] ) . '"><meta name="twitter:description" content="' . esc_attr( $m['desc'] ) . '"><meta name="twitter:image" content="' . esc_url( $m['image'] ) . '">' . "\n";
	foreach ( hnv_schema( $r, $m ) as $g ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $g, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}

function hnv_schema( $r, $m ) {
	$home = home_url( '/' );
	$org  = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Organization',
		'@id'         => $home . '#organization',
		'name'        => 'HASNIVO',
		'url'         => $home,
		'logo'        => HNV_URL . 'assets/img/hasnivo-512.png',
		'slogan'      => 'Empowering Your Digital Future.',
		'email'       => hnv_opt( 'email' ),
		'contactPoint' => array( '@type' => 'ContactPoint', 'contactType' => 'sales', 'email' => hnv_opt( 'email' ), 'availableLanguage' => array( 'English', 'Urdu' ) ),
	);
	$out  = array();
	if ( 'home' === $r['type'] ) {
		$out[] = $org;
		$out[] = array( '@context' => 'https://schema.org', '@type' => 'WebSite', '@id' => $home . '#website', 'url' => $home, 'name' => 'HASNIVO', 'publisher' => array( '@id' => $home . '#organization' ) );
		return $out;
	}
	$crumbs = array( array( 'Home', $home ) );
	if ( 'product' === $r['type'] ) {
		$crumbs[] = array( 'Products', home_url( '/products/' ) );
		$crumbs[] = array( $r['post']->post_title, $m['url'] );
		$p        = $r['post'];
		$app      = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'SoftwareApplication',
			'name'                => $p->post_title,
			'description'         => $m['desc'],
			'url'                 => $m['url'],
			'applicationCategory' => 'BusinessApplication',
			'operatingSystem'     => 'Web',
			'publisher'           => array( '@id' => $home . '#organization' ),
		);
		$logo     = hnv_product_logo( $p->ID );
		if ( $logo && ! preg_match( '/\.svg(\?|$)/i', hnv_img( $logo ) ) ) {
			$app['image'] = hnv_img( $logo );
		}
		$out[] = $app;
	} elseif ( 'service' === $r['type'] ) {
		$crumbs[] = array( 'Services', home_url( '/services/' ) );
		$crumbs[] = array( $r['post']->post_title, $m['url'] );
		$out[]    = array( '@context' => 'https://schema.org', '@type' => 'Service', 'name' => $r['post']->post_title, 'description' => $m['desc'], 'url' => $m['url'], 'provider' => array( '@id' => $home . '#organization' ) );
	} elseif ( 'category' === $r['type'] ) {
		$crumbs[] = array( 'Products', home_url( '/products/' ) );
		$crumbs[] = array( $r['term']->name, $m['url'] );
	} else {
		$crumbs[] = array( isset( hnv_pages()[ $r['type'] ] ) ? hnv_pages()[ $r['type'] ][0] : ucfirst( $r['type'] ), $m['url'] );
	}
	$items = array();
	foreach ( $crumbs as $i => $c ) {
		$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] );
	}
	$out[] = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items );
	return $out;
}

/* ------------------------- Sitemap and robots ------------------------- */

function hnv_sitemap() {
	$urls   = array( array( home_url( '/' ), '' ) );
	foreach ( array( 'products', 'services', 'solutions', 'digital-skills', 'about', 'contact', 'plans' ) as $s ) {
		$urls[] = array( home_url( '/' . $s . '/' ), '' );
	}
	foreach ( hnv_products() as $p ) {
		$urls[] = array( get_permalink( $p ), get_post_modified_time( 'c', true, $p ) );
	}
	foreach ( hnv_services() as $p ) {
		$urls[] = array( get_permalink( $p ), get_post_modified_time( 'c', true, $p ) );
	}
	foreach ( hnv_categories() as $t ) {
		if ( $t->count > 0 ) {
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$urls[] = array( $link, '' );
			}
		}
	}
	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ( $urls as $u ) {
		echo '<url><loc>' . esc_url( $u[0] ) . '</loc>' . ( $u[1] ? '<lastmod>' . esc_html( $u[1] ) . '</lastmod>' : '' ) . '</url>' . "\n";
	}
	echo '</urlset>';
	exit;
}

add_filter(
	'robots_txt',
	function ( $txt ) {
		if ( ! hnv_is_public() ) {
			return $txt;
		}
		return $txt . "\nSitemap: " . home_url( '/hasnivo-sitemap.xml' ) . "\n";
	},
	20
);
