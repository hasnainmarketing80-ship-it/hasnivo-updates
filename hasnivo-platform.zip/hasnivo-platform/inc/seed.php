<?php
/**
 * First-run content: the 11 product categories, IlmSeekho (first product),
 * the WhatsApp chatbot product and the 7 services. Runs once, never overwrites
 * anything that already exists.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hnv_default_categories() {
	return array(
		'LMS & Education Software',
		'School Management Systems',
		'Business Management Software',
		'AI Tools & Chatbots',
		'WhatsApp Automation',
		'Mobile Applications',
		'Web Applications',
		'Games',
		'Digital Downloads',
		'Software & Utilities',
		'Other Digital Products',
	);
}

function hnv_seed_defaults() {
	if ( get_option( 'hnv_seeded' ) ) {
		return;
	}
	foreach ( hnv_default_categories() as $c ) {
		if ( ! term_exists( $c, 'hnv_category' ) ) {
			wp_insert_term( $c, 'hnv_category' );
		}
	}

	if ( ! hnv_products( array( 'posts_per_page' => 1 ) ) ) {
		$lms = wp_insert_post(
			array(
				'post_type'    => 'hnv_product',
				'post_status'  => 'publish',
				'post_title'   => 'Ilm Seekho',
				'post_name'    => 'ilmseekho',
				'menu_order'   => 1,
				'post_excerpt' => 'A complete learning management system for schools, colleges, academies and tuition centres.',
				'post_content' => "Ilm Seekho is a learning and school management platform for schools, colleges, academies and universities in Pakistan. It is available as a website and an app, in English and Urdu.\n\nIt is in early release, so new features are being added step by step. You can register and try it today.\n\nIlm Seekho is built and supported by Hasnivo.",
			)
		);
		if ( $lms && ! is_wp_error( $lms ) ) {
			$m = array(
				'tagline'    => 'The learning management system for schools, colleges and academies',
				'status'     => 'live',
				'accent'     => '#FF8A4C',
				'logo'       => 'plugin:img/ilmseekho-logo.svg',
				'banner'     => 'plugin:img/lms-admin.svg',
				'images'     => "plugin:img/lms-admin.svg\nplugin:img/lms-teacher.svg\nplugin:img/lms-student.svg",
				'features'   => "Principal / Admin dashboard | Students, teachers, classes, fees and reports for the whole institution.\nTeacher dashboard | Plan classes, upload lectures, set work and mark progress.\nStudent dashboard | Timetable, lectures, assignments and results in one place.\nAttendance management | Mark attendance in seconds and see trends by class and student.\nAssignments | Create, collect and grade assignments online.\nExaminations | Schedule exams, record marks and publish results.\nTimetables | Class and teacher timetables that update everywhere.\nLive classes | Teach online with scheduled live sessions.\nLectures | Share recorded lectures and learning material.\nStudent progress tracking | Subject-wise progress for students and parents.",
				'specs'      => "For: Schools, colleges, academies, tuition centres\nUsers: Principal / Admin, Teachers, Students\nAccess: Any modern browser, mobile friendly\nHosting: Runs on its own app at ilmseekho.hasnivo.com\nSupport: Set-up help and training",
				'price'      => 'Contact us for pricing',
				'price_note' => 'Pricing depends on the number of students and the modules you need.',
				'demo_url'   => 'https://ilmseekho.hasnivo.com',
				'buy_url'    => '',
				'powered'    => 'IlmSeekho, powered by Hasnivo',
			);
			foreach ( $m as $k => $v ) {
				update_post_meta( $lms, '_hnv_' . $k, $v );
			}
			wp_set_object_terms( $lms, array( 'LMS & Education Software', 'School Management Systems' ), 'hnv_category' );
		}

		$wa = wp_insert_post(
			array(
				'post_type'    => 'hnv_product',
				'post_status'  => 'publish',
				'post_title'   => 'Hasnivo WhatsApp AI Chatbot',
				'post_name'    => 'whatsapp-ai-chatbot',
				'menu_order'   => 2,
				'post_excerpt' => 'An AI assistant on your WhatsApp number that answers customers, takes orders and books appointments, day and night.',
				'post_content' => "Customers expect a reply in minutes. The Hasnivo WhatsApp AI Chatbot answers common questions, shares your menu or services, takes orders, books appointments and hands the chat to a person when needed.\n\nWe set it up with your own business information, so it answers about your prices, timings and policies, not generic text.",
			)
		);
		if ( $wa && ! is_wp_error( $wa ) ) {
			$m = array(
				'tagline'    => 'Instant WhatsApp replies, orders and bookings',
				'status'     => 'live',
				'accent'     => '#25D366',
				'logo'       => 'plugin:img/whatsapp-bot-logo.svg',
				'banner'     => 'plugin:img/whatsapp-bot-banner.svg',
				'features'   => "AI replies | Answers customer questions using your own business information.\nOrder taking | Share the menu and collect orders with confirmation.\nAppointment booking | Offer slots and confirm bookings automatically.\nHuman handover | Pass the chat to your team when a person is needed.\nVoice note understanding | Understands voice messages as well as text.\nBroadcasts and contacts | Keep and message your customer list.",
				'specs'      => "Channel: WhatsApp Business\nSet-up: Done by the Hasnivo team\nLanguages: Replies in the language your customer writes in",
				'price'      => 'Plans from Rs 0',
				'price_note' => 'Free, Starter, Business and Pro plans are listed below.',
				'demo_url'   => '',
				'buy_url'    => '',
				'show_plans' => '1',
			);
			foreach ( $m as $k => $v ) {
				update_post_meta( $wa, '_hnv_' . $k, $v );
			}
			wp_set_object_terms( $wa, array( 'WhatsApp Automation', 'AI Tools & Chatbots' ), 'hnv_category' );
		}
	}

	if ( ! hnv_services() ) {
		$svc = array(
			array( 'Website Development', 'website-development', 'web', 'Fast, modern business websites that look professional on every phone and bring in enquiries.', "Custom design that fits your brand\nMobile-first, quick loading pages\nSearch-friendly structure (SEO)\nContact forms and WhatsApp buttons\nEasy updates without code" ),
			array( 'E-commerce Development', 'e-commerce-development', 'store', 'Online stores with product catalogues, secure checkout and order alerts straight to your phone.', "Product catalogue and categories\nCards, bank and cash-on-delivery options\nOrder notifications on WhatsApp\nInventory and discount tools\nTraining to manage your store" ),
			array( 'AI Chatbot Development', 'ai-chatbot-development', 'bot', 'Chatbots that understand your business and answer customers on your website, WhatsApp and more.', "Trained on your own information\nWorks in the customer's language\nLead capture and handover to humans\nTested before launch\nMonthly improvements" ),
			array( 'WhatsApp Business Automation', 'whatsapp-business-automation', 'chat', 'Automate orders, bookings, reminders and follow-ups on the channel your customers already use.', "Order and booking flows\nAutomatic reminders and follow-ups\nBroadcast messages to your contacts\nTeam inbox and chat handover\nReports on conversations" ),
			array( 'Custom Software Development', 'custom-software-development', 'code', 'Web and mobile applications built around the way your business really works.', "Requirements and planning\nWeb apps and mobile apps\nDashboards and admin panels\nSecure logins and roles\nOngoing support" ),
			array( 'Business Automation', 'business-automation', 'flow', 'Connect your tools so routine work, reports and reminders happen without manual effort.', "Forms to sheets to email flows\nInvoices, reports and alerts\nCRM and lead tracking\nIntegrations with the tools you use\nTime saved, measured" ),
			array( 'Digital Solutions', 'digital-solutions', 'spark', 'Not sure what you need? We help you choose and build the right digital tools for your goals.', "Free discovery conversation\nClear plan and timeline\nStep-by-step delivery\nTraining for your team\nPartner for the long term" ),
		);
		foreach ( $svc as $i => $s ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'hnv_service',
					'post_status'  => 'publish',
					'post_title'   => $s[0],
					'post_name'    => $s[1],
					'menu_order'   => $i + 1,
					'post_excerpt' => $s[3],
					'post_content' => $s[3] . "\n\nTell us what you want to achieve and we will recommend the simplest solution that works, with a clear price and timeline before we start.",
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_hnv_icon', $s[2] );
				update_post_meta( $id, '_hnv_tagline', $s[3] );
				update_post_meta( $id, '_hnv_bullets', $s[4] );
			}
		}
	}
	update_option( 'hnv_seeded', 1 );
}

/** 1.0.2: make the Ilm Seekho product match the real app (runs once, only if not edited since). */
function hnv_migrate_102() {
	if ( get_option( 'hnv_mig_102' ) ) {
		return;
	}
	update_option( 'hnv_mig_102', 1 );
	$p = get_page_by_path( 'ilmseekho', OBJECT, 'hnv_product' );
	if ( ! $p ) {
		return;
	}
	wp_update_post(
		array(
			'ID'           => $p->ID,
			'post_title'   => 'Ilm Seekho',
			'post_excerpt' => 'A learning and school management platform for schools, colleges, academies and universities in Pakistan.',
			'post_content' => "Ilm Seekho is a learning and school management platform for schools, colleges, academies and universities in Pakistan. It is available as a website and an app, in English and Urdu.\n\nIt is in early release, so new features are being added step by step. You can register and try it today.\n\nIlm Seekho is built and supported by Hasnivo.",
		)
	);
	$m = array(
		'tagline'    => 'Learning and school management for Pakistan, in English and Urdu',
		'status'     => 'beta',
		'accent'     => '#E8C766',
		'logo'       => 'plugin:img/ilmseekho-logo.svg',
		'banner'     => '',
		'images'     => '',
		'features'   => "Website and app | Use it in the browser or as an app on your phone.\nEnglish and Urdu | Works in both languages.\nBuilt for Pakistan | Made for schools, colleges, academies and universities here.\nRegister and sign in | Create an account and log in securely.",
		'roadmap'    => "Attendance | Mark and track attendance by class.\nAssignments | Create, collect and grade work online.\nExaminations | Schedule exams and publish results.\nTimetables | Class and teacher timetables.\nLive classes | Scheduled online sessions.\nProgress tracking | Subject-wise progress for students.",
		'specs'      => "For: Schools, colleges, academies, universities\nLanguages: English and Urdu\nAccess: Website and app\nStatus: Early release (beta)\nSupport: Set-up help from the Hasnivo team",
		'price'      => 'Contact us',
		'price_note' => 'Tell us about your institution and we will help you get started.',
		'demo_url'   => 'https://lms.hasnivo.tech',
		'powered'    => 'Ilm Seekho, powered by Hasnivo',
	);
	foreach ( $m as $k => $v ) {
		update_post_meta( $p->ID, '_hnv_' . $k, $v );
	}
}

/** 1.0.3: the LMS now lives at lms.hasnivo.com. */
function hnv_migrate_103() {
	if ( get_option( 'hnv_mig_103' ) ) {
		return;
	}
	update_option( 'hnv_mig_103', 1 );
	$p = get_page_by_path( 'ilmseekho', OBJECT, 'hnv_product' );
	if ( $p && 'https://lms.hasnivo.tech' === get_post_meta( $p->ID, '_hnv_demo_url', true ) ) {
		update_post_meta( $p->ID, '_hnv_demo_url', 'https://lms.hasnivo.com' );
	}
}
