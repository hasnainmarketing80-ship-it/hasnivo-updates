<?php
/**
 * Admin: HASNIVO menu, product/service editors, homepage & content settings.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', 'hnv_admin_menu', 9 );
function hnv_admin_menu() {
	add_menu_page( 'HASNIVO', 'HASNIVO', 'manage_options', 'hnv-home', 'hnv_settings_page', 'dashicons-superhero-alt', 25 );
	add_submenu_page( 'hnv-home', 'Homepage & content', 'Homepage & content', 'manage_options', 'hnv-home', 'hnv_settings_page' );
	add_submenu_page( 'hnv-home', 'Product categories', 'Categories', 'manage_options', 'edit-tags.php?taxonomy=hnv_category&post_type=hnv_product' );
}

add_filter(
	'parent_file',
	function ( $parent ) {
		global $current_screen;
		if ( $current_screen && 'hnv_category' === $current_screen->taxonomy ) {
			return 'hnv-home';
		}
		return $parent;
	}
);

function hnv_icon_keys() {
	return array(
		'web'   => 'Website',
		'store' => 'Store',
		'bot'   => 'AI bot',
		'chat'  => 'WhatsApp / chat',
		'code'  => 'Code / software',
		'flow'  => 'Automation',
		'spark' => 'Digital solutions',
		'book'  => 'Education',
		'app'   => 'Mobile app',
		'game'  => 'Game',
		'box'   => 'Download / package',
	);
}

/* ---------------- Meta boxes ---------------- */

add_action( 'add_meta_boxes', 'hnv_add_boxes' );
function hnv_add_boxes() {
	add_meta_box( 'hnv_product_box', 'Product details', 'hnv_product_box', 'hnv_product', 'normal', 'high' );
	add_meta_box( 'hnv_service_box', 'Service details', 'hnv_service_box', 'hnv_service', 'normal', 'high' );
}

function hnv_field_html( $post_id, $key, $def ) {
	list( $label, $type, $help ) = $def;
	$name = 'hnv_f[' . $key . ']';
	$val  = hnv_meta( $post_id, $key );
	echo '<div class="hnv-f"><label for="hnv_' . esc_attr( $key ) . '"><b>' . esc_html( $label ) . '</b></label>';
	switch ( $type ) {
		case 'status':
			echo '<select id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( array( 'live' => 'Live', 'beta' => 'Beta', 'coming' => 'Coming soon' ) as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( '' === $val ? 'live' : $val, $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select>';
			break;
		case 'color':
			echo '<input type="color" id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ? $val : '#3B74FF' ) . '">';
			break;
		case 'lines':
			echo '<textarea id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" rows="6" class="large-text">' . esc_textarea( $val ) . '</textarea>';
			break;
		case 'gallery':
			echo '<textarea id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" rows="4" class="large-text">' . esc_textarea( $val ) . '</textarea>';
			echo '<p><button type="button" class="button hnv-pick" data-target="hnv_' . esc_attr( $key ) . '" data-multi="1">Add images from library</button></p>';
			break;
		case 'media':
			echo '<input type="text" class="large-text" id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"> ';
			echo '<button type="button" class="button hnv-pick" data-target="hnv_' . esc_attr( $key ) . '">Choose image</button>';
			break;
		case 'check':
			echo ' <input type="checkbox" id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1"' . checked( '1', (string) $val, false ) . '>';
			break;
		case 'icon':
			echo '<select id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( hnv_icon_keys() as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $val ? $val : 'spark', $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select>';
			break;
		case 'url':
			echo '<input type="url" class="large-text" id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" placeholder="https://">';
			if ( 'video' === $key ) {
				echo ' <button type="button" class="button hnv-pick" data-target="hnv_video" data-type="video">Choose video</button>';
			}
			break;
		default:
			echo '<input type="text" class="large-text" id="hnv_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
	}
	if ( '' !== $help ) {
		echo '<p class="description">' . esc_html( $help ) . '</p>';
	}
	echo '</div>';
}

function hnv_product_box( $post ) {
	wp_nonce_field( 'hnv_save_' . $post->ID, 'hnv_nonce' );
	echo '<p class="description">Write the main description in the big editor above, add a short summary in the Excerpt box, pick a category on the right. Everything here appears on the product landing page. Saving a published product shows it on the website straight away.</p>';
	foreach ( hnv_product_fields() as $k => $d ) {
		hnv_field_html( $post->ID, $k, $d );
	}
}
function hnv_service_box( $post ) {
	wp_nonce_field( 'hnv_save_' . $post->ID, 'hnv_nonce' );
	foreach ( hnv_service_fields() as $k => $d ) {
		hnv_field_html( $post->ID, $k, $d );
	}
}

function hnv_clean_media( $v ) {
	$v = trim( (string) $v );
	if ( 0 === strpos( $v, 'plugin:' ) ) {
		return preg_match( '#^plugin:[a-z0-9/_.-]+$#i', $v ) ? $v : '';
	}
	return esc_url_raw( $v );
}

add_action( 'save_post', 'hnv_save_fields', 10, 2 );
function hnv_save_fields( $post_id, $post ) {
	if ( ! in_array( $post->post_type, array( 'hnv_product', 'hnv_service' ), true ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['hnv_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hnv_nonce'] ) ), 'hnv_save_' . $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$defs = 'hnv_product' === $post->post_type ? hnv_product_fields() : hnv_service_fields();
	$in   = isset( $_POST['hnv_f'] ) && is_array( $_POST['hnv_f'] ) ? wp_unslash( $_POST['hnv_f'] ) : array();
	foreach ( $defs as $key => $def ) {
		$raw  = isset( $in[ $key ] ) ? $in[ $key ] : '';
		$type = $def[1];
		switch ( $type ) {
			case 'status':
				$v = in_array( $raw, array( 'live', 'beta', 'coming' ), true ) ? $raw : 'live';
				break;
			case 'color':
				$v = (string) sanitize_hex_color( $raw );
				break;
			case 'check':
				$v = $raw ? '1' : '';
				break;
			case 'icon':
				$v = array_key_exists( $raw, hnv_icon_keys() ) ? $raw : 'spark';
				break;
			case 'media':
			case 'url':
				$v = hnv_clean_media( $raw );
				break;
			case 'gallery':
				$v = implode( "\n", array_filter( array_map( 'hnv_clean_media', hnv_lines( $raw ) ) ) );
				break;
			case 'lines':
				$v = substr( sanitize_textarea_field( $raw ), 0, 6000 );
				break;
			default:
				$v = substr( sanitize_text_field( $raw ), 0, 300 );
		}
		update_post_meta( $post_id, '_hnv_' . $key, $v );
	}
}

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		$s = get_current_screen();
		if ( ! $s ) {
			return;
		}
		$ours = in_array( $s->post_type, array( 'hnv_product', 'hnv_service' ), true ) || 'toplevel_page_hnv-home' === $hook;
		if ( ! $ours ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'hnv-admin', HNV_URL . 'assets/admin.css', array(), HNV_VER );
		wp_enqueue_script( 'hnv-admin', HNV_URL . 'assets/admin.js', array( 'jquery' ), HNV_VER, true );
	}
);

/* ---- Product list columns ---- */
add_filter(
	'manage_hnv_product_posts_columns',
	function ( $c ) {
		$n = array();
		foreach ( $c as $k => $v ) {
			$n[ $k ] = $v;
			if ( 'title' === $k ) {
				$n['hnv_status'] = 'Status';
				$n['hnv_cat']    = 'Category';
			}
		}
		return $n;
	}
);
add_action(
	'manage_hnv_product_posts_custom_column',
	function ( $col, $id ) {
		if ( 'hnv_status' === $col ) {
			$s = hnv_meta( $id, 'status', 'live' );
			echo esc_html( array( 'live' => 'Live', 'beta' => 'Beta', 'coming' => 'Coming soon' )[ $s ] ?? 'Live' );
			echo 'publish' === get_post_status( $id ) ? '' : ' (not published)';
		}
		if ( 'hnv_cat' === $col ) {
			$t = get_the_terms( $id, 'hnv_category' );
			echo $t && ! is_wp_error( $t ) ? esc_html( implode( ', ', wp_list_pluck( $t, 'name' ) ) ) : '-';
		}
	},
	10,
	2
);

/* ---------------- Homepage & content settings ---------------- */

function hnv_settings_fields() {
	return array(
		'Homepage hero'        => array(
			'hero_kicker' => array( 'Small line above the headline', 'text' ),
			'hero_title'  => array( 'Headline', 'text' ),
			'hero_sub'    => array( 'Sub-headline', 'area2' ),
			'cta1_text'   => array( 'Main button text', 'text' ),
			'cta1_url'    => array( 'Main button link (e.g. /products/)', 'text' ),
			'cta2_text'   => array( 'Second button text', 'text' ),
			'cta2_url'    => array( 'Second button link', 'text' ),
			'stats'       => array( 'Numbers strip. One per line: value|label', 'area4' ),
		),
		'Promotional banners'  => array(
			'banners' => array( 'One banner per line: Title|Text|Button text|Link. Leave empty to hide banners.', 'area5' ),
		),
		'Solutions page'       => array(
			'solutions' => array( 'One per line: Title|Description|icon(education, food, health, store, growth)|Link', 'area6' ),
		),
		'Digital Skills page'  => array(
			'skills' => array( 'One per line: Title|Description|Level', 'area6' ),
		),
		'About Us page'        => array(
			'about' => array( 'Text. Each line becomes a paragraph.', 'area6' ),
		),
		'Contact details'      => array(
			'email'    => array( 'Email for enquiries', 'text' ),
			'whatsapp' => array( 'WhatsApp number with country code, digits only', 'text' ),
			'address'  => array( 'Location line shown in the footer and contact page', 'text' ),
			'ga4'      => array( 'Google Analytics 4 ID (optional, looks like G-XXXXXXXXXX)', 'text' ),
		),
	);
}

add_action( 'admin_post_hnv_save_settings', 'hnv_save_settings' );
function hnv_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'hnv_settings' );
	$in  = isset( $_POST['hnv'] ) && is_array( $_POST['hnv'] ) ? wp_unslash( $_POST['hnv'] ) : array();
	$out = array();
	foreach ( hnv_settings_fields() as $group ) {
		foreach ( $group as $k => $def ) {
			$v = isset( $in[ $k ] ) ? (string) $in[ $k ] : '';
			if ( 0 === strpos( $def[1], 'area' ) ) {
				$v = substr( sanitize_textarea_field( $v ), 0, 5000 );
			} else {
				$v = substr( sanitize_text_field( $v ), 0, 300 );
			}
			if ( 'ga4' === $k && '' !== $v && ! preg_match( '/^G-[A-Z0-9]{6,}$/', $v ) ) {
				$v = '';
			}
			if ( 'email' === $k && '' !== $v && ! is_email( $v ) ) {
				$v = '';
			}
			$out[ $k ] = $v;
		}
	}
	update_option( 'hnv_options', $out );
	update_option( 'hnv_public', ! empty( $_POST['hnv_public'] ) ? '1' : '' );
	wp_safe_redirect( admin_url( 'admin.php?page=hnv-home&saved=1' ) );
	exit;
}

function hnv_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	echo '<div class="wrap hnv-wrap"><h1>HASNIVO · Homepage & content</h1>';
	if ( isset( $_GET['saved'] ) ) {
		echo '<div class="notice notice-success is-dismissible"><p>Saved. Your website is updated.</p></div>';
	}
	echo '<p class="description">Products, Services and Categories have their own menus on the left. Everything on this page edits text on the website. Leave a box empty to use the built-in default text.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="hnv_save_settings">';
	wp_nonce_field( 'hnv_settings' );
	$o = get_option( 'hnv_options', array() );
	$d = hnv_option_defaults();
	echo '<div class="hnv-card"><h2>Go live</h2><p><label><input type="checkbox" name="hnv_public" value="1"' . checked( '1', (string) get_option( 'hnv_public', '' ), false ) . '> <b>Show the new HASNIVO site to everyone</b></label></p><p class="description">Unticked = preview mode: only you (logged in as administrator) see the new site, visitors still see the old one. Tick this box and save when you are ready to go live. Untick it to go back instantly.</p></div>';
	foreach ( hnv_settings_fields() as $group => $fields ) {
		echo '<div class="hnv-card"><h2>' . esc_html( $group ) . '</h2>';
		foreach ( $fields as $k => $def ) {
			$val = isset( $o[ $k ] ) ? $o[ $k ] : '';
			echo '<div class="hnv-f"><label for="s_' . esc_attr( $k ) . '"><b>' . esc_html( $def[0] ) . '</b></label>';
			if ( 0 === strpos( $def[1], 'area' ) ) {
				echo '<textarea id="s_' . esc_attr( $k ) . '" name="hnv[' . esc_attr( $k ) . ']" rows="' . (int) substr( $def[1], 4 ) . '" class="large-text" placeholder="' . esc_attr( $d[ $k ] ) . '">' . esc_textarea( $val ) . '</textarea>';
			} else {
				echo '<input type="text" id="s_' . esc_attr( $k ) . '" name="hnv[' . esc_attr( $k ) . ']" value="' . esc_attr( $val ) . '" class="large-text" placeholder="' . esc_attr( $d[ $k ] ) . '">';
			}
			echo '</div>';
		}
		echo '</div>';
	}
	submit_button( 'Save changes' );
	echo '</form></div>';
}
